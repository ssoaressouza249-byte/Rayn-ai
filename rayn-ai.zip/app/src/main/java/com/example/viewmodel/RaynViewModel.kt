package com.example.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GeminiModelInfo
import com.example.data.RaynPreferences
import com.example.data.RaynSettingsState
import com.example.network.ChatTurn
import com.example.network.GeminiRestClient
import com.example.network.PingResult
import com.example.network.PolicyGuard
import com.example.scanner.ScanReport
import com.example.scanner.VirusScannerAnalyzer
import com.example.security.IntegrityReport
import com.example.security.SecurityIntegrityGuard
import com.example.storage.AttachedFile
import com.example.storage.SavedFileResult
import com.example.storage.StorageManager
import com.example.swb.SwbBuildResult
import com.example.swb.SwbProjectGenerator
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class RaynTab(val label: String) {
    CHAT("Rayn Chat"),
    SWB("Criar .SWB"),
    SCANNER("Scanner Vírus"),
    SETTINGS("Ajustes"),
}

data class ChatUiMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val attachmentName: String? = null,
    val suggestedFileName: String? = null,
    val extractableContent: String? = null,
    val autoSavedResult: SavedFileResult? = null,
    val isError: Boolean = false,
    val timestampMs: Long = System.currentTimeMillis(),
)

data class SaveFeedbackBanner(
    val message: String,
    val isError: Boolean = false,
)

data class RaynUiState(
    val currentTab: RaynTab = RaynTab.CHAT,
    val integrityReport: IntegrityReport? = null,
    val settings: RaynSettingsState = RaynSettingsState(),
    val folderDisplayName: String = "Nenhuma pasta selecionada",
    val cooldownRemainingMs: Long = 0L,
    val cooldownFormatted: String = "",

    // Settings UI
    val apiKeyDraft: String = "",
    val isFetchingModels: Boolean = false,
    val modelsError: String? = null,
    val isTestingConnection: Boolean = false,
    val pingResult: PingResult? = null,

    // Chat UI
    val chatMessages: List<ChatUiMessage> = emptyList(),
    val chatInput: String = "",
    val attachedFile: AttachedFile? = null,
    val isChatLoading: Boolean = false,
    val saveBanner: SaveFeedbackBanner? = null,

    // SWB UI
    val swbAppName: String = "RaynUtility",
    val swbPackageName: String = "com.rayn.utility",
    val swbDescription: String = "",
    val swbUseAi: Boolean = true,
    val isGeneratingSwb: Boolean = false,
    val swbError: String? = null,
    val lastSwbResult: SwbBuildResult? = null,

    // Scanner UI
    val isScanning: Boolean = false,
    val scanError: String? = null,
    val scanReport: ScanReport? = null,
)

class RaynViewModel(application: Application) : AndroidViewModel(application) {

    private val preferences = RaynPreferences(application)
    private val geminiClient = GeminiRestClient()

    private val _uiState = MutableStateFlow(RaynUiState())
    val uiState: StateFlow<RaynUiState> = _uiState.asStateFlow()

    private var apiDraftInitialized = false

    init {
        observePreferences()
        runIntegrityCheck()
        startCooldownTicker()
    }

    private fun observePreferences() {
        viewModelScope.launch {
            preferences.stateFlow.collect { settings ->
                val folderLabel = StorageManager.getReadableFolderName(
                    getApplication(),
                    settings.savedFolderUri
                )
                val remaining = computeRemainingCooldownMs(settings)
                _uiState.update { state ->
                    state.copy(
                        settings = settings,
                        folderDisplayName = folderLabel,
                        cooldownRemainingMs = remaining,
                        cooldownFormatted = formatCooldown(remaining),
                        apiKeyDraft = if (!apiDraftInitialized) {
                            apiDraftInitialized = true
                            settings.geminiApiKey
                        } else {
                            state.apiKeyDraft
                        }
                    )
                }
            }
        }
    }

    private fun startCooldownTicker() {
        viewModelScope.launch {
            while (isActive) {
                val snapshot = _uiState.value.settings
                if (snapshot.swbCredits <= 0) {
                    val restored = preferences.restoreCreditsIfCooldownElapsed()
                    if (!restored) {
                        val remaining = computeRemainingCooldownMs(snapshot)
                        _uiState.update {
                            it.copy(
                                cooldownRemainingMs = remaining,
                                cooldownFormatted = formatCooldown(remaining)
                            )
                        }
                    }
                } else if (_uiState.value.cooldownRemainingMs != 0L) {
                    _uiState.update {
                        it.copy(cooldownRemainingMs = 0L, cooldownFormatted = "")
                    }
                }
                delay(1000L)
            }
        }
    }

    private fun computeRemainingCooldownMs(settings: RaynSettingsState): Long {
        if (settings.swbCredits > 0 || settings.cooldownStartTimestamp <= 0L) return 0L
        val elapsed = System.currentTimeMillis() - settings.cooldownStartTimestamp
        return (RaynSettingsState.COOLDOWN_DURATION_MS - elapsed).coerceAtLeast(0L)
    }

    private fun formatCooldown(remainingMs: Long): String {
        val totalSeconds = (remainingMs / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return String.format("Volta em %02dh %02dm %02ds", hours, minutes, seconds)
    }

    fun selectTab(tab: RaynTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun runIntegrityCheck() {
        viewModelScope.launch {
            val report = SecurityIntegrityGuard.verifyIntegrity(getApplication(), preferences)
            _uiState.update { it.copy(integrityReport = report) }
        }
    }

    private suspend fun ensureIntegrityBeforeAction(): Boolean {
        val report = SecurityIntegrityGuard.verifyIntegrity(getApplication(), preferences)
        _uiState.update { it.copy(integrityReport = report) }
        return report.isValid
    }

    // --- SETTINGS ---

    fun updateApiKeyDraft(value: String) {
        _uiState.update { it.copy(apiKeyDraft = value, modelsError = null) }
    }

    fun saveApiKeyAndSyncModels() {
        val key = _uiState.value.apiKeyDraft.trim()
        if (key.isBlank()) {
            _uiState.update { it.copy(modelsError = "Cole sua GEMINI_API_KEY antes de salvar.") }
            return
        }
        viewModelScope.launch {
            if (!ensureIntegrityBeforeAction()) return@launch
            _uiState.update {
                it.copy(isFetchingModels = true, modelsError = null, pingResult = null)
            }
            preferences.saveApiKeyOnly(key)
            val result = geminiClient.listActiveModels(key)
            result.onSuccess { models ->
                val currentSelected = _uiState.value.settings.selectedModel
                val chosenModel = models.firstOrNull { it.id == currentSelected }?.id
                    ?: models.firstOrNull { it.id.contains("flash", ignoreCase = true) }?.id
                    ?: models.first().id
                preferences.saveApiKeyAndModels(key, models, chosenModel)
                _uiState.update {
                    it.copy(
                        isFetchingModels = false,
                        modelsError = null,
                        saveBanner = SaveFeedbackBanner(
                            "${models.size} modelos ativos sincronizados na sua conta."
                        )
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isFetchingModels = false,
                        modelsError = err.message ?: "Falha ao listar modelos."
                    )
                }
            }
        }
    }

    fun selectModel(model: GeminiModelInfo) {
        viewModelScope.launch {
            preferences.saveSelectedModel(model.id)
            _uiState.update { it.copy(pingResult = null) }
        }
    }

    fun testConnection() {
        val key = _uiState.value.apiKeyDraft.trim().ifBlank { _uiState.value.settings.geminiApiKey }
        val model = _uiState.value.settings.selectedModel
        viewModelScope.launch {
            if (!ensureIntegrityBeforeAction()) return@launch
            _uiState.update { it.copy(isTestingConnection = true, pingResult = null) }
            val ping = geminiClient.testConnection(key, model)
            _uiState.update { it.copy(isTestingConnection = false, pingResult = ping) }
        }
    }

    fun onFolderSelected(uri: Uri?) {
        if (uri == null) return
        val context = getApplication<Application>()
        runCatching {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            context.contentResolver.takePersistableUriPermission(uri, flags)
        }
        viewModelScope.launch {
            preferences.saveFolderUri(uri.toString())
            val label = StorageManager.getReadableFolderName(context, uri.toString())
            _uiState.update {
                it.copy(
                    saveBanner = SaveFeedbackBanner("Pasta padrão definida: $label")
                )
            }
        }
    }

    // --- CHAT & DOCUMENTFILE ---

    fun updateChatInput(text: String) {
        _uiState.update { it.copy(chatInput = text) }
    }

    fun attachDocument(uri: Uri?) {
        if (uri == null) return
        viewModelScope.launch {
            StorageManager.readAttachedFile(getApplication(), uri)
                .onSuccess { attached ->
                    _uiState.update {
                        it.copy(
                            attachedFile = attached,
                            saveBanner = SaveFeedbackBanner("Anexado: ${attached.name}")
                        )
                    }
                }
                .onFailure { err ->
                    _uiState.update {
                        it.copy(
                            saveBanner = SaveFeedbackBanner(
                                err.message ?: "Erro ao ler arquivo anexado.",
                                isError = true
                            )
                        )
                    }
                }
        }
    }

    fun clearAttachment() {
        _uiState.update { it.copy(attachedFile = null) }
    }

    fun dismissBanner() {
        _uiState.update { it.copy(saveBanner = null) }
    }

    fun sendChatMessage(overridePrompt: String? = null) {
        val state = _uiState.value
        val prompt = (overridePrompt ?: state.chatInput).trim()
        val attached = state.attachedFile

        if (prompt.isBlank() && attached == null) return
        if (state.isChatLoading) return

        val finalPrompt = prompt.ifBlank {
            "Analise o arquivo anexado (${attached?.name}) e explique seu conteúdo."
        }

        val userMsg = ChatUiMessage(
            id = "u_${System.currentTimeMillis()}",
            isUser = true,
            text = finalPrompt,
            attachmentName = attached?.name,
        )

        _uiState.update {
            it.copy(
                chatMessages = it.chatMessages + userMsg,
                chatInput = if (overridePrompt == null) "" else it.chatInput,
                attachedFile = null,
                isChatLoading = true,
            )
        }

        viewModelScope.launch {
            if (!ensureIntegrityBeforeAction()) {
                _uiState.update { it.copy(isChatLoading = false) }
                return@launch
            }

            // Se o usuário enviou arquivo/texto com pedido direto de salvar e não há chave configurada,
            // ou após responder com IA, garantimos execução imediata!
            val settings = _uiState.value.settings
            val wantsSave = StorageManager.shouldAutoSaveFromPrompt(finalPrompt)

            val historyTurns = _uiState.value.chatMessages
                .dropLast(1)
                .filter { !it.isError }
                .map { ChatTurn(isUser = it.isUser, text = it.text) }

            val responseResult = geminiClient.generateChat(
                apiKey = settings.geminiApiKey,
                modelId = settings.selectedModel,
                history = historyTurns,
                attachmentName = attached?.name,
                attachmentContent = attached?.textContent,
                userPrompt = finalPrompt,
            )

            responseResult.onSuccess { replyText ->
                val payload = StorageManager.extractFilePayload(
                    userPrompt = finalPrompt,
                    aiResponse = replyText,
                    attachedFileName = attached?.name
                )

                var autoSaved: SavedFileResult? = null
                var banner: SaveFeedbackBanner? = null

                if (wantsSave) {
                    if (settings.savedFolderUri.isNotBlank()) {
                        StorageManager.saveTextToFolder(
                            context = getApplication(),
                            folderUriString = settings.savedFolderUri,
                            fileName = payload.suggestedFileName,
                            content = payload.content
                        ).onSuccess { saved ->
                            autoSaved = saved
                            banner = SaveFeedbackBanner(
                                "Salvo automaticamente em ${saved.locationLabel}/${saved.fileName}"
                            )
                        }.onFailure { err ->
                            banner = SaveFeedbackBanner(
                                err.message ?: "Erro ao salvar automaticamente.",
                                isError = true
                            )
                        }
                    } else {
                        banner = SaveFeedbackBanner(
                            "Configure a Pasta Padrão na aba Ajustes para salvamento automático.",
                            isError = true
                        )
                    }
                }

                val aiMsg = ChatUiMessage(
                    id = "a_${System.currentTimeMillis()}",
                    isUser = false,
                    text = replyText,
                    suggestedFileName = payload.suggestedFileName,
                    extractableContent = payload.content,
                    autoSavedResult = autoSaved,
                )

                _uiState.update {
                    it.copy(
                        chatMessages = it.chatMessages + aiMsg,
                        isChatLoading = false,
                        saveBanner = banner ?: it.saveBanner,
                    )
                }
            }.onFailure { err ->
                // Caso especial: usuário anexou arquivo e pediu só para salvar na pasta sem IA configurada
                if (wantsSave && attached != null && settings.geminiApiKey.isBlank() &&
                    settings.savedFolderUri.isNotBlank()
                ) {
                    val targetName = StorageManager.extractFilePayload(
                        userPrompt = finalPrompt,
                        aiResponse = attached.textContent,
                        attachedFileName = attached.name
                    ).suggestedFileName
                    val savedRes = StorageManager.saveTextToFolder(
                        context = getApplication(),
                        folderUriString = settings.savedFolderUri,
                        fileName = targetName,
                        content = attached.textContent
                    )
                    savedRes.onSuccess { saved ->
                        val msg = ChatUiMessage(
                            id = "a_${System.currentTimeMillis()}",
                            isUser = false,
                            text = "Arquivo salvo diretamente na pasta selecionada: ${saved.locationLabel}/${saved.fileName}",
                            suggestedFileName = saved.fileName,
                            extractableContent = attached.textContent,
                            autoSavedResult = saved,
                        )
                        _uiState.update {
                            it.copy(
                                chatMessages = it.chatMessages + msg,
                                isChatLoading = false,
                                saveBanner = SaveFeedbackBanner("Salvo: ${saved.fileName}")
                            )
                        }
                        return@launch
                    }
                }

                val errMsg = ChatUiMessage(
                    id = "e_${System.currentTimeMillis()}",
                    isUser = false,
                    text = err.message ?: "Falha ao processar mensagem.",
                    isError = true,
                )
                _uiState.update {
                    it.copy(
                        chatMessages = it.chatMessages + errMsg,
                        isChatLoading = false,
                    )
                }
            }
        }
    }

    fun saveMessageToFolder(message: ChatUiMessage, customFileName: String? = null) {
        val folderUri = _uiState.value.settings.savedFolderUri
        if (folderUri.isBlank()) {
            _uiState.update {
                it.copy(
                    saveBanner = SaveFeedbackBanner(
                        "Defina a Pasta Padrão de Salvamento na aba Ajustes primeiro.",
                        isError = true
                    )
                )
            }
            return
        }

        val content = message.extractableContent ?: message.text
        val fileName = (customFileName ?: message.suggestedFileName ?: "rayn_resposta_${message.timestampMs % 10000}.txt")
            .trim()
            .ifBlank { "rayn_resposta.txt" }

        viewModelScope.launch {
            StorageManager.saveTextToFolder(
                context = getApplication(),
                folderUriString = folderUri,
                fileName = fileName,
                content = content
            ).onSuccess { saved ->
                _uiState.update { state ->
                    state.copy(
                        chatMessages = state.chatMessages.map {
                            if (it.id == message.id) it.copy(autoSavedResult = saved) else it
                        },
                        saveBanner = SaveFeedbackBanner(
                            "Arquivo \"${saved.fileName}\" salvo em ${saved.locationLabel}!"
                        )
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        saveBanner = SaveFeedbackBanner(
                            err.message ?: "Não foi possível gravar o arquivo na pasta.",
                            isError = true
                        )
                    )
                }
            }
        }
    }

    // --- SWB CREATOR ---

    fun updateSwbAppName(value: String) {
        _uiState.update { it.copy(swbAppName = value, swbError = null) }
    }

    fun updateSwbPackageName(value: String) {
        _uiState.update { it.copy(swbPackageName = value, swbError = null) }
    }

    fun updateSwbDescription(value: String) {
        _uiState.update { it.copy(swbDescription = value, swbError = null) }
    }

    fun updateSwbUseAi(useAi: Boolean) {
        _uiState.update { it.copy(swbUseAi = useAi, swbError = null) }
    }

    fun applySwbPreset(name: String, pkg: String, desc: String) {
        _uiState.update {
            it.copy(
                swbAppName = name,
                swbPackageName = pkg,
                swbDescription = desc,
                swbError = null,
            )
        }
    }

    fun generateSwbProject() {
        val state = _uiState.value
        if (state.isGeneratingSwb) return

        viewModelScope.launch {
            if (!ensureIntegrityBeforeAction()) return@launch

            preferences.restoreCreditsIfCooldownElapsed()
            val freshSnapshot = preferences.getSnapshot()
            if (freshSnapshot.swbCredits <= 0) {
                _uiState.update {
                    it.copy(swbError = "Créditos esgotados. Aguarde o cronômetro de 15 horas.")
                }
                return@launch
            }

            val violation = PolicyGuard.checkPromptViolation("${state.swbAppName} ${state.swbDescription}")
            if (violation != null) {
                _uiState.update { it.copy(swbError = violation) }
                return@launch
            }

            _uiState.update { it.copy(isGeneratingSwb = true, swbError = null) }

            val specResult = if (state.swbUseAi) {
                geminiClient.generateSwbSpec(
                    apiKey = freshSnapshot.geminiApiKey,
                    modelId = freshSnapshot.selectedModel,
                    appName = state.swbAppName,
                    packageName = state.swbPackageName,
                    description = state.swbDescription.ifBlank { "Aplicativo utilitário Android moderno" },
                )
            } else {
                Result.success(
                    SwbProjectGenerator.buildDefaultSpec(
                        appName = state.swbAppName,
                        description = state.swbDescription,
                    )
                )
            }

            specResult.onSuccess { spec ->
                val buildResult = SwbProjectGenerator.generateAndSaveSwb(
                    context = getApplication(),
                    folderUriString = freshSnapshot.savedFolderUri,
                    appName = state.swbAppName,
                    packageName = state.swbPackageName,
                    spec = spec,
                )
                buildResult.onSuccess { swb ->
                    preferences.consumeSwbCredit()
                    _uiState.update {
                        it.copy(
                            isGeneratingSwb = false,
                            lastSwbResult = swb,
                            swbError = null,
                            saveBanner = SaveFeedbackBanner(
                                "${swb.savedFile.fileName} gerado em ${swb.savedFile.locationLabel} (-1 crédito)"
                            )
                        )
                    }
                }.onFailure { err ->
                    _uiState.update {
                        it.copy(
                            isGeneratingSwb = false,
                            swbError = err.message ?: "Falha ao empacotar arquivo .swb."
                        )
                    }
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isGeneratingSwb = false,
                        swbError = err.message ?: "Erro ao gerar especificação com Rayn AI."
                    )
                }
            }
        }
    }

    // --- VIRUS SCANNER ---

    fun scanFile(uri: Uri?) {
        if (uri == null) return
        viewModelScope.launch {
            if (!ensureIntegrityBeforeAction()) return@launch
            _uiState.update { it.copy(isScanning = true, scanError = null) }
            VirusScannerAnalyzer.analyzeFile(getApplication(), uri)
                .onSuccess { report ->
                    _uiState.update {
                        it.copy(isScanning = false, scanReport = report, scanError = null)
                    }
                }
                .onFailure { err ->
                    _uiState.update {
                        it.copy(
                            isScanning = false,
                            scanError = err.message ?: "Falha ao analisar o arquivo."
                        )
                    }
                }
        }
    }
}
