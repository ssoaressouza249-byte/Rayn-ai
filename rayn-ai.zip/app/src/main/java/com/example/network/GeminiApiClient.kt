package com.example.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class GeminiChatTurn(
    val isUser: Boolean,
    val text: String
)

data class GeminiTestResult(
    val success: Boolean,
    val latencyMs: Long,
    val message: String
)

class GeminiApiClient {

    companion object {
        const val BASE_HOST_URL = "https://generativelanguage.googleapis.com"
        const val DEFAULT_API_VERSION = "v1beta"
        const val DEFAULT_MODEL_ID = "gemini-2.5-flash"

        fun sanitizeApiKey(rawKey: String): String {
            return rawKey.trim().replace(Regex("\\s+"), "")
        }

        fun buildGenerateContentUrl(
            apiVersion: String,
            modelId: String,
            apiKey: String
        ): HttpUrl {
            val cleanModel = modelId.removePrefix("models/").trim()
            return "$BASE_HOST_URL/$apiVersion/models/$cleanModel:generateContent"
                .toHttpUrl()
                .newBuilder()
                .addQueryParameter("key", sanitizeApiKey(apiKey))
                .build()
        }

        fun buildListModelsUrl(apiVersion: String, apiKey: String): HttpUrl {
            return "$BASE_HOST_URL/$apiVersion/models"
                .toHttpUrl()
                .newBuilder()
                .addQueryParameter("key", sanitizeApiKey(apiKey))
                .build()
        }

        fun pickBestFlashModelFromListJson(rawJson: String): String? {
            val models = JSONObject(rawJson).optJSONArray("models") ?: return null
            val candidates = mutableListOf<String>()
            for (i in 0 until models.length()) {
                val item = models.optJSONObject(i) ?: continue
                val name = item.optString("name").removePrefix("models/")
                val methods = item.optJSONArray("supportedGenerationMethods") ?: continue
                var supportsGenerate = false
                for (j in 0 until methods.length()) {
                    if (methods.optString(j) == "generateContent") {
                        supportsGenerate = true
                        break
                    }
                }
                if (supportsGenerate && name.startsWith("gemini", ignoreCase = true)) {
                    val lower = name.lowercase()
                    if (!lower.contains("embedding") &&
                        !lower.contains("image") &&
                        !lower.contains("tts") &&
                        !lower.contains("robotics")
                    ) {
                        candidates.add(name)
                    }
                }
            }
            if (candidates.isEmpty()) return null

            return candidates.firstOrNull { it == DEFAULT_MODEL_ID }
                ?: candidates.firstOrNull { it == "gemini-flash-latest" }
                ?: candidates.firstOrNull { it.contains("flash", ignoreCase = true) && !it.contains("lite", ignoreCase = true) }
                ?: candidates.firstOrNull { it.contains("flash", ignoreCase = true) }
                ?: candidates.firstOrNull()
        }

        fun formatApiError(code: Int, rawBody: String, endpointPath: String): String {
            val trimmedBody = rawBody.trim()
            val parsedMsg = runCatching {
                JSONObject(trimmedBody).optJSONObject("error")?.optString("message")
            }.getOrNull()

            return buildString {
                append("Erro HTTP $code ($endpointPath)")
                if (!parsedMsg.isNullOrBlank()) {
                    append(": $parsedMsg")
                }
                if (trimmedBody.isNotBlank()) {
                    append("\nResposta da API: $trimmedBody")
                } else {
                    append("\nResposta da API: (corpo vazio)")
                }
            }
        }

        val MANDATORY_SYSTEM_INSTRUCTION = """
            Você é a Rayn AI, um assistente avançado de engenharia Android, manipulação de arquivos e arquitetura Sketchware Pro.
            REGRAS DE CONDUTA OBRIGATÓRIAS (PRIORIDADE MÁXIMA):
            a) NUNCA gerar, descrever ou processar conteúdo íntimo, sexual ou NSFW. Recusar imediatamente qualquer pedido desse tipo.
            b) NUNCA criar cheats pesados, hacks, mods maliciosos, aimbots automáticos ou qualquer código destinado a injetar, alterar ou explorar arquivos internos de jogos (Android/data, obb, bibliotecas .so).
            c) PERMITIR a criação de aplicativos legítimos em geral, utilitários visuais inofensivos (como sobreposição simples de mira/crosshair na tela sem interação com arquivos ou memória de jogos) e a organização/salvamento de arquivos do próprio usuário.
            d) Quando o usuário enviar ou descrever um arquivo próprio legítimo e pedir para montar os blocos correspondentes no Sketchware, gerar apenas a estrutura de blocos padrão do Sketchware (onCreate, onClick, manipulação segura de arquivos do próprio app).
            
            INSTRUÇÕES DE MANIPULAÇÃO E SALVAMENTO DE ARQUIVOS NO CHAT:
            Quando o usuário pedir para criar, editar, corrigir ou converter um arquivo (ou pedir para salvar em uma pasta/subpasta), responda de forma clara em português e inclua EXATAMENTE o bloco estruturado abaixo contendo o arquivo completo pronto para gravação direta:
            <<<RAYN_FILE_START>>>
            FILENAME: nome_exato_com_extensao.ext
            SUBFOLDER: subpasta_opcional_ou_vazio
            AUTO_SAVE: true_ou_false
            <<<CONTENT>>>
            conteúdo completo do arquivo aqui
            <<<RAYN_FILE_END>>>
            Defina AUTO_SAVE como true sempre que o usuário pedir explicitamente para salvar/gravar o arquivo na pasta.
        """.trimIndent()
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    @Volatile
    private var activeApiVersion: String = DEFAULT_API_VERSION

    @Volatile
    private var activeModelId: String = DEFAULT_MODEL_ID

    suspend fun testConnection(apiKey: String): GeminiTestResult = withContext(Dispatchers.IO) {
        val cleanKey = sanitizeApiKey(apiKey)
        if (cleanKey.isBlank()) {
            return@withContext GeminiTestResult(
                success = false,
                latencyMs = 0L,
                message = "Informe uma GEMINI_API_KEY válida antes de testar."
            )
        }

        val start = System.currentTimeMillis()
        try {
            val payload = JSONObject().apply {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", MANDATORY_SYSTEM_INSTRUCTION)))
                })
                put("contents", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", "Responda apenas: RAYN_ONLINE_OK")))
                }))
                put("generationConfig", JSONObject().apply {
                    put("maxOutputTokens", 32)
                    put("temperature", 0.1)
                })
            }

            val (usedModel, rawBody) = executeWith404Fallback(cleanKey, payload)
            val latency = System.currentTimeMillis() - start
            val text = extractCandidateText(rawBody)
            GeminiTestResult(
                success = true,
                latencyMs = latency,
                message = "Conectado ao $usedModel (${latency}ms): ${text.take(60)}"
            )
        } catch (e: Exception) {
            val latency = System.currentTimeMillis() - start
            GeminiTestResult(
                success = false,
                latencyMs = latency,
                message = e.localizedMessage ?: "Erro desconhecido ao conectar à API Gemini."
            )
        }
    }

    suspend fun generateChatReply(
        apiKey: String,
        history: List<GeminiChatTurn>,
        userPrompt: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanKey = sanitizeApiKey(apiKey)
            require(cleanKey.isNotBlank()) {
                "GEMINI_API_KEY não configurada. Acesse a aba Ajustes para inserir e testar sua chave."
            }

            val contentsArray = JSONArray()
            history.takeLast(12).forEach { turn ->
                contentsArray.put(JSONObject().apply {
                    put("role", if (turn.isUser) "user" else "model")
                    put("parts", JSONArray().put(JSONObject().put("text", turn.text)))
                })
            }
            contentsArray.put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", userPrompt)))
            })

            val payload = JSONObject().apply {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", MANDATORY_SYSTEM_INSTRUCTION)))
                })
                put("contents", contentsArray)
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.35)
                })
            }

            val (_, rawBody) = executeWith404Fallback(cleanKey, payload)
            extractCandidateText(rawBody)
        }
    }

    suspend fun generateSwbBlueprintJson(
        apiKey: String,
        appName: String,
        packageName: String,
        description: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanKey = sanitizeApiKey(apiKey)
            require(cleanKey.isNotBlank()) {
                "GEMINI_API_KEY não configurada. Acesse a aba Ajustes para configurar sua chave."
            }

            val swbSystemPrompt = """
                $MANDATORY_SYSTEM_INSTRUCTION
                
                TAREFA ESPECÍFICA:
                Gere um JSON estritamente válido para empacotamento de um projeto Sketchware Pro (.swb).
                Se o pedido violar as regras a) ou b), retorne um JSON com {"rejected": true, "reason": "motivo"}.
                Caso contrário, retorne um JSON com exatamente as chaves:
                {
                  "rejected": false,
                  "project": {
                    "my_app_name": "$appName",
                    "my_sc_pkg_name": "$packageName",
                    "my_ws_name": "$appName",
                    "sc_ver_code": "1",
                    "sc_ver_name": "1.0",
                    "color_primary": "#2979FF",
                    "color_primary_dark": "#06080F",
                    "color_accent": "#00E5FF"
                  },
                  "file": {
                    "activities": [
                      {"fileName": "main", "type": 1, "orientation": 1, "theme": 0}
                    ],
                    "customViews": []
                  },
                  "view": {
                    "mainXml": "<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\" android:layout_width=\"match_parent\" android:layout_height=\"match_parent\" android:orientation=\"vertical\" android:padding=\"16dp\" android:background=\"#06080F\">...</LinearLayout>",
                    "widgets": [
                      {"id": "textview1", "type": "TextView", "text": "$appName"},
                      {"id": "button1", "type": "Button", "text": "Executar"}
                    ]
                  },
                  "logic": {
                    "events": [
                      {
                        "targetId": "main",
                        "eventName": "onCreate",
                        "blocks": [
                          {"opCode": "setTitle", "spec": "Activity setTitle %s", "params": ["$appName"]}
                        ]
                      },
                      {
                        "targetId": "button1",
                        "eventName": "onClick",
                        "blocks": [
                          {"opCode": "toast", "spec": "Toast %s", "params": ["Ação executada com segurança"]}
                        ]
                      }
                    ]
                  },
                  "library": {
                    "useAppCompat": true,
                    "useFirebase": false,
                    "useAdMob": false
                  },
                  "resource": {
                    "stringsXml": "<resources><string name=\"app_name\">$appName</string></resources>",
                    "colorsXml": "<resources><color name=\"colorPrimary\">#2979FF</color><color name=\"colorAccent\">#00E5FF</color></resources>"
                  }
                }
                Inclua widgets e blocos padrão do Sketchware (onCreate, onClick, manipulação segura de arquivos do próprio app) alinhados à descrição do usuário.
            """.trimIndent()

            val payload = JSONObject().apply {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", swbSystemPrompt)))
                })
                put("contents", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put(
                        "text",
                        "Crie a estrutura Sketchware Pro para o app '$appName' ($packageName): $description"
                    )))
                }))
                put("generationConfig", JSONObject().apply {
                    put("responseMimeType", "application/json")
                    put("temperature", 0.25)
                })
            }

            val (_, rawBody) = executeWith404Fallback(cleanKey, payload)
            extractCandidateText(rawBody)
        }
    }

    private fun executeWith404Fallback(cleanKey: String, payload: JSONObject): Pair<String, String> {
        val bodyStr = payload.toString()
        val firstAttempt = postGenerateContent(activeApiVersion, activeModelId, cleanKey, bodyStr)
        if (firstAttempt.isSuccess) {
            return activeModelId to firstAttempt.body
        }

        // If 404 NOT_FOUND, discover an active generateContent model via models.list() and retry
        if (firstAttempt.httpCode == 404) {
            for (version in listOf("v1beta", "v1")) {
                val discoveredModel = discoverActiveModel(version, cleanKey)
                if (discoveredModel != null && (version != activeApiVersion || discoveredModel != activeModelId)) {
                    val retry = postGenerateContent(version, discoveredModel, cleanKey, bodyStr)
                    if (retry.isSuccess) {
                        activeApiVersion = version
                        activeModelId = discoveredModel
                        return discoveredModel to retry.body
                    }
                    if (retry.httpCode != 404) {
                        throw IllegalStateException(
                            formatApiError(retry.httpCode, retry.body, "$version/models/$discoveredModel:generateContent")
                        )
                    }
                }
            }
        }

        throw IllegalStateException(
            formatApiError(
                firstAttempt.httpCode,
                firstAttempt.body,
                "$activeApiVersion/models/$activeModelId:generateContent"
            )
        )
    }

    private data class HttpOutcome(
        val isSuccess: Boolean,
        val httpCode: Int,
        val body: String
    )

    private fun postGenerateContent(
        apiVersion: String,
        modelId: String,
        cleanKey: String,
        jsonBody: String
    ): HttpOutcome {
        val url = buildGenerateContentUrl(apiVersion, modelId, cleanKey)
        val request = Request.Builder()
            .url(url)
            .post(jsonBody.toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            val rawBody = response.body?.string().orEmpty()
            return HttpOutcome(response.isSuccessful, response.code, rawBody)
        }
    }

    private fun discoverActiveModel(apiVersion: String, cleanKey: String): String? {
        return runCatching {
            val url = buildListModelsUrl(apiVersion, cleanKey)
            val request = Request.Builder().url(url).get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@use null
                val raw = response.body?.string().orEmpty()
                pickBestFlashModelFromListJson(raw)
            }
        }.getOrNull()
    }

    private fun extractCandidateText(rawBody: String): String {
        val root = JSONObject(rawBody)
        val candidates = root.optJSONArray("candidates")
            ?: throw IllegalStateException("Resposta vazia da API Gemini.\nResposta: $rawBody")
        if (candidates.length() == 0) {
            val promptFeedback = root.optJSONObject("promptFeedback")?.toString().orEmpty()
            throw IllegalStateException("Nenhum candidato retornado pelo modelo. $promptFeedback\nResposta: $rawBody")
        }
        val first = candidates.getJSONObject(0)
        val finishReason = first.optString("finishReason")
        val content = first.optJSONObject("content")
            ?: throw IllegalStateException("Conteúdo bloqueado ou ausente ($finishReason).\nResposta: $rawBody")
        val parts = content.optJSONArray("parts")
            ?: throw IllegalStateException("Partes de resposta ausentes.\nResposta: $rawBody")
        val builder = StringBuilder()
        for (i in 0 until parts.length()) {
            val text = parts.getJSONObject(i).optString("text")
            if (text.isNotEmpty()) builder.append(text)
        }
        val result = builder.toString().trim()
        if (result.isEmpty()) throw IllegalStateException("Texto de resposta vazio.\nResposta: $rawBody")
        return result
    }
}
