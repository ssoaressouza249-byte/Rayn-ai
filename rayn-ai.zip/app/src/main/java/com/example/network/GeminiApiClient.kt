package com.example.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class GeminiChatTurn(
    val isUser: Boolean,
    val text: String
)

data class GeminiTestResult(
    val success: Boolean,
    val latencyMs: Long,
    val message: String
)

class GeminiApiClient {

    companion object {
        private const val MODEL_ENDPOINT =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"

        val MANDATORY_SYSTEM_INSTRUCTION = """
            Você é a Rayn AI, um assistente avançado de engenharia Android, manipulação de arquivos e arquitetura Sketchware Pro.
            REGRAS DE CONDUTA OBRIGATÓRIAS (PRIORIDADE MÁXIMA):
            a) NUNCA gerar, descrever ou processar conteúdo íntimo, sexual ou NSFW. Recusar imediatamente qualquer pedido desse tipo.
            b) NUNCA criar cheats pesados, hacks, mods maliciosos, aimbots automáticos ou qualquer código destinado a injetar, alterar ou explorar arquivos internos de jogos (Android/data, obb, bibliotecas .so).
            c) PERMITIR a criação de aplicativos legítimos em geral, utilitários visuais inofensivos (como sobreposição simples de mira/crosshair na tela sem interação com arquivos ou memória de jogos) e a organização/salvamento de arquivos do próprio usuário.
            d) Quando o usuário enviar ou descrever um arquivo próprio legítimo e pedir para montar os blocos correspondentes no Sketchware, gerar apenas a estrutura de blocos padrão do Sketchware (onCreate, onClick, manipulação segura de arquivos do próprio app).
            
            INSTRUÇÕES DE MANIPULAÇÃO E SALVAMENTO DE ARQUIVOS NO CHAT:
            Quando o usuário pedir para criar, editar, corrigir ou converter um arquivo (ou pedir para salvar em uma pasta/subpasta), responda de forma clara em português e inclua EXATAMENTE o bloco estruturado abaixo contendo o arquivo completo pronto para gravação direta:
            <<<RAYN_FILE_START>>>
            FILENAME: nome_exato_com_extensao.ext
            SUBFOLDER: subpasta_opcional_ou_vazio
            AUTO_SAVE: true_ou_false
            <<<CONTENT>>>
            conteúdo completo do arquivo aqui
            <<<RAYN_FILE_END>>>
            Defina AUTO_SAVE como true sempre que o usuário pedir explicitamente para salvar/gravar o arquivo na pasta.
        """.trimIndent()
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun testConnection(apiKey: String): GeminiTestResult = withContext(Dispatchers.IO) {
        val trimmedKey = apiKey.trim()
        if (trimmedKey.isBlank()) {
            return@withContext GeminiTestResult(
                success = false,
                latencyMs = 0L,
                message = "Informe uma GEMINI_API_KEY válida antes de testar."
            )
        }

        val start = System.currentTimeMillis()
        try {
            val payload = JSONObject().apply {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", MANDATORY_SYSTEM_INSTRUCTION)))
                })
                put("contents", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", "Responda apenas: RAYN_ONLINE_OK")))
                }))
                put("generationConfig", JSONObject().apply {
                    put("maxOutputTokens", 32)
                    put("temperature", 0.1)
                })
            }

            val request = Request.Builder()
                .url("$MODEL_ENDPOINT?key=$trimmedKey")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val latency = System.currentTimeMillis() - start
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val apiError = extractApiError(rawBody, response.code)
                    return@withContext GeminiTestResult(false, latency, apiError)
                }
                val text = extractCandidateText(rawBody)
                return@withContext GeminiTestResult(
                    success = true,
                    latencyMs = latency,
                    message = "Conectado ao gemini-2.5-flash (${latency}ms): ${text.take(60)}"
                )
            }
        } catch (e: Exception) {
            val latency = System.currentTimeMillis() - start
            return@withContext GeminiTestResult(
                success = false,
                latencyMs = latency,
                message = "Falha de rede: ${e.localizedMessage ?: "Erro desconhecido"}"
            )
        }
    }

    suspend fun generateChatReply(
        apiKey: String,
        history: List<GeminiChatTurn>,
        userPrompt: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val trimmedKey = apiKey.trim()
            require(trimmedKey.isNotBlank()) {
                "GEMINI_API_KEY não configurada. Acesse a aba Ajustes para inserir e testar sua chave."
            }

            val contentsArray = JSONArray()
            history.takeLast(12).forEach { turn ->
                contentsArray.put(JSONObject().apply {
                    put("role", if (turn.isUser) "user" else "model")
                    put("parts", JSONArray().put(JSONObject().put("text", turn.text)))
                })
            }
            contentsArray.put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", userPrompt)))
            })

            val payload = JSONObject().apply {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", MANDATORY_SYSTEM_INSTRUCTION)))
                })
                put("contents", contentsArray)
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.35)
                })
            }

            val request = Request.Builder()
                .url("$MODEL_ENDPOINT?key=$trimmedKey")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw IllegalStateException(extractApiError(rawBody, response.code))
                }
                extractCandidateText(rawBody)
            }
        }
    }

    suspend fun generateSwbBlueprintJson(
        apiKey: String,
        appName: String,
        packageName: String,
        description: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val trimmedKey = apiKey.trim()
            require(trimmedKey.isNotBlank()) {
                "GEMINI_API_KEY não configurada. Acesse a aba Ajustes para configurar sua chave."
            }

            val swbSystemPrompt = """
                $MANDATORY_SYSTEM_INSTRUCTION
                
                TAREFA ESPECÍFICA:
                Gere um JSON estritamente válido para empacotamento de um projeto Sketchware Pro (.swb).
                Se o pedido violar as regras a) ou b), retorne um JSON com {"rejected": true, "reason": "motivo"}.
                Caso contrário, retorne um JSON com exatamente as chaves:
                {
                  "rejected": false,
                  "project": {
                    "my_app_name": "$appName",
                    "my_sc_pkg_name": "$packageName",
                    "my_ws_name": "$appName",
                    "sc_ver_code": "1",
                    "sc_ver_name": "1.0",
                    "color_primary": "#2979FF",
                    "color_primary_dark": "#06080F",
                    "color_accent": "#00E5FF"
                  },
                  "file": {
                    "activities": [
                      {"fileName": "main", "type": 1, "orientation": 1, "theme": 0}
                    ],
                    "customViews": []
                  },
                  "view": {
                    "mainXml": "<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\" android:layout_width=\"match_parent\" android:layout_height=\"match_parent\" android:orientation=\"vertical\" android:padding=\"16dp\" android:background=\"#06080F\">...</LinearLayout>",
                    "widgets": [
                      {"id": "textview1", "type": "TextView", "text": "$appName"},
                      {"id": "button1", "type": "Button", "text": "Executar"}
                    ]
                  },
                  "logic": {
                    "events": [
                      {
                        "targetId": "main",
                        "eventName": "onCreate",
                        "blocks": [
                          {"opCode": "setTitle", "spec": "Activity setTitle %s", "params": ["$appName"]}
                        ]
                      },
                      {
                        "targetId": "button1",
                        "eventName": "onClick",
                        "blocks": [
                          {"opCode": "toast", "spec": "Toast %s", "params": ["Ação executada com segurança"]}
                        ]
                      }
                    ]
                  },
                  "library": {
                    "useAppCompat": true,
                    "useFirebase": false,
                    "useAdMob": false
                  },
                  "resource": {
                    "stringsXml": "<resources><string name=\"app_name\">$appName</string></resources>",
                    "colorsXml": "<resources><color name=\"colorPrimary\">#2979FF</color><color name=\"colorAccent\">#00E5FF</color></resources>"
                  }
                }
                Inclua widgets e blocos padrão do Sketchware (onCreate, onClick, manipulação segura de arquivos do próprio app) alinhados à descrição do usuário.
            """.trimIndent()

            val payload = JSONObject().apply {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", swbSystemPrompt)))
                })
                put("contents", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put(
                        "text",
                        "Crie a estrutura Sketchware Pro para o app '$appName' ($packageName): $description"
                    )))
                }))
                put("generationConfig", JSONObject().apply {
                    put("responseMimeType", "application/json")
                    put("temperature", 0.25)
                })
            }

            val request = Request.Builder()
                .url("$MODEL_ENDPOINT?key=$trimmedKey")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw IllegalStateException(extractApiError(rawBody, response.code))
                }
                extractCandidateText(rawBody)
            }
        }
    }

    private fun extractCandidateText(rawBody: String): String {
        val root = JSONObject(rawBody)
        val candidates = root.optJSONArray("candidates")
            ?: throw IllegalStateException("Resposta vazia da API Gemini.")
        if (candidates.length() == 0) {
            val promptFeedback = root.optJSONObject("promptFeedback")?.toString().orEmpty()
            throw IllegalStateException("Nenhum candidato retornado pelo modelo. $promptFeedback")
        }
        val first = candidates.getJSONObject(0)
        val finishReason = first.optString("finishReason")
        val content = first.optJSONObject("content")
            ?: throw IllegalStateException("Conteúdo bloqueado ou ausente ($finishReason).")
        val parts = content.optJSONArray("parts")
            ?: throw IllegalStateException("Partes de resposta ausentes.")
        val builder = StringBuilder()
        for (i in 0 until parts.length()) {
            val text = parts.getJSONObject(i).optString("text")
            if (text.isNotEmpty()) builder.append(text)
        }
        val result = builder.toString().trim()
        if (result.isEmpty()) throw IllegalStateException("Texto de resposta vazio.")
        return result
    }

    private fun extractApiError(rawBody: String, code: Int): String {
        val parsedMsg = runCatching {
            JSONObject(rawBody).optJSONObject("error")?.optString("message")
        }.getOrNull()
        return if (!parsedMsg.isNullOrBlank()) {
            "Erro Gemini ($code): $parsedMsg"
        } else {
            "Erro HTTP $code na API Gemini."
        }
    }
}
