package com.example.network

import com.example.data.GeminiModelInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class PingResult(
    val isOnline: Boolean,
    val latencyMs: Long,
    val modelId: String,
    val message: String,
)

data class ChatTurn(
    val isUser: Boolean,
    val text: String,
    val attachmentName: String? = null,
    val attachmentContent: String? = null,
)

data class SwbAiSpec(
    val screenTitle: String,
    val primaryColorHex: String,
    val buttonLabel: String,
    val statusText: String,
    val toastMessage: String,
    val enableInputField: Boolean,
    val isCrosshairUtility: Boolean,
    val extraLogicComment: String,
)

object PolicyGuard {
    private val nsfwKeywords = listOf(
        "porn", "porno", "pornografia", "sexo explícito", "nudez", "nsfw", "erótico",
        "erotico", "hentai", "xxx", "onlyfans", "conteúdo sexual", "conteudo sexual"
    )

    private val maliciousCheatKeywords = listOf(
        "aimbot", "wallhack", "esp hack", "speedhack", "god mode", "injetar .so",
        "inject .so", "memory hack", "gameguardian", "il2cpp dump", "mod menu cheat",
        "bypass anti-cheat", "bypass anticheat", "alterar android/data", "modificar obb",
        "editar obb", "injetar obb", "hook libil2cpp", "auto headshot"
    )

    fun checkPromptViolation(prompt: String): String? {
        val lower = prompt.lowercase()
        if (nsfwKeywords.any { lower.contains(it) }) {
            return "Bloqueado pela Política do Rayn AI: conteúdo íntimo, sexual ou NSFW não é permitido."
        }
        if (maliciousCheatKeywords.any { lower.contains(it) }) {
            return "Bloqueado pela Política do Rayn AI: cheats pesados, aimbots automáticos, hacks ou injeção/alteração em Android/data, obb ou .so não são permitidos."
        }
        return null
    }
}

class GeminiRestClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    companion object {
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

        val SYSTEM_INSTRUCTION = """
            Você é o Rayn AI, um assistente técnico especialista em desenvolvimento Android (Kotlin, Jetpack Compose, XML, JSON) e projetos do Sketchware Pro (.swb).
            Responda sempre em Português do Brasil de forma objetiva, técnica e útil.

            REGRAS DE CONDUTA INVIOLÁVEIS:
            1. NUNCA gerar, descrever ou processar conteúdo íntimo, sexual, erótico ou NSFW. Recuse imediatamente se solicitado.
            2. NUNCA criar cheats pesados, hacks, mods maliciosos, aimbots automáticos, wallhacks ou códigos para injetar/alterar arquivos internos de jogos (Android/data, obb, arquivos .so ou memória de outros apps). Recuse imediatamente se solicitado.
            3. PERMITA normalmente: aplicativos Android legítimos em geral, utilitários visuais inofensivos (como uma mira/crosshair flutuante visual simples sem tocar em arquivos, memória ou processos de jogos), leitura/edição/conversão de arquivos (.txt, .json, .xml, .kt, .html, .csv) e montagem de blocos padrão do Sketchware Pro (onCreate, onClick, widgets, intents) para projetos legítimos enviados pelo usuário.

            SALVAMENTO DE ARQUIVOS:
            Quando o usuário pedir para criar, editar, converter ou salvar um arquivo para a pasta padrão, inclua o conteúdo pronto do arquivo delimitado exatamente assim:
            ===FILE:nome_com_extensao.ext===
            conteudo_completo_aqui
            ===END_FILE===
            (Substitua nome_com_extensao.ext pelo nome real pedido, ex: config.json, MainActivity.kt, dados.csv).
        """.trimIndent()
    }

    suspend fun listActiveModels(apiKey: String): Result<List<GeminiModelInfo>> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanKey = apiKey.trim()
            require(cleanKey.isNotBlank()) { "Informe uma GEMINI_API_KEY válida." }

            val collected = mutableListOf<GeminiModelInfo>()
            var pageToken: String? = null

            do {
                val urlBuilder = StringBuilder("$BASE_URL/models?pageSize=100&key=$cleanKey")
                if (!pageToken.isNullOrBlank()) {
                    urlBuilder.append("&pageToken=").append(pageToken)
                }

                val request = Request.Builder()
                    .url(urlBuilder.toString())
                    .get()
                    .build()

                client.newCall(request).execute().use { response ->
                    val bodyStr = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        val errMsg = parseApiError(bodyStr, response.code)
                        error("Erro ao consultar modelos (HTTP ${response.code}): $errMsg")
                    }

                    val root = JSONObject(bodyStr)
                    val arr = root.optJSONArray("models") ?: JSONArray()
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        val methods = item.optJSONArray("supportedGenerationMethods") ?: JSONArray()
                        val supportsGenerate = (0 until methods.length()).any {
                            methods.optString(it) == "generateContent"
                        }
                        if (!supportsGenerate) continue

                        val fullName = item.optString("name")
                        val modelId = fullName.removePrefix("models/")
                        if (modelId.isBlank()) continue

                        collected.add(
                            GeminiModelInfo(
                                id = modelId,
                                displayName = item.optString("displayName").ifBlank { modelId },
                                description = item.optString("description"),
                                inputTokenLimit = item.optInt("inputTokenLimit"),
                                outputTokenLimit = item.optInt("outputTokenLimit"),
                            )
                        )
                    }
                    pageToken = root.optString("nextPageToken").takeIf { it.isNotBlank() }
                }
            } while (pageToken != null)

            if (collected.isEmpty()) {
                error("Nenhum modelo com suporte a generateContent foi retornado para esta chave.")
            }

            collected.sortedWith(
                compareByDescending<GeminiModelInfo> { it.id.contains("flash", ignoreCase = true) }
                    .thenByDescending { it.id.contains("2.5") || it.id.contains("3.") }
                    .thenBy { it.id }
            )
        }
    }

    suspend fun testConnection(apiKey: String, modelId: String): PingResult = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        val cleanModel = modelId.removePrefix("models/").trim()
        if (cleanKey.isBlank() || cleanModel.isBlank()) {
            return@withContext PingResult(
                isOnline = false,
                latencyMs = 0L,
                modelId = cleanModel,
                message = "Chave API ou modelo não configurado."
            )
        }

        val startNs = System.nanoTime()
        return@withContext try {
            val payload = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", "Responda apenas: OK"))
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("maxOutputTokens", 12)
                    put("temperature", 0.0)
                })
            }

            val request = Request.Builder()
                .url("$BASE_URL/models/$cleanModel:generateContent?key=$cleanKey")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val elapsedMs = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val err = parseApiError(bodyStr, response.code)
                    PingResult(
                        isOnline = false,
                        latencyMs = elapsedMs,
                        modelId = cleanModel,
                        message = "HTTP ${response.code}: $err"
                    )
                } else {
                    val text = extractCandidateText(bodyStr).ifBlank { "OK" }
                    PingResult(
                        isOnline = true,
                        latencyMs = elapsedMs,
                        modelId = cleanModel,
                        message = "IA Online ($cleanModel) • Resposta: ${text.take(30)}"
                    )
                }
            }
        } catch (e: Exception) {
            val elapsedMs = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
            PingResult(
                isOnline = false,
                latencyMs = elapsedMs,
                modelId = cleanModel,
                message = e.localizedMessage ?: "Falha de rede ao conectar à API Gemini."
            )
        }
    }

    suspend fun generateChat(
        apiKey: String,
        modelId: String,
        history: List<ChatTurn>,
        attachmentName: String?,
        attachmentContent: String?,
        userPrompt: String,
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val violation = PolicyGuard.checkPromptViolation(
                "$userPrompt\n${attachmentContent.orEmpty().take(3000)}"
            )
            if (violation != null) {
                error(violation)
            }

            val cleanKey = apiKey.trim()
            val cleanModel = modelId.removePrefix("models/").trim()
            require(cleanKey.isNotBlank()) { "Configure sua GEMINI_API_KEY na aba Ajustes." }
            require(cleanModel.isNotBlank()) { "Selecione um modelo ativo na aba Ajustes." }

            val contents = JSONArray()
            history.takeLast(10).forEach { turn ->
                contents.put(
                    JSONObject().apply {
                        put("role", if (turn.isUser) "user" else "model")
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", turn.text))
                        })
                    }
                )
            }

            val fullUserText = buildString {
                if (!attachmentName.isNullOrBlank() && !attachmentContent.isNullOrBlank()) {
                    appendLine("[ARQUIVO ANEXADO: $attachmentName]")
                    appendLine("```")
                    appendLine(attachmentContent.take(60_000))
                    appendLine("```")
                    appendLine()
                }
                append(userPrompt)
            }

            contents.put(
                JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", fullUserText))
                    })
                }
            )

            val payload = JSONObject().apply {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", SYSTEM_INSTRUCTION))
                    })
                })
                put("contents", contents)
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.5)
                    put("maxOutputTokens", 4096)
                })
            }

            val request = Request.Builder()
                .url("$BASE_URL/models/$cleanModel:generateContent?key=$cleanKey")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val err = parseApiError(bodyStr, response.code)
                    error("Erro Gemini (HTTP ${response.code}): $err")
                }
                val text = extractCandidateText(bodyStr)
                if (text.isBlank()) {
                    error("A resposta foi bloqueada pelos filtros de segurança ou retornou vazia.")
                }
                text
            }
        }
    }

    suspend fun generateSwbSpec(
        apiKey: String,
        modelId: String,
        appName: String,
        packageName: String,
        description: String,
    ): Result<SwbAiSpec> = withContext(Dispatchers.IO) {
        runCatching {
            val violation = PolicyGuard.checkPromptViolation("$appName $description")
            if (violation != null) {
                error(violation)
            }

            val cleanKey = apiKey.trim()
            val cleanModel = modelId.removePrefix("models/").trim()
            require(cleanKey.isNotBlank()) { "Configure sua GEMINI_API_KEY na aba Ajustes para usar geração com IA." }
            require(cleanModel.isNotBlank()) { "Selecione um modelo ativo na aba Ajustes." }

            val prompt = """
                Gere exclusivamente um JSON válido (sem markdown) especificando um projeto legítimo do Sketchware Pro:
                Nome do app: "$appName"
                Pacote: "$packageName"
                Descrição do usuário: "$description"

                Campos obrigatórios do JSON:
                {
                  "screenTitle": "Título da MainActivity",
                  "primaryColorHex": "#00E5FF",
                  "buttonLabel": "Texto do botão principal (ex: Ativar / Executar)",
                  "statusText": "Texto inicial do TextView de status",
                  "toastMessage": "Mensagem exibida no evento onClick",
                  "enableInputField": true,
                  "isCrosshairUtility": false,
                  "extraLogicComment": "Resumo curto dos blocos onCreate e onClick"
                }
            """.trimIndent()

            val payload = JSONObject().apply {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", SYSTEM_INSTRUCTION))
                    })
                })
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", prompt))
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.3)
                    put("responseMimeType", "application/json")
                })
            }

            val request = Request.Builder()
                .url("$BASE_URL/models/$cleanModel:generateContent?key=$cleanKey")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val err = parseApiError(bodyStr, response.code)
                    error("Erro Gemini (HTTP ${response.code}): $err")
                }
                val raw = extractCandidateText(bodyStr)
                    .removePrefix("```json")
                    .removePrefix("```")
                    .removeSuffix("```")
                    .trim()
                val json = JSONObject(raw)
                SwbAiSpec(
                    screenTitle = json.optString("screenTitle").ifBlank { appName },
                    primaryColorHex = json.optString("primaryColorHex").ifBlank { "#00E5FF" },
                    buttonLabel = json.optString("buttonLabel").ifBlank { "Executar Ação" },
                    statusText = json.optString("statusText").ifBlank { "$appName pronto." },
                    toastMessage = json.optString("toastMessage").ifBlank { "Ação executada com sucesso!" },
                    enableInputField = json.optBoolean("enableInputField", true),
                    isCrosshairUtility = json.optBoolean("isCrosshairUtility", false),
                    extraLogicComment = json.optString("extraLogicComment").ifBlank { "Blocos onCreate + onClick configurados." },
                )
            }
        }
    }

    private fun extractCandidateText(bodyStr: String): String {
        val root = JSONObject(bodyStr)
        val candidates = root.optJSONArray("candidates") ?: return ""
        if (candidates.length() == 0) return ""
        val content = candidates.getJSONObject(0).optJSONObject("content") ?: return ""
        val parts = content.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val partText = parts.getJSONObject(i).optString("text")
            if (partText.isNotEmpty()) sb.append(partText)
        }
        return sb.toString().trim()
    }

    private fun parseApiError(bodyStr: String, code: Int): String {
        return runCatching {
            val json = JSONObject(bodyStr)
            json.optJSONObject("error")?.optString("message").orEmpty().ifBlank { "Erro HTTP $code" }
        }.getOrDefault("Erro HTTP $code")
    }
}
