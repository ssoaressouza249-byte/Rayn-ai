package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.raynDataStore: DataStore<Preferences> by preferencesDataStore(name = "rayn_ai_prefs")

data class RaynPreferencesState(
    val swbCredits: Int = RaynPreferencesRepository.MAX_SWB_CREDITS,
    val cooldownStartTimestamp: Long = 0L,
    val geminiApiKey: String = "",
    val safFolderUri: String? = null,
    val safFolderDisplay: String? = null,
    val baselineCertSha256: String? = null
)

class RaynPreferencesRepository(
    private val context: Context,
    private val timeProvider: () -> Long = { System.currentTimeMillis() }
) {
    companion object {
        const val MAX_SWB_CREDITS = 15
        const val COOLDOWN_DURATION_MS = 54_000_000L // 15 hours (15 * 60 * 60 * 1000)

        private val KEY_SWB_CREDITS = intPreferencesKey("swb_credits")
        private val KEY_COOLDOWN_START = longPreferencesKey("cooldown_start_timestamp")
        private val KEY_GEMINI_API_KEY = stringPreferencesKey("gemini_api_key")
        private val KEY_SAF_FOLDER_URI = stringPreferencesKey("saf_folder_uri")
        private val KEY_SAF_FOLDER_DISPLAY = stringPreferencesKey("saf_folder_display")
        private val KEY_BASELINE_CERT_SHA256 = stringPreferencesKey("baseline_cert_sha256")
    }

    val preferencesFlow: Flow<RaynPreferencesState> = context.raynDataStore.data.map { prefs ->
        RaynPreferencesState(
            swbCredits = prefs[KEY_SWB_CREDITS] ?: MAX_SWB_CREDITS,
            cooldownStartTimestamp = prefs[KEY_COOLDOWN_START] ?: 0L,
            geminiApiKey = prefs[KEY_GEMINI_API_KEY] ?: "",
            safFolderUri = prefs[KEY_SAF_FOLDER_URI]?.takeIf { it.isNotBlank() },
            safFolderDisplay = prefs[KEY_SAF_FOLDER_DISPLAY]?.takeIf { it.isNotBlank() },
            baselineCertSha256 = prefs[KEY_BASELINE_CERT_SHA256]?.takeIf { it.isNotBlank() }
        )
    }

    suspend fun getSnapshot(): RaynPreferencesState = preferencesFlow.first()

    suspend fun saveGeminiApiKey(apiKey: String) {
        context.raynDataStore.edit { prefs ->
            prefs[KEY_GEMINI_API_KEY] = apiKey.trim()
        }
    }

    suspend fun saveSafFolder(uri: String, displayPath: String) {
        context.raynDataStore.edit { prefs ->
            prefs[KEY_SAF_FOLDER_URI] = uri
            prefs[KEY_SAF_FOLDER_DISPLAY] = displayPath
        }
    }

    suspend fun getOrRecordBaselineCertSha256(currentHash: String): String {
        var resolved = currentHash
        context.raynDataStore.edit { prefs ->
            val existing = prefs[KEY_BASELINE_CERT_SHA256]
            if (existing.isNullOrBlank() && currentHash.isNotBlank()) {
                prefs[KEY_BASELINE_CERT_SHA256] = currentHash
                resolved = currentHash
            } else if (!existing.isNullOrBlank()) {
                resolved = existing
            }
        }
        return resolved
    }

    suspend fun refreshCreditsIfCooldownExpired(): Boolean {
        var restored = false
        val now = timeProvider()
        context.raynDataStore.edit { prefs ->
            val currentCredits = prefs[KEY_SWB_CREDITS] ?: MAX_SWB_CREDITS
            val cooldownStart = prefs[KEY_COOLDOWN_START] ?: 0L
            if (currentCredits <= 0 && cooldownStart > 0L && (now - cooldownStart) >= COOLDOWN_DURATION_MS) {
                prefs[KEY_SWB_CREDITS] = MAX_SWB_CREDITS
                prefs[KEY_COOLDOWN_START] = 0L
                restored = true
            }
        }
        return restored
    }

    suspend fun consumeSwbCredit(): Boolean {
        refreshCreditsIfCooldownExpired()
        var consumed = false
        val now = timeProvider()
        context.raynDataStore.edit { prefs ->
            val current = prefs[KEY_SWB_CREDITS] ?: MAX_SWB_CREDITS
            if (current > 0) {
                val updated = current - 1
                prefs[KEY_SWB_CREDITS] = updated
                if (updated == 0) {
                    prefs[KEY_COOLDOWN_START] = now
                }
                consumed = true
            }
        }
        return consumed
    }

    fun calculateRemainingCooldownMs(state: RaynPreferencesState): Long {
        if (state.swbCredits > 0 || state.cooldownStartTimestamp <= 0L) return 0L
        val elapsed = timeProvider() - state.cooldownStartTimestamp
        return (COOLDOWN_DURATION_MS - elapsed).coerceAtLeast(0L)
    }
}
