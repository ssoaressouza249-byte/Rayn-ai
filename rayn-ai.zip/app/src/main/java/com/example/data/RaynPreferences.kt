package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.raynDataStore: DataStore<Preferences> by preferencesDataStore(name = "rayn_ai_prefs")

data class GeminiModelInfo(
    val id: String,
    val displayName: String,
    val description: String,
    val inputTokenLimit: Int = 0,
    val outputTokenLimit: Int = 0,
)

data class RaynSettingsState(
    val geminiApiKey: String = "",
    val selectedModel: String = "",
    val availableModels: List<GeminiModelInfo> = emptyList(),
    val savedFolderUri: String = "",
    val swbCredits: Int = MAX_SWB_CREDITS,
    val cooldownStartTimestamp: Long = 0L,
    val storedCertSha256: String = "",
) {
    companion object {
        const val MAX_SWB_CREDITS = 15
        const val COOLDOWN_DURATION_MS = 54_000_000L // 15 horas exatas
    }
}

class RaynPreferences(private val context: Context) {

    private object Keys {
        val GEMINI_API_KEY = stringPreferencesKey("gemini_api_key")
        val SELECTED_MODEL = stringPreferencesKey("selected_model")
        val AVAILABLE_MODELS_JSON = stringPreferencesKey("available_models_json")
        val SAVED_FOLDER_URI = stringPreferencesKey("saved_folder_uri")
        val SWB_CREDITS = intPreferencesKey("swb_credits")
        val COOLDOWN_START_TIMESTAMP = longPreferencesKey("cooldown_start_timestamp")
        val SIGNING_CERT_SHA256 = stringPreferencesKey("signing_cert_sha256")
    }

    val stateFlow: Flow<RaynSettingsState> = context.raynDataStore.data.map { prefs ->
        RaynSettingsState(
            geminiApiKey = prefs[Keys.GEMINI_API_KEY].orEmpty(),
            selectedModel = prefs[Keys.SELECTED_MODEL].orEmpty(),
            availableModels = decodeModels(prefs[Keys.AVAILABLE_MODELS_JSON].orEmpty()),
            savedFolderUri = prefs[Keys.SAVED_FOLDER_URI].orEmpty(),
            swbCredits = prefs[Keys.SWB_CREDITS] ?: RaynSettingsState.MAX_SWB_CREDITS,
            cooldownStartTimestamp = prefs[Keys.COOLDOWN_START_TIMESTAMP] ?: 0L,
            storedCertSha256 = prefs[Keys.SIGNING_CERT_SHA256].orEmpty(),
        )
    }

    suspend fun getSnapshot(): RaynSettingsState = stateFlow.first()

    suspend fun saveApiKeyAndModels(
        apiKey: String,
        models: List<GeminiModelInfo>,
        selectedModel: String
    ) {
        context.raynDataStore.edit { prefs ->
            prefs[Keys.GEMINI_API_KEY] = apiKey.trim()
            prefs[Keys.AVAILABLE_MODELS_JSON] = encodeModels(models)
            prefs[Keys.SELECTED_MODEL] = selectedModel
        }
    }

    suspend fun saveSelectedModel(modelId: String) {
        context.raynDataStore.edit { prefs ->
            prefs[Keys.SELECTED_MODEL] = modelId
        }
    }

    suspend fun saveApiKeyOnly(apiKey: String) {
        context.raynDataStore.edit { prefs ->
            prefs[Keys.GEMINI_API_KEY] = apiKey.trim()
        }
    }

    suspend fun saveFolderUri(uriString: String) {
        context.raynDataStore.edit { prefs ->
            prefs[Keys.SAVED_FOLDER_URI] = uriString
        }
    }

    suspend fun saveInitialSigningCertSha256(sha256: String) {
        context.raynDataStore.edit { prefs ->
            if (prefs[Keys.SIGNING_CERT_SHA256].isNullOrEmpty()) {
                prefs[Keys.SIGNING_CERT_SHA256] = sha256
            }
        }
    }

    suspend fun consumeSwbCredit(nowMs: Long = System.currentTimeMillis()): Boolean {
        var consumed = false
        context.raynDataStore.edit { prefs ->
            val current = prefs[Keys.SWB_CREDITS] ?: RaynSettingsState.MAX_SWB_CREDITS
            if (current > 0) {
                val updated = current - 1
                prefs[Keys.SWB_CREDITS] = updated
                if (updated == 0) {
                    val existingStart = prefs[Keys.COOLDOWN_START_TIMESTAMP] ?: 0L
                    if (existingStart == 0L) {
                        prefs[Keys.COOLDOWN_START_TIMESTAMP] = nowMs
                    }
                }
                consumed = true
            }
        }
        return consumed
    }

    suspend fun restoreCreditsIfCooldownElapsed(nowMs: Long = System.currentTimeMillis()): Boolean {
        var restored = false
        context.raynDataStore.edit { prefs ->
            val credits = prefs[Keys.SWB_CREDITS] ?: RaynSettingsState.MAX_SWB_CREDITS
            val startTs = prefs[Keys.COOLDOWN_START_TIMESTAMP] ?: 0L
            if (credits <= 0 && startTs > 0L && (nowMs - startTs) >= RaynSettingsState.COOLDOWN_DURATION_MS) {
                prefs[Keys.SWB_CREDITS] = RaynSettingsState.MAX_SWB_CREDITS
                prefs[Keys.COOLDOWN_START_TIMESTAMP] = 0L
                restored = true
            } else if (credits <= 0 && startTs == 0L) {
                prefs[Keys.COOLDOWN_START_TIMESTAMP] = nowMs
            }
        }
        return restored
    }

    private fun encodeModels(models: List<GeminiModelInfo>): String {
        val arr = JSONArray()
        models.forEach { m ->
            arr.put(
                JSONObject().apply {
                    put("id", m.id)
                    put("displayName", m.displayName)
                    put("description", m.description)
                    put("inputTokenLimit", m.inputTokenLimit)
                    put("outputTokenLimit", m.outputTokenLimit)
                }
            )
        }
        return arr.toString()
    }

    private fun decodeModels(json: String): List<GeminiModelInfo> {
        if (json.isBlank()) return emptyList()
        return runCatching {
            val arr = JSONArray(json)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    add(
                        GeminiModelInfo(
                            id = obj.optString("id"),
                            displayName = obj.optString("displayName"),
                            description = obj.optString("description"),
                            inputTokenLimit = obj.optInt("inputTokenLimit"),
                            outputTokenLimit = obj.optInt("outputTokenLimit"),
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }
}
