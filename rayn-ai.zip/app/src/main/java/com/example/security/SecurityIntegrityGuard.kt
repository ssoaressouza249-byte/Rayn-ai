package com.example.security

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import com.example.R
import com.example.data.RaynPreferencesRepository
import java.security.MessageDigest

data class IntegrityReport(
    val isValid: Boolean,
    val detectedPackageName: String,
    val detectedAppName: String,
    val currentCertSha256: String,
    val expectedCertSha256: String,
    val failureReason: String? = null
)

class SecurityIntegrityGuard(
    private val context: Context,
    private val preferencesRepository: RaynPreferencesRepository
) {
    companion object {
        const val EXPECTED_PACKAGE_NAME = "com.raynai.assistant.pro"
        const val EXPECTED_APP_NAME = "Rayn AI"
        const val TAMPER_ALERT_MESSAGE =
            "ALERTA DE SEGURANÇA: Modificação não autorizada detectada no Rayn AI. Execução bloqueada."

        fun evaluateIntegrity(
            detectedPackageName: String,
            stringResourceAppName: String,
            manifestLabelAppName: String,
            currentCertSha256: String,
            expectedCertSha256: String
        ): IntegrityReport {
            val effectiveLabel = if (manifestLabelAppName == stringResourceAppName) {
                stringResourceAppName
            } else {
                "$stringResourceAppName / $manifestLabelAppName"
            }

            val failure = when {
                detectedPackageName != EXPECTED_PACKAGE_NAME ->
                    "Package Name adulterado: esperado '$EXPECTED_PACKAGE_NAME', encontrado '$detectedPackageName'."
                stringResourceAppName != EXPECTED_APP_NAME || manifestLabelAppName != EXPECTED_APP_NAME ->
                    "Nome oficial do aplicativo modificado: esperado '$EXPECTED_APP_NAME', encontrado '$effectiveLabel'."
                currentCertSha256.isBlank() ->
                    "Certificado de assinatura do APK ausente ou ilegível."
                expectedCertSha256.isNotBlank() && !currentCertSha256.equals(expectedCertSha256, ignoreCase = true) ->
                    "Assinatura SHA-256 adulterada! Hash divergente do certificado original."
                else -> null
            }

            return IntegrityReport(
                isValid = failure == null,
                detectedPackageName = detectedPackageName,
                detectedAppName = effectiveLabel,
                currentCertSha256 = currentCertSha256,
                expectedCertSha256 = expectedCertSha256,
                failureReason = failure
            )
        }

        fun sha256Hex(bytes: ByteArray): String {
            val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
            return digest.joinToString(":") { "%02X".format(it) }
        }
    }

    suspend fun verifyIntegrity(): IntegrityReport {
        val detectedPackage = context.packageName
        val resourceName = runCatching { context.getString(R.string.app_name) }.getOrDefault("")
        val manifestLabel = runCatching {
            val appInfo = context.packageManager.getApplicationInfo(detectedPackage, 0)
            context.packageManager.getApplicationLabel(appInfo).toString()
        }.getOrDefault(resourceName)

        val currentCertHash = readSigningCertificateSha256()
        val expectedCertHash = if (currentCertHash.isNotBlank()) {
            preferencesRepository.getOrRecordBaselineCertSha256(currentCertHash)
        } else {
            preferencesRepository.getSnapshot().baselineCertSha256.orEmpty()
        }

        return evaluateIntegrity(
            detectedPackageName = detectedPackage,
            stringResourceAppName = resourceName,
            manifestLabelAppName = manifestLabel,
            currentCertSha256 = currentCertHash,
            expectedCertSha256 = expectedCertHash
        )
    }

    @Suppress("DEPRECATION")
    private fun readSigningCertificateSha256(): String {
        return runCatching {
            val pm = context.packageManager
            val pkgInfo: PackageInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pm.getPackageInfo(
                    context.packageName,
                    PackageManager.GET_SIGNING_CERTIFICATES
                )
            } else {
                pm.getPackageInfo(
                    context.packageName,
                    PackageManager.GET_SIGNATURES
                )
            }

            val certBytes: ByteArray? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val signingInfo = pkgInfo.signingInfo
                val signers = signingInfo?.apkContentsSigners
                    ?: signingInfo?.signingCertificateHistory
                signers?.firstOrNull()?.toByteArray()
            } else {
                pkgInfo.signatures?.firstOrNull()?.toByteArray()
            }

            if (certBytes != null && certBytes.isNotEmpty()) {
                sha256Hex(certBytes)
            } else {
                // Fallback deterministic identifier only if test runner provides empty signatures
                ""
            }
        }.getOrDefault("")
    }
}
