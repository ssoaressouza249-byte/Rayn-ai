package com.example.security

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.example.R
import com.example.data.RaynPreferences
import java.security.MessageDigest

data class IntegrityReport(
    val isValid: Boolean,
    val packageName: String,
    val expectedPackageName: String,
    val appLabel: String,
    val expectedAppLabel: String,
    val currentCertSha256: String,
    val storedCertSha256: String,
    val failureReason: String? = null,
    val checkedAtMs: Long = System.currentTimeMillis(),
)

object SecurityIntegrityGuard {

    const val EXPECTED_PACKAGE_NAME = "com.raynai.assistant.pro"
    const val EXPECTED_APP_NAME = "Rayn AI"

    suspend fun verifyIntegrity(
        context: Context,
        preferences: RaynPreferences
    ): IntegrityReport {
        val currentPackage = context.packageName
        val currentLabel = runCatching {
            context.applicationInfo.loadLabel(context.packageManager).toString()
        }.getOrDefault("")
        val stringLabel = runCatching {
            context.getString(R.string.app_name)
        }.getOrDefault("")

        val currentSha256 = readAppSigningCertSha256(context)
        val snapshot = preferences.getSnapshot()
        var storedSha256 = snapshot.storedCertSha256

        if (storedSha256.isBlank() && currentSha256.isNotBlank() && currentSha256 != "INDISPONÍVEL") {
            preferences.saveInitialSigningCertSha256(currentSha256)
            storedSha256 = currentSha256
        }

        val failureReason = when {
            currentPackage != EXPECTED_PACKAGE_NAME ->
                "Pacote adulterado detectado: $currentPackage (esperado: $EXPECTED_PACKAGE_NAME)"
            currentLabel != EXPECTED_APP_NAME || stringLabel != EXPECTED_APP_NAME ->
                "Nome oficial alterado: \"$currentLabel\" / \"$stringLabel\" (esperado: \"$EXPECTED_APP_NAME\")"
            currentSha256.isBlank() || currentSha256 == "INDISPONÍVEL" ->
                "Certificado de assinatura do APK não encontrado ou inválido."
            storedSha256.isNotBlank() && !storedSha256.equals(currentSha256, ignoreCase = true) ->
                "Assinatura SHA-256 divergente! Possível APK reempacotado ou modificado."
            else -> null
        }

        return IntegrityReport(
            isValid = failureReason == null,
            packageName = currentPackage,
            expectedPackageName = EXPECTED_PACKAGE_NAME,
            appLabel = currentLabel.ifBlank { stringLabel },
            expectedAppLabel = EXPECTED_APP_NAME,
            currentCertSha256 = currentSha256,
            storedCertSha256 = storedSha256,
            failureReason = failureReason,
        )
    }

    @Suppress("DEPRECATION")
    fun readAppSigningCertSha256(context: Context): String {
        return runCatching {
            val pm = context.packageManager
            val pkgName = context.packageName
            val certBytes: ByteArray? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val pkgInfo = pm.getPackageInfo(pkgName, PackageManager.GET_SIGNING_CERTIFICATES)
                val signingInfo = pkgInfo.signingInfo
                val signers = if (signingInfo != null) {
                    if (signingInfo.hasMultipleSigners()) {
                        signingInfo.apkContentsSigners
                    } else {
                        signingInfo.signingCertificateHistory
                    }
                } else {
                    null
                }
                signers?.firstOrNull()?.toByteArray()
            } else {
                val pkgInfo = pm.getPackageInfo(pkgName, PackageManager.GET_SIGNATURES)
                pkgInfo.signatures?.firstOrNull()?.toByteArray()
            }

            if (certBytes == null) {
                "INDISPONÍVEL"
            } else {
                sha256Hex(certBytes)
            }
        }.getOrDefault("INDISPONÍVEL")
    }

    fun sha256Hex(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString(":") { "%02X".format(it) }
    }
}
