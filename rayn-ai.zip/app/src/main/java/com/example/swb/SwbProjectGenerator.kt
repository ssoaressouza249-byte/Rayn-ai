package com.example.swb

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import com.example.network.SwbAiSpec
import com.example.security.SecurityIntegrityGuard
import com.example.storage.SavedFileResult
import com.example.storage.StorageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class SwbBuildResult(
    val savedFile: SavedFileResult,
    val sha256: String,
    val entries: List<String>,
    val logicSummary: String,
)

object SwbProjectGenerator {

    private val sketchwarePackages = listOf(
        "com.sketchware.remod",
        "com.besome.sketch",
    )

    fun buildDefaultSpec(
        appName: String,
        description: String,
    ): SwbAiSpec {
        val lower = description.lowercase()
        val isCrosshair = lower.contains("mira") || lower.contains("crosshair")
        return when {
            isCrosshair -> SwbAiSpec(
                screenTitle = appName,
                primaryColorHex = "#00E5FF",
                buttonLabel = "Alternar Mira Flutuante",
                statusText = "Utilitário visual pronto (sem acesso a arquivos ou memória de jogos).",
                toastMessage = "Mira visual central alternada!",
                enableInputField = false,
                isCrosshairUtility = true,
                extraLogicComment = "Blocos onCreate (tema escuro) + onClick (alternar visualização da mira inofensiva)",
            )
            else -> SwbAiSpec(
                screenTitle = appName,
                primaryColorHex = "#00E5FF",
                buttonLabel = "Executar",
                statusText = description.ifBlank { "Projeto Sketchware Pro criado pelo Rayn AI." },
                toastMessage = "Ação executada no $appName!",
                enableInputField = true,
                isCrosshairUtility = false,
                extraLogicComment = "Blocos onCreate + onClick com TextView, EditText e Button configurados.",
            )
        }
    }

    suspend fun generateAndSaveSwb(
        context: Context,
        folderUriString: String,
        appName: String,
        packageName: String,
        spec: SwbAiSpec,
    ): Result<SwbBuildResult> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanAppName = appName.trim().ifBlank { "RaynCyberApp" }
            val cleanPkg = packageName.trim().ifBlank { "com.rayn.project" }
            val baseFileName = cleanAppName
                .lowercase()
                .replace(Regex("[^a-z0-9_]+"), "_")
                .trim('_')
                .ifBlank { "projeto_rayn" } + ".swb"

            val projectJson = buildProjectMetadataJson(cleanAppName, cleanPkg, spec)
            val fileJson = buildDataFileJson()
            val viewJson = buildDataViewJson(cleanAppName, spec)
            val logicJson = buildDataLogicJson(spec)
            val libraryJson = buildDataLibraryJson()
            val resourceJson = buildDataResourceJson()

            val zipEntries = linkedMapOf(
                "project" to projectJson,
                "data/file" to fileJson,
                "data/view" to viewJson,
                "data/logic" to logicJson,
                "data/library" to libraryJson,
                "data/resource" to resourceJson,
            )

            val baos = ByteArrayOutputStream()
            ZipOutputStream(baos).use { zos ->
                zipEntries.forEach { (entryPath, content) ->
                    val entry = ZipEntry(entryPath)
                    zos.putNextEntry(entry)
                    zos.write(content.toByteArray(Charsets.UTF_8))
                    zos.closeEntry()
                }
            }

            val zipBytes = baos.toByteArray()
            val sha256 = SecurityIntegrityGuard.sha256Hex(zipBytes)

            val saved = StorageManager.saveBytesToFolderOrDownloads(
                context = context,
                folderUriString = folderUriString,
                fileName = baseFileName,
                mimeType = "application/octet-stream",
                bytes = zipBytes,
                allowDownloadsFallback = true,
            ).getOrThrow()

            SwbBuildResult(
                savedFile = saved,
                sha256 = sha256,
                entries = zipEntries.keys.toList(),
                logicSummary = spec.extraLogicComment,
            )
        }
    }

    fun buildShareWithSketchwareIntent(context: Context, fileUri: Uri, fileName: String): Intent {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_STREAM, fileUri)
            putExtra(Intent.EXTRA_TITLE, fileName)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        val pm = context.packageManager
        val installedSketchware = sketchwarePackages.firstOrNull { pkg ->
            runCatching {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(pkg, 0)
                true
            }.getOrDefault(false)
        }

        return if (installedSketchware != null) {
            Intent(sendIntent).apply { `package` = installedSketchware }
        } else {
            Intent.createChooser(sendIntent, "Compartilhar $fileName com Sketchware Pro")
        }
    }

    private fun buildProjectMetadataJson(appName: String, pkg: String, spec: SwbAiSpec): String {
        return JSONObject().apply {
            put("my_app_name", appName)
            put("my_sc_pkg_name", pkg)
            put("my_ws_name", appName.replace(" ", ""))
            put("my_sc_reg_dt", System.currentTimeMillis().toString())
            put("sc_ver_code", "1")
            put("sc_ver_name", "1.0")
            put("sketchware_ver", 640)
            put("sc_id", "601")
            put("color_primary", -16718337)
            put("color_primary_dark", -16381937)
            put("color_accent", -14059009)
            put("color_control_highlight", -16718337)
            put("color_control_normal", -16718337)
            put("custom_theme_hex", spec.primaryColorHex)
        }.toString(2)
    }

    private fun buildDataFileJson(): String {
        val mainActivityFile = JSONObject().apply {
            put("fileName", "main")
            put("fileType", 0)
            put("keyboardSetting", 0)
            put("options", 1)
            put("orientation", 1)
            put("theme", 0)
        }
        return JSONArray().apply { put(mainActivityFile) }.toString(2)
    }

    private fun buildDataViewJson(appName: String, spec: SwbAiSpec): String {
        val views = JSONArray()

        views.put(JSONObject().apply {
            put("id", "linear_root")
            put("type", 0)
            put("parent", "root")
            put("parentType", 0)
            put("index", 0)
            put("layout", JSONObject().apply {
                put("width", -1)
                put("height", -1)
                put("orientation", 1)
                put("paddingLeft", 24)
                put("paddingTop", 24)
                put("paddingRight", 24)
                put("paddingBottom", 24)
                put("backgroundColor", -16381937)
                put("gravity", 17)
            })
        })

        views.put(JSONObject().apply {
            put("id", "text_title")
            put("type", 4)
            put("parent", "linear_root")
            put("parentType", 0)
            put("index", 0)
            put("text", JSONObject().apply {
                put("text", spec.screenTitle.ifBlank { appName })
                put("textSize", 22)
                put("textColor", -16718337)
                put("textType", 1)
            })
        })

        views.put(JSONObject().apply {
            put("id", "text_status")
            put("type", 4)
            put("parent", "linear_root")
            put("parentType", 0)
            put("index", 1)
            put("text", JSONObject().apply {
                put("text", spec.statusText)
                put("textSize", 14)
                put("textColor", -986896)
            })
        })

        if (spec.isCrosshairUtility) {
            views.put(JSONObject().apply {
                put("id", "text_crosshair_preview")
                put("type", 4)
                put("parent", "linear_root")
                put("parentType", 0)
                put("index", 2)
                put("text", JSONObject().apply {
                    put("text", "⊕")
                    put("textSize", 48)
                    put("textColor", -16718337)
                })
            })
        } else if (spec.enableInputField) {
            views.put(JSONObject().apply {
                put("id", "edittext_input")
                put("type", 5)
                put("parent", "linear_root")
                put("parentType", 0)
                put("index", 2)
                put("text", JSONObject().apply {
                    put("text", "")
                    put("hint", "Digite aqui...")
                    put("textSize", 15)
                    put("textColor", -1)
                    put("hintColor", -7829368)
                })
            })
        }

        views.put(JSONObject().apply {
            put("id", "button_action")
            put("type", 3)
            put("parent", "linear_root")
            put("parentType", 0)
            put("index", 3)
            put("text", JSONObject().apply {
                put("text", spec.buttonLabel)
                put("textSize", 15)
                put("textColor", -16381937)
                put("textType", 1)
            })
            put("layout", JSONObject().apply {
                put("width", -1)
                put("height", -2)
                put("marginTop", 16)
                put("backgroundColor", -16718337)
            })
        })

        return JSONObject().apply {
            put("main.xml", views)
        }.toString(2)
    }

    private fun buildDataLogicJson(spec: SwbAiSpec): String {
        val onCreateBlocks = JSONArray().apply {
            put(JSONObject().apply {
                put("id", "1")
                put("spec", "setText %m.textview %s")
                put("opCode", "setText")
                put("type", " ")
                put("params", JSONArray().apply {
                    put("text_status")
                    put(spec.statusText)
                })
            })
        }

        val onClickBlocks = JSONArray().apply {
            put(JSONObject().apply {
                put("id", "2")
                put("spec", "Toast %s")
                put("opCode", "doToast")
                put("type", " ")
                put("params", JSONArray().apply {
                    put(spec.toastMessage)
                })
            })
            if (spec.isCrosshairUtility) {
                put(JSONObject().apply {
                    put("id", "3")
                    put("spec", "setVisible %m.view %m.visible")
                    put("opCode", "setVisible")
                    put("type", " ")
                    put("params", JSONArray().apply {
                        put("text_crosshair_preview")
                        put("VISIBLE")
                    })
                })
            }
        }

        val events = JSONArray().apply {
            put(JSONObject().apply {
                put("eventName", "onCreate")
                put("targetId", "MainActivity")
                put("targetType", 0)
            })
            put(JSONObject().apply {
                put("eventName", "onClick")
                put("targetId", "button_action")
                put("targetType", 3)
            })
        }

        return JSONObject().apply {
            put("MainActivity.java", JSONObject().apply {
                put("events", events)
                put("onCreate", onCreateBlocks)
                put("button_action_onClick", onClickBlocks)
                put("variables", JSONArray())
                put("components", JSONArray())
            })
        }.toString(2)
    }

    private fun buildDataLibraryJson(): String {
        return JSONObject().apply {
            put("appcompat", JSONObject().put("useYn", "Y"))
            put("design", JSONObject().put("useYn", "Y"))
            put("firebase", JSONObject().put("useYn", "N"))
            put("admob", JSONObject().put("useYn", "N"))
            put("googlemap", JSONObject().put("useYn", "N"))
        }.toString(2)
    }

    private fun buildDataResourceJson(): String {
        return JSONObject().apply {
            put("images", JSONArray())
            put("sounds", JSONArray())
            put("fonts", JSONArray())
        }.toString(2)
    }
}
