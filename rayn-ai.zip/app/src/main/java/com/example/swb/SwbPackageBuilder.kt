package com.example.swb

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class SwbEntryPreview(
    val entryPath: String,
    val sizeBytes: Int,
    val previewContent: String
)

data class SwbBuildArtifact(
    val appName: String,
    val packageName: String,
    val fileName: String,
    val archiveBytes: ByteArray,
    val entries: List<SwbEntryPreview>
)

class SwbPackageBuilder {

    fun buildFromAiJson(
        rawJson: String,
        requestedAppName: String,
        requestedPackageName: String
    ): SwbBuildArtifact {
        val cleanedJson = stripMarkdownFences(rawJson)
        val root = JSONObject(cleanedJson)

        if (root.optBoolean("rejected", false)) {
            val reason = root.optString("reason", "Solicitação recusada pelas diretrizes de segurança da Rayn AI.")
            throw IllegalArgumentException(reason)
        }

        val safeAppName = requestedAppName.trim().ifBlank { "RaynApp" }
        val safePkg = requestedPackageName.trim().ifBlank { "com.raynai.sketchapp" }
        val projectId = (1000..9999).random().toString()

        val projectObj = root.optJSONObject("project") ?: JSONObject()
        val normalizedProject = JSONObject().apply {
            put("sc_id", projectId)
            put("my_app_name", projectObj.optString("my_app_name", safeAppName))
            put("my_sc_pkg_name", projectObj.optString("my_sc_pkg_name", safePkg))
            put("my_ws_name", projectObj.optString("my_ws_name", safeAppName.replace(" ", "")))
            put("sc_ver_code", projectObj.optString("sc_ver_code", "1"))
            put("sc_ver_name", projectObj.optString("sc_ver_name", "1.0"))
            put("sketchware_ver", 152)
            put("color_primary", projectObj.optString("color_primary", "#2979FF"))
            put("color_primary_dark", projectObj.optString("color_primary_dark", "#06080F"))
            put("color_accent", projectObj.optString("color_accent", "#00E5FF"))
            put("color_control_highlight", "#1A2642")
            put("color_control_normal", "#00E5FF")
        }

        val fileObj = root.optJSONObject("file") ?: JSONObject().apply {
            put("activities", JSONArray().put(JSONObject().apply {
                put("fileName", "main")
                put("type", 1)
                put("orientation", 1)
                put("theme", 0)
            }))
            put("customViews", JSONArray())
        }

        val viewObj = root.optJSONObject("view") ?: JSONObject().apply {
            put(
                "mainXml",
                """
                <LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
                    android:layout_width="match_parent"
                    android:layout_height="match_parent"
                    android:orientation="vertical"
                    android:padding="16dp"
                    android:background="#06080F">
                    <TextView
                        android:id="@+id/textview1"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="$safeAppName"
                        android:textColor="#00E5FF"
                        android:textSize="20sp" />
                </LinearLayout>
                """.trimIndent()
            )
            put("widgets", JSONArray())
        }

        val logicObj = root.optJSONObject("logic") ?: JSONObject().apply {
            put("events", JSONArray().put(JSONObject().apply {
                put("targetId", "main")
                put("eventName", "onCreate")
                put("blocks", JSONArray().put(JSONObject().apply {
                    put("opCode", "setTitle")
                    put("spec", "Activity setTitle %s")
                    put("params", JSONArray().put(safeAppName))
                }))
            }))
        }

        val libraryObj = root.optJSONObject("library") ?: JSONObject().apply {
            put("useAppCompat", true)
            put("useFirebase", false)
            put("useAdMob", false)
        }

        val resourceObj = root.optJSONObject("resource") ?: JSONObject().apply {
            put("stringsXml", "<resources><string name=\"app_name\">$safeAppName</string></resources>")
            put("colorsXml", "<resources><color name=\"colorPrimary\">#2979FF</color><color name=\"colorAccent\">#00E5FF</color></resources>")
        }

        val entryMap = linkedMapOf(
            "project" to normalizedProject.toString(2),
            "data/file" to fileObj.toString(2),
            "data/view" to viewObj.toString(2),
            "data/logic" to logicObj.toString(2),
            "data/library" to libraryObj.toString(2),
            "data/resource" to resourceObj.toString(2)
        )

        val baos = ByteArrayOutputStream()
        val previews = mutableListOf<SwbEntryPreview>()
        ZipOutputStream(baos).use { zos ->
            entryMap.forEach { (path, content) ->
                val bytes = content.toByteArray(Charsets.UTF_8)
                zos.putNextEntry(ZipEntry(path))
                zos.write(bytes)
                zos.closeEntry()
                previews.add(
                    SwbEntryPreview(
                        entryPath = path,
                        sizeBytes = bytes.size,
                        previewContent = content
                    )
                )
            }
        }

        val sanitizedBase = safeAppName
            .replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
            .trim('_')
            .ifBlank { "RaynProject" }

        return SwbBuildArtifact(
            appName = safeAppName,
            packageName = safePkg,
            fileName = "$sanitizedBase.swb",
            archiveBytes = baos.toByteArray(),
            entries = previews
        )
    }

    private fun stripMarkdownFences(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.startsWith("```")) {
            val firstNewline = trimmed.indexOf('\n')
            val lastFence = trimmed.lastIndexOf("```")
            if (firstNewline > 0 && lastFence > firstNewline) {
                return trimmed.substring(firstNewline + 1, lastFence).trim()
            }
        }
        val firstBrace = trimmed.indexOf('{')
        val lastBrace = trimmed.lastIndexOf('}')
        if (firstBrace >= 0 && lastBrace > firstBrace) {
            return trimmed.substring(firstBrace, lastBrace + 1)
        }
        return trimmed
    }
}
