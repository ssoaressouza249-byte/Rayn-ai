package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.RaynPreferencesRepository
import com.example.data.RaynPreferencesState
import com.example.network.GeminiApiClient
import com.example.network.GeminiChatTurn
import com.example.network.GeminiTestResult
import com.example.scanner.ApkStaticScanner
import com.example.scanner.FileScanReport
import com.example.security.IntegrityReport
import com.example.security.SecurityIntegrityGuard
import com.example.storage.AttachedFileData
import com.example.storage.SafSaveResult
import com.example.storage.SafStorageManager
import com.example.swb.SwbBuildArtifact
import com.example.swb.SwbPackageBuilder
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

enum class RaynTab(val route: String) {
    CHAT("rayn_chat"),
    SWB("create_swb"),
    SCANNER("virus_scanner"),
    SETTINGS("settings")
}

data class ChatMessageUi(
    val id: String = UUID.randomUUID().toString(),
    val isUser: Boolean,
    val text: String,
    val attachedFileName: String? = null,
    val generatedFileName: String? = null,
    val generatedSubfolder: String? = null,
    val savableContent: String = "",
    val hasFilePreview: Boolean = false,
    val savedConfirmationBanner: String? = null,
    val saveErrorBanner: String? = null,
    val timestampMs: Long = System.currentTimeMillis()
)

data class SwbUiState(
    val appName: String = "",
    val packageName: String = "com.raynai.meuapp",
    val description: String = "",
    val isGenerating: Boolean = false,
    val errorMessage: String? = null,
    val lastArtifact: SwbBuildArtifact? = null,
    val lastSaveResult: SafSaveResult? = null
)

data class ScannerUiState(
    val isScanning: Boolean = false,
    val errorMessage: String? = null,
    val report: FileScanReport? = null
)

data class SettingsUiState(
    val apiKeyDraft: String = "",
    val isTestingConnection: Boolean = false,
    val testResult: GeminiTestResult? = null,
    val keySavedBanner: String? = null,
    val folderSavedBanner: String? = null
)

data class RaynMainUiState(
    val currentTab: RaynTab = RaynTab.CHAT,
    val preferences: RaynPreferencesState = RaynPreferencesState(),
    val remainingCooldownMs: Long = 0L,
    val integrityReport: IntegrityReport? = null,
    val isCheckingIntegrity: Boolean = true,
    val chatMessages: List<ChatMessageUi> = emptyList(),
    val chatInput: String = "",
    val attachedFile: AttachedFileData? = null,
    val isChatLoading: Boolean = false,
    val chatErrorBanner: String? = null,
    val swbState: SwbUiState = SwbUiState(),
    val scannerState: ScannerUiState = ScannerUiState(),
    val settingsState: SettingsUiState = SettingsUiState()
)

class RaynViewModel(application: Application) : AndroidViewModel(application) {

    private val preferencesRepository = RaynPreferencesRepository(application)
    private val integrityGuard = SecurityIntegrityGuard(application, preferencesRepository)
    private val safStorageManager = SafStorageManager(application)
    private val geminiApiClient = GeminiApiClient()
    private val swbPackageBuilder = SwbPackageBuilder()
    private val apkStaticScanner = ApkStaticScanner(application)

    private val _uiState = MutableStateFlow(RaynMainUiState())
    val uiState: StateFlow<RaynMainUiState> = _uiState.asStateFlow()

    init {
        observePreferences()
        runInitialIntegrityCheck()
        startCooldownTicker()
    }

    private fun observePreferences() {
        viewModelScope.launch {
            preferencesRepository.preferencesFlow.collect { prefs ->
                val remaining = preferencesRepository.calculateRemainingCooldownMs(prefs)
                _uiState.update { current ->
                    val shouldPopulateDraft = current.settingsState.apiKeyDraft.isEmpty() && prefs.geminiApiKey.isNotEmpty()
                    current.copy(
                        preferences = prefs,
                        remainingCooldownMs = remaining,
                        settingsState = if (shouldPopulateDraft) {
                            current.settingsState.copy(apiKeyDraft = prefs.geminiApiKey)
                        } else {
                            current.settingsState
                        }
                    )
                }
            }
        }
    }

    private fun runInitialIntegrityCheck() {
        viewModelScope.launch {
            _uiState.update { it.copy(isCheckingIntegrity = true) }
            val report = integrityGuard.verifyIntegrity()
            _uiState.update {
                it.copy(
                    integrityReport = report,
                    isCheckingIntegrity = false
                )
            }
        }
    }

    fun recheckIntegrity() {
        runInitialIntegrityCheck()
    }

    private suspend fun verifyIntegrityBeforeAiCall(): Boolean {
        val report = integrityGuard.verifyIntegrity()
        _uiState.update { it.copy(integrityReport = report) }
        return report.isValid
    }

    private fun startCooldownTicker() {
        viewModelScope.launch {
            while (isActive) {
                preferencesRepository.refreshCreditsIfCooldownExpired()
                val snapshot = _uiState.value.preferences
                val remaining = preferencesRepository.calculateRemainingCooldownMs(snapshot)
                _uiState.update { it.copy(remainingCooldownMs = remaining) }
                delay(1000L)
            }
        }
    }

    fun selectTab(tab: RaynTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    // --- CHAT ACTIONS ---

    fun updateChatInput(value: String) {
        _uiState.update { it.copy(chatInput = value, chatErrorBanner = null) }
    }

    fun attachDocument(uri: Uri) {
        viewModelScope.launch {
            safStorageManager.readAttachedDocument(uri)
                .onSuccess { data ->
                    _uiState.update { it.copy(attachedFile = data, chatErrorBanner = null) }
                }
                .onFailure { err ->
                    _uiState.update {
                        it.copy(chatErrorBanner = "Erro ao ler arquivo anexo: ${err.localizedMessage}")
                    }
                }
        }
    }

    fun clearAttachment() {
        _uiState.update { it.copy(attachedFile = null) }
    }

    fun clearChatHistory() {
        _uiState.update {
            it.copy(chatMessages = emptyList(), chatErrorBanner = null)
        }
    }

    fun sendChatMessage() {
        val currentState = _uiState.value
        if (currentState.isChatLoading) return

        val rawPrompt = currentState.chatInput.trim()
        val attached = currentState.attachedFile
        if (rawPrompt.isBlank() && attached == null) return

        val effectivePrompt = if (rawPrompt.isBlank() && attached != null) {
            "Analise o arquivo ${attached.fileName} e sugira melhorias ou correções."
        } else {
            rawPrompt
        }

        val userBubble = ChatMessageUi(
            isUser = true,
            text = effectivePrompt,
            attachedFileName = attached?.fileName,
            savableContent = attached?.textContent ?: effectivePrompt,
            generatedFileName = attached?.fileName ?: "prompt_rayn.txt"
        )

        _uiState.update {
            it.copy(
                chatMessages = it.chatMessages + userBubble,
                chatInput = "",
                attachedFile = null,
                isChatLoading = true,
                chatErrorBanner = null
            )
        }

        viewModelScope.launch {
            // Mandatory real-time anti-crack verification before every AI call
            if (!verifyIntegrityBeforeAiCall()) {
                _uiState.update { it.copy(isChatLoading = false) }
                return@launch
            }

            val prefs = preferencesRepository.getSnapshot()
            val fullPromptForModel = buildString {
                if (attached != null) {
                    appendLine("[ARQUIVO ANEXADO PELO USUÁRIO]")
                    appendLine("Nome: ${attached.fileName}")
                    appendLine("MIME: ${attached.mimeType} | Tamanho: ${attached.sizeBytes} bytes")
                    appendLine("Conteúdo:")
                    appendLine("```")
                    appendLine(attached.textContent)
                    appendLine("```")
                    appendLine()
                }
                append(effectivePrompt)
            }

            val history = currentState.chatMessages.map { msg ->
                GeminiChatTurn(isUser = msg.isUser, text = msg.text)
            }

            val result = geminiApiClient.generateChatReply(
                apiKey = prefs.geminiApiKey,
                history = history,
                userPrompt = fullPromptForModel
            )

            result.onSuccess { rawReply ->
                val parsed = RaynChatParser.parseReply(
                    rawReply = rawReply,
                    userPrompt = effectivePrompt,
                    attachedFileName = attached?.fileName
                )

                var savedBanner: String? = null
                var saveError: String? = null

                if (parsed.shouldAutoSave) {
                    val treeUri = prefs.safFolderUri
                    val folderDisplay = prefs.safFolderDisplay ?: "Pasta SAF"
                    if (treeUri.isNullOrBlank()) {
                        saveError = "Defina a Pasta Padrão de Salvamento em Ajustes para salvar automaticamente."
                    } else {
                        val saveRes = safStorageManager.saveTextToSafFolder(
                            treeUriString = treeUri,
                            folderDisplayName = folderDisplay,
                            fileName = parsed.fileName,
                            content = parsed.savableContent,
                            subfolder = parsed.subfolder
                        )
                        if (saveRes.success) {
                            savedBanner = "Salvo em ${saveRes.displayPath}/${saveRes.fileName}"
                        } else {
                            saveError = saveRes.errorMessage
                        }
                    }
                }

                val assistantBubble = ChatMessageUi(
                    isUser = false,
                    text = parsed.displayMarkdown,
                    generatedFileName = parsed.fileName,
                    generatedSubfolder = parsed.subfolder,
                    savableContent = parsed.savableContent,
                    hasFilePreview = parsed.hasExplicitFileArtifact,
                    savedConfirmationBanner = savedBanner,
                    saveErrorBanner = saveError
                )

                _uiState.update {
                    it.copy(
                        chatMessages = it.chatMessages + assistantBubble,
                        isChatLoading = false
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isChatLoading = false,
                        chatErrorBanner = err.localizedMessage ?: "Erro ao consultar Gemini 2.5 Flash."
                    )
                }
            }
        }
    }

    fun saveMessageToSafFolder(messageId: String) {
        viewModelScope.launch {
            val prefs = preferencesRepository.getSnapshot()
            val treeUri = prefs.safFolderUri
            val folderDisplay = prefs.safFolderDisplay ?: "Pasta SAF"

            if (treeUri.isNullOrBlank() || !safStorageManager.hasValidTreePermission(treeUri)) {
                _uiState.update { state ->
                    state.copy(
                        chatMessages = state.chatMessages.map { msg ->
                            if (msg.id == messageId) {
                                msg.copy(
                                    saveErrorBanner = "Nenhuma pasta SAF configurada. Selecione em Ajustes."
                                )
                            } else msg
                        }
                    )
                }
                return@launch
            }

            val targetMsg = _uiState.value.chatMessages.find { it.id == messageId } ?: return@launch
            val fileName = targetMsg.generatedFileName ?: targetMsg.attachedFileName ?: "rayn_nota.txt"
            val content = targetMsg.savableContent.ifBlank { targetMsg.text }

            val result = safStorageManager.saveTextToSafFolder(
                treeUriString = treeUri,
                folderDisplayName = folderDisplay,
                fileName = fileName,
                content = content,
                subfolder = targetMsg.generatedSubfolder
            )

            _uiState.update { state ->
                state.copy(
                    chatMessages = state.chatMessages.map { msg ->
                        if (msg.id == messageId) {
                            if (result.success) {
                                msg.copy(
                                    savedConfirmationBanner = "Salvo em ${result.displayPath}/${result.fileName}",
                                    saveErrorBanner = null
                                )
                            } else {
                                msg.copy(
                                    saveErrorBanner = result.errorMessage ?: "Erro ao salvar arquivo."
                                )
                            }
                        } else msg
                    }
                )
            }
        }
    }

    // --- SWB BUILDER ACTIONS ---

    fun updateSwbAppName(value: String) {
        _uiState.update { it.copy(swbState = it.swbState.copy(appName = value, errorMessage = null)) }
    }

    fun updateSwbPackageName(value: String) {
        _uiState.update { it.copy(swbState = it.swbState.copy(packageName = value, errorMessage = null)) }
    }

    fun updateSwbDescription(value: String) {
        _uiState.update { it.copy(swbState = it.swbState.copy(description = value, errorMessage = null)) }
    }

    fun generateSwbProject() {
        val current = _uiState.value
        val swb = current.swbState
        if (swb.isGenerating) return

        viewModelScope.launch {
            // Refresh credits first in case 15 hours just elapsed
            preferencesRepository.refreshCreditsIfCooldownExpired()
            val prefs = preferencesRepository.getSnapshot()

            if (prefs.swbCredits <= 0) {
                _uiState.update {
                    it.copy(
                        swbState = it.swbState.copy(
                            errorMessage = "Créditos esgotados. Aguarde a recarga automática de 15 horas."
                        )
                    )
                }
                return@launch
            }

            if (swb.appName.isBlank() || swb.description.isBlank()) {
                _uiState.update {
                    it.copy(
                        swbState = it.swbState.copy(
                            errorMessage = "Preencha o Nome do App e a descrição do projeto Sketchware Pro."
                        )
                    )
                }
                return@launch
            }

            // Mandatory real-time anti-crack verification before AI call
            if (!verifyIntegrityBeforeAiCall()) return@launch

            _uiState.update {
                it.copy(
                    swbState = it.swbState.copy(
                        isGenerating = true,
                        errorMessage = null,
                        lastSaveResult = null
                    )
                )
            }

            val aiResult = geminiApiClient.generateSwbBlueprintJson(
                apiKey = prefs.geminiApiKey,
                appName = swb.appName.trim(),
                packageName = swb.packageName.trim().ifBlank { "com.raynai.sketchapp" },
                description = swb.description.trim()
            )

            aiResult.onSuccess { rawJson ->
                runCatching {
                    val artifact = swbPackageBuilder.buildFromAiJson(
                        rawJson = rawJson,
                        requestedAppName = swb.appName,
                        requestedPackageName = swb.packageName
                    )
                    // Deduct 1 credit only after successful blueprint + .swb packaging
                    val consumed = preferencesRepository.consumeSwbCredit()
                    if (!consumed) {
                        throw IllegalStateException("Sem créditos disponíveis para concluir a geração.")
                    }

                    val saveRes = safStorageManager.saveSwbArchive(
                        treeUriString = prefs.safFolderUri,
                        folderDisplayName = prefs.safFolderDisplay,
                        fileName = artifact.fileName,
                        bytes = artifact.archiveBytes
                    )

                    _uiState.update {
                        it.copy(
                            swbState = it.swbState.copy(
                                isGenerating = false,
                                lastArtifact = artifact,
                                lastSaveResult = saveRes,
                                errorMessage = if (!saveRes.success) saveRes.errorMessage else null
                            )
                        )
                    }
                }.onFailure { buildErr ->
                    _uiState.update {
                        it.copy(
                            swbState = it.swbState.copy(
                                isGenerating = false,
                                errorMessage = buildErr.localizedMessage ?: "Falha ao empacotar .SWB."
                            )
                        )
                    }
                }
            }.onFailure { apiErr ->
                _uiState.update {
                    it.copy(
                        swbState = it.swbState.copy(
                            isGenerating = false,
                            errorMessage = apiErr.localizedMessage ?: "Erro ao gerar estrutura na API Gemini."
                        )
                    )
                }
            }
        }
    }

    fun reSaveLastSwbToSaf() {
        viewModelScope.launch {
            val artifact = _uiState.value.swbState.lastArtifact ?: return@launch
            val prefs = preferencesRepository.getSnapshot()
            val treeUri = prefs.safFolderUri
            if (treeUri.isNullOrBlank()) {
                _uiState.update {
                    it.copy(
                        swbState = it.swbState.copy(
                            errorMessage = "Configure a Pasta Padrão em Ajustes para salvar via SAF."
                        )
                    )
                }
                return@launch
            }
            val saveRes = safStorageManager.saveBytesToSafFolder(
                treeUriString = treeUri,
                folderDisplayName = prefs.safFolderDisplay ?: "Pasta SAF",
                fileName = artifact.fileName,
                bytes = artifact.archiveBytes
            )
            _uiState.update {
                it.copy(
                    swbState = it.swbState.copy(
                        lastSaveResult = saveRes,
                        errorMessage = if (!saveRes.success) saveRes.errorMessage else null
                    )
                )
            }
        }
    }

    // --- VIRUS SCANNER ACTIONS ---

    fun scanSelectedFile(uri: Uri) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(scannerState = ScannerUiState(isScanning = true))
            }
            apkStaticScanner.scanUri(uri)
                .onSuccess { report ->
                    _uiState.update {
                        it.copy(scannerState = ScannerUiState(isScanning = false, report = report))
                    }
                }
                .onFailure { err ->
                    _uiState.update {
                        it.copy(
                            scannerState = ScannerUiState(
                                isScanning = false,
                                errorMessage = err.localizedMessage ?: "Falha ao analisar arquivo."
                            )
                        )
                    }
                }
        }
    }

    // --- SETTINGS ACTIONS ---

    fun updateApiKeyDraft(value: String) {
        _uiState.update {
            it.copy(
                settingsState = it.settingsState.copy(
                    apiKeyDraft = value,
                    keySavedBanner = null
                )
            )
        }
    }

    fun saveGeminiApiKey() {
        viewModelScope.launch {
            val key = _uiState.value.settingsState.apiKeyDraft.trim()
            preferencesRepository.saveGeminiApiKey(key)
            _uiState.update {
                it.copy(
                    settingsState = it.settingsState.copy(
                        keySavedBanner = if (key.isBlank()) "Chave removida." else "GEMINI_API_KEY salva com segurança no DataStore."
                    )
                )
            }
        }
    }

    fun testGeminiConnection() {
        viewModelScope.launch {
            val key = _uiState.value.settingsState.apiKeyDraft.trim()
                .ifBlank { _uiState.value.preferences.geminiApiKey }
            if (key.isNotBlank()) {
                preferencesRepository.saveGeminiApiKey(key)
            }
            _uiState.update {
                it.copy(
                    settingsState = it.settingsState.copy(
                        isTestingConnection = true,
                        testResult = null
                    )
                )
            }
            val result = geminiApiClient.testConnection(key)
            _uiState.update {
                it.copy(
                    settingsState = it.settingsState.copy(
                        isTestingConnection = false,
                        testResult = result
                    )
                )
            }
        }
    }

    fun onSafFolderPicked(uri: Uri) {
        viewModelScope.launch {
            val displayPath = safStorageManager.persistTreePermission(uri)
            preferencesRepository.saveSafFolder(uri.toString(), displayPath)
            _uiState.update {
                it.copy(
                    settingsState = it.settingsState.copy(
                        folderSavedBanner = "Pasta padrão vinculada: $displayPath"
                    )
                )
            }
        }
    }
}
