package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material.icons.filled.GppMaybe
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.scanner.RiskLevel
import com.example.scanner.ScanReport
import com.example.ui.components.CyberCard
import com.example.ui.theme.CrimsonSurface
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberAmberSurface
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDeepBlack
import com.example.ui.theme.CyberGraphiteElevated
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberGreenSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCrimson
import com.example.viewmodel.RaynUiState

@Composable
fun ScannerScreen(
    uiState: RaynUiState,
    onScanFile: (android.net.Uri?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        onScanFile(uri)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberDeepBlack)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        CyberCard(borderColor = NeonBlue.copy(alpha = 0.5f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(NeonBlue.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Filled.Security,
                        contentDescription = "Scanner de Vírus",
                        tint = NeonBlue,
                        modifier = Modifier.size(26.dp),
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Scanner Vírus & Inspetor APK",
                        style = MaterialTheme.typography.titleMedium,
                        color = CyberTextPrimary,
                    )
                    Text(
                        text = "Calcula SHA-256, verifica assinatura real, extrai pacote, versão e permissões perigosas (READ_SMS, Accessibility, Overlay, Install Packages).",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextSecondary,
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            Button(
                onClick = { filePicker.launch(arrayOf("*/*")) },
                enabled = !uiState.isScanning,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonBlue,
                    contentColor = CyberDeepBlack,
                ),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(vertical = 14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pick_scan_file_button"),
            ) {
                Icon(Icons.Filled.FileOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Selecionar Arquivo ou .APK para Análise", fontWeight = FontWeight.Bold)
            }

            if (uiState.isScanning) {
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = NeonBlue,
                    trackColor = CyberDeepBlack,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Calculando SHA-256 e inspecionando assinatura...",
                    style = MaterialTheme.typography.labelMedium,
                    color = NeonBlue,
                )
            }

            if (!uiState.scanError.isNullOrBlank()) {
                Spacer(Modifier.height(10.dp))
                Surface(
                    color = CrimsonSurface,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, NeonCrimson),
                ) {
                    Text(
                        text = uiState.scanError,
                        style = MaterialTheme.typography.bodySmall,
                        color = NeonCrimson,
                        modifier = Modifier.padding(12.dp),
                    )
                }
            }
        }

        val report = uiState.scanReport
        if (report != null) {
            ScanReportCard(report = report)
        } else if (!uiState.isScanning) {
            CyberCard {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = Icons.Filled.BugReport,
                        contentDescription = null,
                        tint = CyberTextMuted,
                        modifier = Modifier.size(36.dp),
                    )
                    Text(
                        text = "Nenhum arquivo analisado ainda",
                        style = MaterialTheme.typography.titleSmall,
                        color = CyberTextSecondary,
                    )
                    Text(
                        text = "Selecione qualquer .apk, .swb, .dex, .so, .json ou documento para inspeção completa.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextMuted,
                    )
                }
            }
        }
    }
}

@Composable
private fun ScanReportCard(report: ScanReport) {
    val (accentColor, surfaceColor, riskIcon) = when (report.riskLevel) {
        RiskLevel.SAFE -> Triple(CyberGreen, CyberGreenSurface, Icons.Filled.VerifiedUser)
        RiskLevel.CAUTION -> Triple(CyberAmber, CyberAmberSurface, Icons.Filled.GppMaybe)
        RiskLevel.HIGH_RISK -> Triple(NeonCrimson, CrimsonSurface, Icons.Filled.GppBad)
    }

    CyberCard(
        borderColor = accentColor,
        containerColor = surfaceColor.copy(alpha = 0.45f),
        modifier = Modifier.testTag("scan_verdict_card"),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f),
            ) {
                Icon(
                    imageVector = riskIcon,
                    contentDescription = report.riskLevel.label,
                    tint = accentColor,
                    modifier = Modifier.size(32.dp),
                )
                Column {
                    Text(
                        text = "DIAGNÓSTICO: ${report.riskLevel.label.uppercase()}",
                        style = MaterialTheme.typography.titleMedium,
                        color = accentColor,
                    )
                    Text(
                        text = report.fileName,
                        style = MaterialTheme.typography.labelMedium,
                        color = CyberTextPrimary,
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Text(
            text = report.summary,
            style = MaterialTheme.typography.bodySmall,
            color = CyberTextPrimary,
        )
    }

    CyberCard {
        Text(
            text = "Assinatura & Hashes Criptográficos",
            style = MaterialTheme.typography.titleSmall,
            color = NeonBlue,
        )
        Spacer(Modifier.height(8.dp))
        InspectorLine("Formato real", report.detectedFormat)
        InspectorLine("Tamanho", "${report.fileSizeBytes} bytes")
        InspectorLine("SHA-256", report.sha256)
        InspectorLine("MD5", report.md5)
    }

    if (report.isApk) {
        CyberCard(borderColor = if (report.signatureVerified) CyberBorder else NeonCrimson) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.Key,
                    contentDescription = null,
                    tint = if (report.signatureVerified) NeonBlue else NeonCrimson,
                    modifier = Modifier.size(18.dp),
                )
                Text(
                    text = "Metadados & Certificado do APK",
                    style = MaterialTheme.typography.titleSmall,
                    color = CyberTextPrimary,
                )
            }
            Spacer(Modifier.height(8.dp))
            InspectorLine("Pacote", report.packageName ?: "N/D")
            InspectorLine("Versão", "${report.versionName ?: "N/D"} (code ${report.versionCode ?: 0})")
            InspectorLine(
                "Certificado",
                if (report.signatureVerified) "Assinatura Válida" else "Ausente / Não Verificada"
            )
            if (!report.signatureSha256.isNullOrBlank()) {
                InspectorLine("Cert SHA-256", report.signatureSha256)
            }
            if (!report.signatureSubject.isNullOrBlank()) {
                InspectorLine("Emissor X.509", report.signatureSubject)
            }
            InspectorLine("Total de Permissões", "${report.totalPermissions}")
        }
    }

    CyberCard {
        Text(
            text = "Permissões Perigosas & Alertas",
            style = MaterialTheme.typography.titleSmall,
            color = CyberTextPrimary,
        )
        Spacer(Modifier.height(8.dp))

        if (report.dangerousFindings.isEmpty() && report.heuristicAlerts.isEmpty()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.CheckCircle,
                    contentDescription = null,
                    tint = CyberGreen,
                    modifier = Modifier.size(18.dp),
                )
                Text(
                    text = "Nenhuma permissão crítica ou assinatura anômala detectada.",
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberGreen,
                )
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                report.dangerousFindings.forEach { finding ->
                    val color = if (finding.severity == RiskLevel.HIGH_RISK) NeonCrimson else CyberAmber
                    Surface(
                        color = CyberGraphiteElevated,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, color.copy(alpha = 0.6f)),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "[${finding.severity.label.uppercase()}] ${finding.permission.substringAfterLast('.')}",
                                style = MaterialTheme.typography.labelMedium,
                                color = color,
                                fontWeight = FontWeight.Bold,
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = finding.reason,
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberTextSecondary,
                            )
                        }
                    }
                }
                report.heuristicAlerts.forEach { alert ->
                    Surface(
                        color = CyberGraphiteElevated,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, NeonCrimson.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Warning,
                                contentDescription = null,
                                tint = NeonCrimson,
                                modifier = Modifier.size(16.dp),
                            )
                            Text(
                                text = alert,
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberTextPrimary,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InspectorLine(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 3.dp)) {
        Text(
            text = label.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = CyberTextMuted,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = CyberTextPrimary,
        )
    }
}
