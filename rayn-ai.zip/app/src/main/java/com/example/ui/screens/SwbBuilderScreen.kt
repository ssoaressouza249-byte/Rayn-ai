package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.RaynPreferencesRepository
import com.example.ui.RaynMainUiState
import com.example.ui.theme.CrimsonDim
import com.example.ui.theme.CyanDim
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderBright
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberSurfaceInput
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MonoBadgeStyle
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCrimson
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SwbBuilderScreen(
    uiState: RaynMainUiState,
    onAppNameChange: (String) -> Unit,
    onPackageNameChange: (String) -> Unit,
    onDescriptionChange: (String) -> Unit,
    onGenerateClick: () -> Unit,
    onSaveToSafClick: () -> Unit
) {
    val context = LocalContext.current
    val credits = uiState.preferences.swbCredits
    val remainingMs = uiState.remainingCooldownMs
    val isLocked = credits <= 0
    val swb = uiState.swbState

    var selectedEntryPath by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 720.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Card
            Column {
                Text(
                    text = stringResource(R.string.swb_title),
                    style = MaterialTheme.typography.headlineSmall,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = stringResource(R.string.swb_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }

            // Credit & 15h Live Timer Card
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (isLocked) CrimsonDim.copy(alpha = 0.7f) else CyberSurface,
                border = BorderStroke(
                    1.dp,
                    if (isLocked) NeonCrimson else NeonBlue.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isLocked) "COTA DE PROJETOS ESGOTADA" else "COTA SKETCHWARE PRO DISPONÍVEL",
                            style = MonoBadgeStyle,
                            color = if (isLocked) NeonCrimson else NeonBlue
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        if (isLocked) {
                            val totalSeconds = (remainingMs / 1000L).coerceAtLeast(0L)
                            val hours = totalSeconds / 3600L
                            val minutes = (totalSeconds % 3600L) / 60L
                            val seconds = totalSeconds % 60L
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.LockClock,
                                    contentDescription = null,
                                    tint = NeonCrimson,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = stringResource(R.string.swb_cooldown_format, hours, minutes, seconds),
                                    style = MonoBadgeStyle.copy(fontSize = MaterialTheme.typography.labelMedium.fontSize),
                                    color = TextPrimary,
                                    modifier = Modifier.testTag("swb_cooldown_timer_text")
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Rayn Chat, salvamento SAF e Scanner Vírus seguem ativos normalmente.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        } else {
                            Text(
                                text = "Cada arquivo .swb gerado desconta 1 crédito. Recarga automática em 15h quando zerar.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isLocked) CyberBackground else CyanDim,
                        border = BorderStroke(1.dp, if (isLocked) NeonCrimson else NeonBlue)
                    ) {
                        Text(
                            text = "$credits/${RaynPreferencesRepository.MAX_SWB_CREDITS}",
                            style = MonoBadgeStyle.copy(fontSize = MaterialTheme.typography.titleMedium.fontSize),
                            color = if (isLocked) NeonCrimson else NeonBlue,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }

            // Form Card
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = CyberSurface,
                border = BorderStroke(1.dp, CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = swb.appName,
                        onValueChange = onAppNameChange,
                        label = { Text(stringResource(R.string.swb_app_name_label)) },
                        placeholder = { Text(stringResource(R.string.swb_app_name_hint), color = TextMuted) },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = swbFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("swb_app_name_input")
                    )

                    OutlinedTextField(
                        value = swb.packageName,
                        onValueChange = onPackageNameChange,
                        label = { Text(stringResource(R.string.swb_package_label)) },
                        placeholder = { Text(stringResource(R.string.swb_package_hint), color = TextMuted) },
                        singleLine = true,
                        textStyle = MonoCodeStyle.copy(color = TextPrimary),
                        shape = RoundedCornerShape(12.dp),
                        colors = swbFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("swb_package_input")
                    )

                    OutlinedTextField(
                        value = swb.description,
                        onValueChange = onDescriptionChange,
                        label = { Text(stringResource(R.string.swb_prompt_label)) },
                        placeholder = { Text(stringResource(R.string.swb_prompt_hint), color = TextMuted) },
                        minLines = 4,
                        maxLines = 7,
                        shape = RoundedCornerShape(12.dp),
                        colors = swbFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("swb_description_input")
                    )

                    // Quick Template Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val quickPreset = "App utilitário de notas com onCreate, botão salvar nota em arquivo interno do próprio app e Toast de confirmação."
                        OutlinedButton(
                            onClick = {
                                if (swb.appName.isBlank()) onAppNameChange("NotasSeguras")
                                onDescriptionChange(quickPreset)
                            },
                            border = BorderStroke(1.dp, CyberBorderBright),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "Template: Notas + Blocos",
                                style = MaterialTheme.typography.bodySmall,
                                color = NeonBlue
                            )
                        }
                    }

                    if (!swb.errorMessage.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = CrimsonDim,
                            border = BorderStroke(1.dp, NeonCrimson),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.ErrorOutline,
                                    contentDescription = null,
                                    tint = NeonCrimson,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = swb.errorMessage,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimary
                                )
                            }
                        }
                    }

                    Button(
                        onClick = onGenerateClick,
                        enabled = !isLocked && !swb.isGenerating,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElectricBlue,
                            contentColor = TextPrimary,
                            disabledContainerColor = CyberSurfaceElevated,
                            disabledContentColor = TextMuted
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("generate_swb_button")
                    ) {
                        if (swb.isGenerating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = NeonBlue,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Compilando estrutura .SWB...", style = MaterialTheme.typography.labelLarge)
                        } else {
                            Icon(
                                imageVector = Icons.Filled.Extension,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isLocked) "Geração Bloqueada (0 Créditos)" else stringResource(R.string.swb_generate_button),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }

            // Generated .SWB Artifact Inspector
            val artifact = swb.lastArtifact
            if (artifact != null) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = CyberSurface,
                    border = BorderStroke(1.dp, NeonBlue.copy(alpha = 0.7f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("swb_result_card")
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Archive,
                                contentDescription = null,
                                tint = NeonBlue,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = artifact.fileName,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = NeonBlue
                                )
                                Text(
                                    text = "${artifact.packageName} • ${artifact.archiveBytes.size} bytes ZIP",
                                    style = MonoCodeStyle,
                                    color = TextSecondary
                                )
                            }
                        }

                        val saveRes = swb.lastSaveResult
                        if (saveRes != null && saveRes.success) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = CyanDim,
                                border = BorderStroke(1.dp, NeonBlue),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.CheckCircle,
                                        contentDescription = null,
                                        tint = NeonBlue,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Salvo em ${saveRes.displayPath}/${saveRes.fileName}",
                                        style = MonoBadgeStyle,
                                        color = NeonBlue
                                    )
                                }
                            }
                        }

                        HorizontalDivider(color = CyberBorder)

                        Text(
                            text = "ESTRUTURA INTERNA DO PACOTE .SWB:",
                            style = MonoBadgeStyle,
                            color = TextSecondary
                        )

                        artifact.entries.forEach { entry ->
                            val expanded = selectedEntryPath == entry.entryPath
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = CyberBackground,
                                border = BorderStroke(1.dp, if (expanded) NeonBlue else CyberBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedEntryPath = if (expanded) null else entry.entryPath
                                    }
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = entry.entryPath,
                                            style = MonoBadgeStyle,
                                            color = NeonBlue
                                        )
                                        Text(
                                            text = "${entry.sizeBytes} B",
                                            style = MonoCodeStyle,
                                            color = TextSecondary
                                        )
                                    }
                                    if (expanded) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = entry.previewContent.take(1500),
                                            style = MonoCodeStyle,
                                            color = TextPrimary
                                        )
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = onSaveToSafClick,
                                border = BorderStroke(1.dp, NeonBlue),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonBlue),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Filled.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(stringResource(R.string.swb_save_saf_button), maxLines = 1)
                            }

                            val shareUri = swb.lastSaveResult?.shareUri
                            Button(
                                onClick = {
                                    if (shareUri != null) {
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "application/octet-stream"
                                            putExtra(Intent.EXTRA_STREAM, shareUri)
                                            putExtra(Intent.EXTRA_SUBJECT, artifact.fileName)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(
                                            Intent.createChooser(shareIntent, "Abrir ou compartilhar com Sketchware Pro")
                                        )
                                    }
                                },
                                enabled = shareUri != null,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NeonBlue,
                                    contentColor = CyberBackground
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("share_swb_button")
                            ) {
                                Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Sketchware Pro", maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun swbFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = CyberSurfaceInput,
    unfocusedContainerColor = CyberSurfaceInput,
    focusedBorderColor = NeonBlue,
    unfocusedBorderColor = CyberBorder,
    focusedLabelColor = NeonBlue,
    unfocusedLabelColor = TextSecondary,
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    cursorColor = NeonBlue
)
