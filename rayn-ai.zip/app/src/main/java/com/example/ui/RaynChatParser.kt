package com.example.ui

data class ParsedAiReply(
    val displayMarkdown: String,
    val fileName: String,
    val subfolder: String?,
    val savableContent: String,
    val shouldAutoSave: Boolean,
    val hasExplicitFileArtifact: Boolean
)

object RaynChatParser {

    private val blockRegex = Regex(
        """<<<RAYN_FILE_START>>>\s*(.*?)\s*<<<CONTENT>>>\s*(.*?)\s*<<<RAYN_FILE_END>>>""",
        setOf(RegexOption.DOT_MATCHES_ALL)
    )

    private val fencedCodeRegex = Regex(
        """```([a-zA-Z0-9_+-]*)\n(.*?)```""",
        setOf(RegexOption.DOT_MATCHES_ALL)
    )

    private val explicitFileNameHintRegex = Regex(
        """(?i)(?:salve|salvar|salva|gravar|grava|nome|arquivo|como)\s+(?:o\s+arquivo\s+)?[`"']?([a-zA-Z0-9_\-./]+\.[a-zA-Z0-9]{1,10})[`"']?"""
    )

    private val explicitSubfolderHintRegex = Regex(
        """(?i)(?:subpasta|pasta)\s+[`"']?([a-zA-Z0-9_\-/]+)[`"']?"""
    )

    fun parseReply(
        rawReply: String,
        userPrompt: String,
        attachedFileName: String?
    ): ParsedAiReply {
        val match = blockRegex.find(rawReply)
        if (match != null) {
            val header = match.groupValues[1]
            val content = match.groupValues[2].trimEnd()
            val fileNameLine = header.lines().firstOrNull { it.trim().startsWith("FILENAME:", ignoreCase = true) }
            val subfolderLine = header.lines().firstOrNull { it.trim().startsWith("SUBFOLDER:", ignoreCase = true) }
            val autoSaveLine = header.lines().firstOrNull { it.trim().startsWith("AUTO_SAVE:", ignoreCase = true) }

            val parsedFileName = fileNameLine?.substringAfter(":")?.trim()
                ?.takeIf { it.isNotBlank() && !it.equals("null", true) }
                ?: inferFallbackFileName(userPrompt, attachedFileName, null)

            val parsedSubfolder = subfolderLine?.substringAfter(":")?.trim()
                ?.takeIf { it.isNotBlank() && !it.equals("vazio", true) && !it.equals("none", true) && !it.equals("null", true) }

            val autoSaveFlag = autoSaveLine?.substringAfter(":")?.trim()?.equals("true", ignoreCase = true) == true
            val userAskedSave = hasSaveIntent(userPrompt)

            val cleanedDisplay = rawReply.replace(match.value, "").trim().let { intro ->
                if (intro.isBlank()) "Arquivo `$parsedFileName` preparado para gravação." else intro
            }

            return ParsedAiReply(
                displayMarkdown = cleanedDisplay,
                fileName = parsedFileName,
                subfolder = parsedSubfolder,
                savableContent = content,
                shouldAutoSave = autoSaveFlag || userAskedSave,
                hasExplicitFileArtifact = true
            )
        }

        // Fallback: inspect markdown code fences
        val codeMatch = fencedCodeRegex.find(rawReply)
        val lang = codeMatch?.groupValues?.getOrNull(1)?.lowercase()?.trim()
        val codeContent = codeMatch?.groupValues?.getOrNull(2)?.trimEnd()

        val inferredName = inferFallbackFileName(userPrompt, attachedFileName, lang)
        val inferredSubfolder = explicitSubfolderHintRegex.find(userPrompt)?.groupValues?.getOrNull(1)
            ?.trim('/')
            ?.takeIf { it.isNotBlank() && !it.contains('.') }

        return ParsedAiReply(
            displayMarkdown = rawReply.trim(),
            fileName = inferredName,
            subfolder = inferredSubfolder,
            savableContent = codeContent ?: rawReply.trim(),
            shouldAutoSave = hasSaveIntent(userPrompt) && (codeContent != null || attachedFileName != null),
            hasExplicitFileArtifact = codeContent != null
        )
    }

    fun hasSaveIntent(prompt: String): Boolean {
        val lower = prompt.lowercase()
        return lower.contains("salva") ||
            lower.contains("salve") ||
            lower.contains("grava") ||
            lower.contains("grave") ||
            lower.contains("export")
    }

    private fun inferFallbackFileName(
        userPrompt: String,
        attachedFileName: String?,
        codeLang: String?
    ): String {
        val hintedPath = explicitFileNameHintRegex.find(userPrompt)?.groupValues?.getOrNull(1)
        if (!hintedPath.isNullOrBlank()) {
            return hintedPath.substringAfterLast('/')
        }
        if (!attachedFileName.isNullOrBlank()) {
            return attachedFileName
        }
        val ext = when (codeLang) {
            "kotlin", "kt" -> "kt"
            "json" -> "json"
            "xml" -> "xml"
            "html" -> "html"
            "csv" -> "csv"
            "js", "javascript" -> "js"
            "py", "python" -> "py"
            "java" -> "java"
            "md", "markdown" -> "md"
            else -> "txt"
        }
        return "rayn_arquivo_${System.currentTimeMillis() % 10000}.$ext"
    }
}
