package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.RaynPreferencesRepository
import com.example.security.IntegrityReport
import com.example.security.SecurityIntegrityGuard
import com.example.ui.RaynTab
import com.example.ui.theme.CrimsonDim
import com.example.ui.theme.CyanDim
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MonoBadgeStyle
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCrimson
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun RaynTopBar(
    credits: Int,
    maxCredits: Int = RaynPreferencesRepository.MAX_SWB_CREDITS,
    onProtectedBadgeClick: () -> Unit,
    onCreditsBadgeClick: () -> Unit
) {
    val isDepleted = credits <= 0
    val creditColor by animateColorAsState(
        targetValue = if (isDepleted) NeonCrimson else NeonBlue,
        label = "creditColor"
    )
    val creditBg by animateColorAsState(
        targetValue = if (isDepleted) CrimsonDim else CyanDim,
        label = "creditBg"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CyberSurface)
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Logo & Title
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f, fill = false)
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(ElectricBlue.copy(alpha = 0.25f), NeonBlue.copy(alpha = 0.15f))
                            )
                        )
                        .border(1.dp, NeonBlue.copy(alpha = 0.65f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = stringResource(R.string.app_name),
                        tint = NeonBlue,
                        modifier = Modifier.size(19.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = stringResource(R.string.app_name),
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "CYBER CORE v1.0",
                        style = MonoBadgeStyle.copy(fontSize = MaterialTheme.typography.labelSmall.fontSize),
                        color = NeonBlue.copy(alpha = 0.8f),
                        maxLines = 1
                    )
                }
            }

            // Right: Credits Badge + Protected Shield Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = creditBg,
                    border = BorderStroke(1.dp, creditColor.copy(alpha = 0.7f)),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onCreditsBadgeClick)
                        .testTag("top_credits_badge")
                ) {
                    Text(
                        text = stringResource(R.string.badge_credits_format, credits, maxCredits),
                        style = MonoBadgeStyle,
                        color = creditColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        maxLines = 1
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = CrimsonDim.copy(alpha = 0.85f),
                    border = BorderStroke(
                        1.dp,
                        Brush.horizontalGradient(listOf(NeonCrimson, ElectricBlue))
                    ),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onProtectedBadgeClick)
                        .testTag("top_protected_badge")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.GppGood,
                            contentDescription = stringResource(R.string.badge_protected),
                            tint = NeonBlue,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = stringResource(R.string.badge_protected),
                            style = MonoBadgeStyle,
                            color = NeonCrimson,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // Neon hairline gradient bottom border
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.5.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            NeonBlue.copy(alpha = 0.85f),
                            ElectricBlue.copy(alpha = 0.6f),
                            NeonCrimson.copy(alpha = 0.85f)
                        )
                    )
                )
        )
    }
}

@Composable
fun RaynBottomBar(
    currentTab: RaynTab,
    onSelectTab: (RaynTab) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        HorizontalDivider(thickness = 1.dp, color = CyberBorder)
        NavigationBar(
            containerColor = CyberSurface,
            contentColor = TextPrimary,
            windowInsets = WindowInsets.navigationBars
        ) {
            val items = listOf(
                Triple(RaynTab.CHAT, stringResource(R.string.tab_chat), Pair(Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome)),
                Triple(RaynTab.SWB, stringResource(R.string.tab_swb), Pair(Icons.Filled.Extension, Icons.Outlined.Extension)),
                Triple(RaynTab.SCANNER, stringResource(R.string.tab_scanner), Pair(Icons.Filled.Security, Icons.Outlined.Security)),
                Triple(RaynTab.SETTINGS, stringResource(R.string.tab_settings), Pair(Icons.Filled.Tune, Icons.Outlined.Tune))
            )

            items.forEach { (tab, label, icons) ->
                val selected = currentTab == tab
                val activeTint = if (tab == RaynTab.SCANNER) NeonCrimson else NeonBlue
                NavigationBarItem(
                    selected = selected,
                    onClick = { onSelectTab(tab) },
                    modifier = Modifier.testTag("nav_tab_${tab.route}"),
                    icon = {
                        Icon(
                            imageVector = if (selected) icons.first else icons.second,
                            contentDescription = label
                        )
                    },
                    label = {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = MaterialTheme.typography.bodySmall.fontFamily,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = activeTint,
                        selectedTextColor = activeTint,
                        indicatorColor = activeTint.copy(alpha = 0.14f),
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
            }
        }
    }
}

@Composable
fun SecurityLockScreen(
    report: IntegrityReport,
    onRecheck: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF1A040A), CyberBackground, Color(0xFF120307))
                )
            )
            .statusBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(88.dp)
                    .clip(CircleShape)
                    .background(CrimsonDim)
                    .border(2.dp, NeonCrimson, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.GppBad,
                    contentDescription = "Alerta Crítico de Segurança",
                    tint = NeonCrimson,
                    modifier = Modifier.size(48.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = SecurityIntegrityGuard.TAMPER_ALERT_MESSAGE,
                style = MaterialTheme.typography.headlineSmall,
                color = NeonCrimson,
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag("security_lock_alert_text")
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = stringResource(R.string.security_tamper_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = CyberSurface,
                border = BorderStroke(1.dp, NeonCrimson.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!report.failureReason.isNullOrBlank()) {
                        Text(
                            text = "DIAGNÓSTICO:",
                            style = MonoBadgeStyle,
                            color = NeonCrimson
                        )
                        Text(
                            text = report.failureReason,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary
                        )
                        HorizontalDivider(color = CyberBorder)
                    }

                    ForensicLine(
                        label = stringResource(R.string.security_detail_package),
                        value = report.detectedPackageName
                    )
                    ForensicLine(
                        label = stringResource(R.string.security_detail_label),
                        value = report.detectedAppName
                    )
                    ForensicLine(
                        label = stringResource(R.string.security_detail_hash),
                        value = report.currentCertSha256.ifBlank { "AUSENTE" }
                    )
                    if (report.expectedCertSha256.isNotBlank()) {
                        ForensicLine(
                            label = stringResource(R.string.security_detail_expected_hash),
                            value = report.expectedCertSha256
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = onRecheck,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonCrimson,
                    contentColor = TextPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("recheck_integrity_button")
            ) {
                Text(
                    text = stringResource(R.string.action_recheck_integrity),
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
private fun ForensicLine(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Text(text = value, style = MonoCodeStyle, color = TextPrimary)
    }
}
