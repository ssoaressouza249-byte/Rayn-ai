package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.scanner.FileScanReport
import com.example.scanner.ScanRiskLevel
import com.example.scanner.ScannedPermission
import com.example.ui.RaynMainUiState
import com.example.ui.theme.AmberDim
import com.example.ui.theme.CrimsonDim
import com.example.ui.theme.CyanDim
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.MonoBadgeStyle
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCrimson
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun VirusScannerScreen(
    uiState: RaynMainUiState,
    onFileSelected: (android.net.Uri) -> Unit
) {
    val openFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onFileSelected(uri)
    }

    val scanner = uiState.scannerState

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 720.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Column {
                Text(
                    text = stringResource(R.string.scanner_title),
                    style = MaterialTheme.typography.headlineSmall,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = stringResource(R.string.scanner_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }

            // Pick File / APK Trigger Card
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = CyberSurface,
                border = BorderStroke(1.dp, NeonCrimson.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Inspecione APKs, scripts, binários ou documentos localmente antes de executar ou instalar.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )

                    Button(
                        onClick = { openFileLauncher.launch(arrayOf("*/*")) },
                        enabled = !scanner.isScanning,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonCrimson,
                            contentColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("scanner_pick_file_button")
                    ) {
                        if (scanner.isScanning) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = TextPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Executando análise estática...", style = MaterialTheme.typography.labelLarge)
                        } else {
                            Icon(Icons.Filled.FileOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.scanner_pick_file),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }

            if (!scanner.errorMessage.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = CrimsonDim,
                    border = BorderStroke(1.dp, NeonCrimson),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = scanner.errorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            val report = scanner.report
            if (report == null && !scanner.isScanning) {
                EmptyScannerState()
            } else if (report != null) {
                ScanReportView(report = report)
            }
        }
    }
}

@Composable
private fun EmptyScannerState() {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = CyberSurface,
        border = BorderStroke(1.dp, CyberBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(CyberSurfaceElevated)
                    .border(1.dp, CyberBorder, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Security,
                    contentDescription = null,
                    tint = NeonBlue,
                    modifier = Modifier.size(28.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = stringResource(R.string.scanner_empty_title),
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = stringResource(R.string.scanner_empty_body),
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun ScanReportView(report: FileScanReport) {
    val clipboard = LocalClipboardManager.current

    val (badgeLabel, accentColor, bgColor, icon) = when (report.riskLevel) {
        ScanRiskLevel.SAFE -> Quad(
            stringResource(R.string.scanner_status_safe),
            NeonBlue,
            CyanDim,
            Icons.Filled.GppGood
        )
        ScanRiskLevel.WARNING -> Quad(
            stringResource(R.string.scanner_status_warning),
            NeonAmber,
            AmberDim,
            Icons.Filled.WarningAmber
        )
        ScanRiskLevel.HIGH_RISK -> Quad(
            stringResource(R.string.scanner_status_high_risk),
            NeonCrimson,
            CrimsonDim,
            Icons.Filled.GppBad
        )
    }

    // Risk Verdict Card
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = bgColor.copy(alpha = 0.75f),
        border = BorderStroke(1.5.dp, accentColor),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("scanner_verdict_card")
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = badgeLabel,
                tint = accentColor,
                modifier = Modifier.size(34.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "DIAGNÓSTICO: $badgeLabel",
                    style = MonoBadgeStyle.copy(fontSize = MaterialTheme.typography.titleSmall.fontSize),
                    color = accentColor
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = report.riskSummary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary
                )
            }
        }
    }

    // Technical Telemetry & SHA-256 Card
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = CyberSurface,
        border = BorderStroke(1.dp, CyberBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("TELEMETRIA DO ARQUIVO", style = MonoBadgeStyle, color = NeonBlue)
            TelemetryRow("Nome", report.fileName)
            TelemetryRow("Tamanho", formatSize(report.sizeBytes))
            TelemetryRow("Tipo Real (Magic Bytes)", report.magicType)
            TelemetryRow("Assinatura Hex", report.magicHeaderHex)

            HorizontalDivider(color = CyberBorder)

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("SHA-256", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(report.sha256, style = MonoCodeStyle, color = NeonBlue)
                }
                IconButton(
                    onClick = { clipboard.setText(AnnotatedString(report.sha256)) }
                ) {
                    Icon(
                        imageVector = Icons.Filled.ContentCopy,
                        contentDescription = "Copiar SHA-256",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            if (report.findings.isNotEmpty()) {
                HorizontalDivider(color = CyberBorder)
                Text("INDICADORES DETECTADOS", style = MonoBadgeStyle, color = accentColor)
                report.findings.forEach { finding ->
                    Text("• $finding", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                }
            }
        }
    }

    // APK Manifest & Permissions Inspector
    val apk = report.apkMetadata
    if (apk != null) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = CyberSurface,
            border = BorderStroke(1.dp, CyberBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("INSPEÇÃO DE PACOTE APK", style = MonoBadgeStyle, color = NeonBlue)
                TelemetryRow("Pacote", apk.packageName)
                TelemetryRow("Versão", "${apk.versionName} (code ${apk.versionCode})")
                TelemetryRow(
                    "SDK",
                    "minSdk ${apk.minSdk ?: "N/D"} • targetSdk ${apk.targetSdk ?: "N/D"}"
                )
                TelemetryRow(
                    "Componentes Internos",
                    "${apk.dexCount} DEX • ${apk.nativeLibCount} libs .so • ${apk.embeddedArchiveCount} arquivos embutidos"
                )
                if (!apk.signerSha256.isNullOrBlank()) {
                    TelemetryRow("Certificado APK (SHA-256)", apk.signerSha256)
                }

                HorizontalDivider(color = CyberBorder)

                Text(
                    text = "PERMISSÕES SOLICITADAS (${apk.permissions.size})",
                    style = MonoBadgeStyle,
                    color = TextSecondary
                )

                if (apk.permissions.isEmpty()) {
                    Text(
                        text = "Nenhuma permissão declarada no AndroidManifest.",
                        style = MaterialTheme.typography.bodySmall,
                        color = NeonBlue
                    )
                } else {
                    apk.permissions.forEach { perm ->
                        PermissionItemRow(permission = perm)
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionItemRow(permission: ScannedPermission) {
    val badgeColor = when {
        permission.isCritical -> NeonCrimson
        permission.isElevated -> NeonAmber
        else -> NeonBlue
    }
    val badgeText = when {
        permission.isCritical -> "CRÍTICA"
        permission.isElevated -> "SENSÍVEL"
        else -> "PADRÃO"
    }
    val container = when {
        permission.isCritical -> CrimsonDim.copy(alpha = 0.5f)
        permission.isElevated -> AmberDim.copy(alpha = 0.45f)
        else -> CyberBackground
    }

    Surface(
        shape = RoundedCornerShape(10.dp),
        color = container,
        border = BorderStroke(1.dp, badgeColor.copy(alpha = if (permission.isCritical) 0.8f else 0.3f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = permission.shortName,
                    style = MonoBadgeStyle,
                    color = if (permission.isCritical) NeonCrimson else TextPrimary,
                    modifier = Modifier.weight(1f)
                )
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = badgeColor.copy(alpha = 0.16f),
                    border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.6f))
                ) {
                    Text(
                        text = badgeText,
                        style = MonoBadgeStyle,
                        color = badgeColor,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = permission.description,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun TelemetryRow(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Text(text = value, style = MonoCodeStyle, color = TextPrimary)
    }
}

private fun formatSize(bytes: Long): String {
    return when {
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> String.format(Locale.US, "%.2f KB (%d B)", bytes / 1024.0, bytes)
        else -> String.format(Locale.US, "%.2f MB (%d B)", bytes / (1024.0 * 1024.0), bytes)
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
