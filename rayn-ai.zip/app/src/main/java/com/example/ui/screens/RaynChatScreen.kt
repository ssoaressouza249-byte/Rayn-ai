package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.ChatMessageUi
import com.example.ui.RaynMainUiState
import com.example.ui.theme.CrimsonDim
import com.example.ui.theme.CyanDim
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderBright
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberSurfaceInput
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MonoBadgeStyle
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCrimson
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun RaynChatScreen(
    uiState: RaynMainUiState,
    onInputChanged: (String) -> Unit,
    onAttachDocument: (android.net.Uri) -> Unit,
    onClearAttachment: () -> Unit,
    onSend: () -> Unit,
    onSaveMessageToFolder: (String) -> Unit,
    onClearChat: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val openDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onAttachDocument(uri)
    }

    val listState = rememberLazyListState()
    LaunchedEffect(uiState.chatMessages.size) {
        if (uiState.chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.chatMessages.lastIndex)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp)
        ) {
            // Top SAF Folder Status + Clear Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val safFolder = uiState.preferences.safFolderDisplay
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (safFolder != null) CyanDim.copy(alpha = 0.55f) else CyberSurface,
                    border = BorderStroke(
                        1.dp,
                        if (safFolder != null) NeonBlue.copy(alpha = 0.5f) else NeonAmber.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable(onClick = onNavigateToSettings)
                        .testTag("chat_saf_status_chip")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.FolderOpen,
                            contentDescription = null,
                            tint = if (safFolder != null) NeonBlue else NeonAmber,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (safFolder != null) "Pasta SAF: $safFolder" else stringResource(R.string.chat_folder_not_set),
                            style = MonoBadgeStyle,
                            color = if (safFolder != null) NeonBlue else NeonAmber,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (uiState.chatMessages.isNotEmpty()) {
                    IconButton(
                        onClick = onClearChat,
                        modifier = Modifier.testTag("clear_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteSweep,
                            contentDescription = stringResource(R.string.chat_clear),
                            tint = TextSecondary
                        )
                    }
                }
            }

            // Missing API Key Alert Banner
            if (uiState.preferences.geminiApiKey.isBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = CrimsonDim.copy(alpha = 0.7f),
                    border = BorderStroke(1.dp, NeonCrimson.copy(alpha = 0.6f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                        .clickable(onClick = onNavigateToSettings)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ErrorOutline,
                            contentDescription = null,
                            tint = NeonCrimson,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.chat_api_key_missing),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary
                        )
                    }
                }
            }

            // Messages or Welcome Hero
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (uiState.chatMessages.isEmpty()) {
                    ChatWelcomeHero(
                        onAttachClick = { openDocLauncher.launch(arrayOf("*/*")) },
                        onSuggestionClick = { suggestion -> onInputChanged(suggestion) }
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(uiState.chatMessages, key = { it.id }) { msg ->
                            ChatMessageBubble(
                                message = msg,
                                onSaveClick = { onSaveMessageToFolder(msg.id) },
                                onNavigateToSettings = onNavigateToSettings
                            )
                        }

                        if (uiState.isChatLoading) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = CyberSurface,
                                    border = BorderStroke(1.dp, CyberBorderBright),
                                    modifier = Modifier.fillMaxWidth(0.75f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(16.dp),
                                            color = NeonBlue,
                                            strokeWidth = 2.dp
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = "Rayn AI processando...",
                                            style = MonoBadgeStyle,
                                            color = NeonBlue
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Error banner
            if (!uiState.chatErrorBanner.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = CrimsonDim,
                    border = BorderStroke(1.dp, NeonCrimson),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = uiState.chatErrorBanner,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            // Attachment preview chip
            val attached = uiState.attachedFile
            if (attached != null) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = CyberSurfaceElevated,
                    border = BorderStroke(1.dp, NeonBlue.copy(alpha = 0.65f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Description,
                            contentDescription = null,
                            tint = NeonBlue,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = attached.fileName,
                                style = MaterialTheme.typography.labelLarge,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${attached.sizeBytes} bytes • ${attached.mimeType}",
                                style = MonoCodeStyle,
                                color = NeonBlue.copy(alpha = 0.8f),
                                maxLines = 1
                            )
                        }
                        IconButton(
                            onClick = onClearAttachment,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Remover anexo",
                                tint = NeonCrimson,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // Bottom Composer
            Surface(
                color = CyberSurface,
                border = BorderStroke(1.dp, CyberBorder),
                shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    IconButton(
                        onClick = { openDocLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(CyberSurfaceElevated)
                            .border(1.dp, CyberBorderBright, RoundedCornerShape(12.dp))
                            .testTag("attach_file_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AttachFile,
                            contentDescription = stringResource(R.string.chat_attach_file),
                            tint = NeonBlue
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    OutlinedTextField(
                        value = uiState.chatInput,
                        onValueChange = onInputChanged,
                        placeholder = {
                            Text(
                                text = stringResource(R.string.chat_input_hint),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextMuted
                            )
                        },
                        maxLines = 4,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CyberSurfaceInput,
                            unfocusedContainerColor = CyberSurfaceInput,
                            focusedBorderColor = NeonBlue,
                            unfocusedBorderColor = CyberBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = NeonBlue
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_input_field")
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    val canSend = (uiState.chatInput.isNotBlank() || uiState.attachedFile != null) && !uiState.isChatLoading
                    IconButton(
                        onClick = onSend,
                        enabled = canSend,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (canSend) Brush.linearGradient(listOf(ElectricBlue, NeonBlue))
                                else Brush.linearGradient(listOf(CyberSurfaceElevated, CyberSurfaceElevated))
                            )
                            .testTag("send_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = stringResource(R.string.chat_send),
                            tint = if (canSend) CyberBackground else TextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatWelcomeHero(
    onAttachClick: () -> Unit,
    onSuggestionClick: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(18.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = CyberSurface,
            border = BorderStroke(1.dp, CyberBorderBright),
            modifier = Modifier
                .fillMaxWidth()
                .drawBehind {
                    drawLine(
                        color = NeonBlue.copy(alpha = 0.08f),
                        start = Offset(0f, size.height * 0.25f),
                        end = Offset(size.width, size.height * 0.25f),
                        strokeWidth = 1.dp.toPx()
                    )
                    drawLine(
                        color = NeonCrimson.copy(alpha = 0.08f),
                        start = Offset(0f, size.height * 0.75f),
                        end = Offset(size.width, size.height * 0.75f),
                        strokeWidth = 1.dp.toPx()
                    )
                }
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(CyanDim)
                        .border(1.5.dp, NeonBlue, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        tint = NeonBlue,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = stringResource(R.string.chat_welcome_title),
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = stringResource(R.string.chat_welcome_body),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedButton(
                    onClick = onAttachClick,
                    border = BorderStroke(1.dp, NeonBlue),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonBlue),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.AttachFile, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Anexar Arquivo (.txt, .json, .xml, .kt, .html, .csv)")
                }

                Spacer(modifier = Modifier.height(12.dp))

                val suggestions = listOf(
                    "Crie um arquivo config.json para meu app e salve como config.json",
                    "Monte blocos padrão Sketchware (onCreate e onClick) para salvar notas do app",
                    "Crie um utilitário de sobreposição visual simples (Crosshair) em Kotlin"
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    suggestions.forEach { suggestion ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = CyberSurfaceElevated,
                            border = BorderStroke(1.dp, CyberBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onSuggestionClick(suggestion) }
                        ) {
                            Text(
                                text = suggestion,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatMessageBubble(
    message: ChatMessageUi,
    onSaveClick: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val clipboard = LocalClipboardManager.current
    val isUser = message.isUser

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            color = if (isUser) Color(0xFF102246) else CyberSurface,
            border = BorderStroke(
                1.dp,
                if (isUser) ElectricBlue.copy(alpha = 0.6f) else CyberBorderBright
            ),
            modifier = Modifier.fillMaxWidth(0.92f)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                if (!message.attachedFileName.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = CyanDim,
                        border = BorderStroke(1.dp, NeonBlue.copy(alpha = 0.5f)),
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Description,
                                contentDescription = null,
                                tint = NeonBlue,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Anexo: ${message.attachedFileName}",
                                style = MonoBadgeStyle,
                                color = NeonBlue
                            )
                        }
                    }
                }

                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary
                )

                if (!isUser && message.hasFilePreview && message.savableContent.isNotBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = CyberBackground,
                        border = BorderStroke(1.dp, CyberBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = buildString {
                                        if (!message.generatedSubfolder.isNullOrBlank()) {
                                            append("${message.generatedSubfolder}/")
                                        }
                                        append(message.generatedFileName ?: "arquivo.txt")
                                    },
                                    style = MonoBadgeStyle,
                                    color = NeonBlue,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                IconButton(
                                    onClick = { clipboard.setText(AnnotatedString(message.savableContent)) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.ContentCopy,
                                        contentDescription = "Copiar código",
                                        tint = TextSecondary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = message.savableContent.take(1600),
                                style = MonoCodeStyle,
                                color = TextSecondary
                            )
                        }
                    }
                }

                // Neon Blue confirmation banner when saved
                if (!message.savedConfirmationBanner.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = CyanDim,
                        border = BorderStroke(1.dp, NeonBlue),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("saved_confirmation_${message.id}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = null,
                                tint = NeonBlue,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = message.savedConfirmationBanner,
                                style = MonoBadgeStyle,
                                color = NeonBlue
                            )
                        }
                    }
                }

                // Save error banner
                if (!message.saveErrorBanner.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = CrimsonDim,
                        border = BorderStroke(1.dp, NeonCrimson),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(onClick = onNavigateToSettings)
                    ) {
                        Text(
                            text = message.saveErrorBanner,
                            style = MaterialTheme.typography.bodySmall,
                            color = NeonCrimson,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                        )
                    }
                }

                // Save to Folder action button present on every generated message/file
                if (!isUser) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = onSaveClick,
                            border = BorderStroke(1.dp, NeonBlue.copy(alpha = 0.8f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonBlue),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("save_message_button_${message.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Save,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.chat_save_to_folder),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }

                        IconButton(
                            onClick = {
                                clipboard.setText(
                                    AnnotatedString(
                                        message.savableContent.ifBlank { message.text }
                                    )
                                )
                            },
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ContentCopy,
                                contentDescription = "Copiar texto",
                                tint = TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
