package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberDeepBlack = Color(0xFF06080F)
val CyberGraphite = Color(0xFF0D121F)
val CyberGraphiteElevated = Color(0xFF121A2C)
val CyberBorder = Color(0xFF1A2642)
val CyberBorderGlow = Color(0xFF243B6B)

val NeonBlue = Color(0xFF00E5FF)
val ElectricBlue = Color(0xFF2979FF)
val DeepBlueAccent = Color(0xFF0B253A)

val NeonCrimson = Color(0xFFFF1E42)
val CrimsonSurface = Color(0xFF2A0B14)

val CyberGreen = Color(0xFF00E676)
val CyberGreenSurface = Color(0xFF07291B)

val CyberAmber = Color(0xFFFFB300)
val CyberAmberSurface = Color(0xFF2A1E05)

val CyberTextPrimary = Color(0xFFF1F5FF)
val CyberTextSecondary = Color(0xFF94A3C4)
val CyberTextMuted = Color(0xFF5D6D8E)
