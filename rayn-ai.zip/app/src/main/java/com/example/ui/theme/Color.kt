package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyber Blue & Crimson Palette
val CyberBackground = Color(0xFF06080F)
val CyberSurface = Color(0xFF0D121F)
val CyberSurfaceElevated = Color(0xFF131B2E)
val CyberSurfaceInput = Color(0xFF0A0F1A)
val CyberBorder = Color(0xFF1A2642)
val CyberBorderBright = Color(0xFF283C66)

val NeonBlue = Color(0xFF00E5FF)
val ElectricBlue = Color(0xFF2979FF)
val NeonCrimson = Color(0xFFFF1E42)
val CrimsonDim = Color(0xFF3A0C18)
val NeonAmber = Color(0xFFFFB020)
val AmberDim = Color(0xFF332308)
val CyanDim = Color(0xFF092A38)

val TextPrimary = Color(0xFFF0F6FF)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF5D6B85)
