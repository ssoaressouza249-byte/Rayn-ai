package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.CrimsonSurface
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDeepBlack
import com.example.ui.theme.CyberGraphite
import com.example.ui.theme.CyberGraphiteElevated
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.DeepBlueAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCrimson
import com.example.viewmodel.ChatUiMessage
import com.example.viewmodel.RaynUiState

@Composable
fun ChatScreen(
    uiState: RaynUiState,
    onInputChange: (String) -> Unit,
    onAttachDocument: (android.net.Uri?) -> Unit,
    onClearAttachment: () -> Unit,
    onSendMessage: (String?) -> Unit,
    onSaveMessageToFolder: (ChatUiMessage, String) -> Unit,
    onGoToSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val openDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        onAttachDocument(uri)
    }

    var saveDialogTarget by remember { mutableStateOf<ChatUiMessage?>(null) }
    var saveDialogFileName by remember { mutableStateOf("") }

    val listState = rememberLazyListState()
    LaunchedEffect(uiState.chatMessages.size) {
        if (uiState.chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.chatMessages.lastIndex)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberDeepBlack),
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (uiState.chatMessages.isEmpty()) {
                item {
                    ChatWelcomeHero(
                        activeModel = uiState.settings.selectedModel,
                        hasApiKey = uiState.settings.geminiApiKey.isNotBlank(),
                        folderDisplayName = uiState.folderDisplayName,
                        onGoToSettings = onGoToSettings,
                        onQuickPrompt = { prompt ->
                            onInputChange(prompt)
                        },
                    )
                }
            }

            items(uiState.chatMessages, key = { it.id }) { msg ->
                ChatMessageBubble(
                    message = msg,
                    onRequestSave = {
                        saveDialogTarget = msg
                        saveDialogFileName = msg.suggestedFileName ?: "rayn_arquivo.txt"
                    },
                )
            }

            if (uiState.isChatLoading) {
                item {
                    Surface(
                        color = CyberGraphite,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, NeonBlue.copy(alpha = 0.5f)),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = NeonBlue,
                            )
                            Text(
                                text = "Rayn AI processando via ${uiState.settings.selectedModel.ifBlank { "Gemini" }}...",
                                style = MaterialTheme.typography.bodySmall,
                                color = NeonBlue,
                            )
                        }
                    }
                }
            }
        }

        // Bottom composer area
        Surface(
            color = CyberGraphite,
            border = BorderStroke(1.dp, CyberBorder),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (uiState.attachedFile != null) {
                    val file = uiState.attachedFile
                    Surface(
                        color = DeepBlueAccent,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, NeonBlue.copy(alpha = 0.7f)),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Description,
                                    contentDescription = "Arquivo anexado",
                                    tint = NeonBlue,
                                    modifier = Modifier.size(18.dp),
                                )
                                Text(
                                    text = "${file.name} (${file.sizeBytes / 1024} KB)",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = NeonBlue,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            IconButton(
                                onClick = onClearAttachment,
                                modifier = Modifier.size(32.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Close,
                                    contentDescription = "Remover anexo",
                                    tint = CyberTextSecondary,
                                    modifier = Modifier.size(16.dp),
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    IconButton(
                        onClick = { openDocLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(CyberGraphiteElevated)
                            .border(1.dp, CyberBorder, RoundedCornerShape(12.dp))
                            .testTag("attach_file_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AttachFile,
                            contentDescription = "Anexar arquivo do dispositivo",
                            tint = NeonBlue,
                        )
                    }

                    OutlinedTextField(
                        value = uiState.chatInput,
                        onValueChange = onInputChange,
                        placeholder = {
                            Text(
                                text = "Pergunte, edite arquivos ou peça para salvar...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = CyberTextMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        },
                        maxLines = 4,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_input_field"),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonBlue,
                            unfocusedBorderColor = CyberBorder,
                            focusedContainerColor = CyberDeepBlack,
                            unfocusedContainerColor = CyberDeepBlack,
                            focusedTextColor = CyberTextPrimary,
                            unfocusedTextColor = CyberTextPrimary,
                            cursorColor = NeonBlue,
                        ),
                    )

                    IconButton(
                        onClick = { onSendMessage(null) },
                        enabled = !uiState.isChatLoading &&
                            (uiState.chatInput.isNotBlank() || uiState.attachedFile != null),
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (!uiState.isChatLoading &&
                                    (uiState.chatInput.isNotBlank() || uiState.attachedFile != null)
                                ) NeonBlue else CyberGraphiteElevated
                            )
                            .testTag("send_chat_button"),
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Enviar mensagem",
                            tint = if (!uiState.isChatLoading &&
                                (uiState.chatInput.isNotBlank() || uiState.attachedFile != null)
                            ) CyberDeepBlack else CyberTextMuted,
                        )
                    }
                }
            }
        }
    }

    val target = saveDialogTarget
    if (target != null) {
        AlertDialog(
            onDismissRequest = { saveDialogTarget = null },
            containerColor = CyberGraphite,
            titleContentColor = CyberTextPrimary,
            textContentColor = CyberTextSecondary,
            title = {
                Text(
                    text = "Salvar na Pasta Padrão",
                    style = MaterialTheme.typography.titleMedium,
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Destino: ${uiState.folderDisplayName}",
                        style = MaterialTheme.typography.labelMedium,
                        color = NeonBlue,
                    )
                    OutlinedTextField(
                        value = saveDialogFileName,
                        onValueChange = { saveDialogFileName = it },
                        label = { Text("Nome e extensão do arquivo") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("save_filename_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonBlue,
                            unfocusedBorderColor = CyberBorder,
                            focusedTextColor = CyberTextPrimary,
                            unfocusedTextColor = CyberTextPrimary,
                            focusedLabelColor = NeonBlue,
                        ),
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSaveMessageToFolder(target, saveDialogFileName)
                        saveDialogTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonBlue,
                        contentColor = CyberDeepBlack,
                    ),
                    modifier = Modifier.testTag("confirm_save_file_button"),
                ) {
                    Text("Salvar Agora")
                }
            },
            dismissButton = {
                TextButton(onClick = { saveDialogTarget = null }) {
                    Text("Cancelar", color = CyberTextSecondary)
                }
            },
        )
    }
}

@Composable
private fun ChatWelcomeHero(
    activeModel: String,
    hasApiKey: Boolean,
    folderDisplayName: String,
    onGoToSettings: () -> Unit,
    onQuickPrompt: (String) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(
            color = CyberGraphite,
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, CyberBorder),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(145.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_rayn_banner_1794633909181),
                        contentDescription = "Banner Neural Rayn AI",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        CyberGraphite.copy(alpha = 0.95f)
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp),
                    ) {
                        Text(
                            text = "Rayn Chat Neural",
                            style = MaterialTheme.typography.headlineSmall,
                            color = CyberTextPrimary,
                        )
                        Text(
                            text = if (hasApiKey && activeModel.isNotBlank()) {
                                "Modelo ativo: $activeModel"
                            } else {
                                "Configure sua GEMINI_API_KEY em Ajustes para iniciar"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = if (hasApiKey) NeonBlue else NeonCrimson,
                        )
                    }
                }

                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(
                        text = "Anexe qualquer arquivo (.txt, .json, .xml, .kt, .html, .csv) para a IA ler, editar ou converter. Peça para salvar ou use o botão \"Salvar na Pasta\" em qualquer resposta.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextSecondary,
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.FolderOpen,
                            contentDescription = "Pasta de destino",
                            tint = NeonBlue,
                            modifier = Modifier.size(16.dp),
                        )
                        Text(
                            text = "Pasta: $folderDisplayName",
                            style = MaterialTheme.typography.labelMedium,
                            color = CyberTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        if (!hasApiKey) {
                            OutlinedButton(
                                onClick = onGoToSettings,
                                border = BorderStroke(1.dp, NeonBlue),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("hero_go_settings_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Settings,
                                    contentDescription = null,
                                    tint = NeonBlue,
                                    modifier = Modifier.size(14.dp),
                                )
                                Spacer(Modifier.width(6.dp))
                                Text("Ajustes", color = NeonBlue, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val presets = listOf(
                "Crie um arquivo config.json para app Android e salve na pasta",
                "Converta o arquivo anexado para CSV limpo e salve",
                "Gere blocos onCreate e onClick para Sketchware Pro",
            )
            presets.forEach { preset ->
                Surface(
                    color = CyberGraphiteElevated,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.45f)),
                    modifier = Modifier
                        .clickable { onQuickPrompt(preset) },
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = NeonBlue,
                            modifier = Modifier.size(14.dp),
                        )
                        Text(
                            text = preset,
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberTextPrimary,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatMessageBubble(
    message: ChatUiMessage,
    onRequestSave: () -> Unit,
) {
    val alignment = if (message.isUser) Alignment.End else Alignment.Start
    val containerColor = when {
        message.isError -> CrimsonSurface
        message.isUser -> DeepBlueAccent
        else -> CyberGraphite
    }
    val borderColor = when {
        message.isError -> NeonCrimson
        message.isUser -> ElectricBlue.copy(alpha = 0.7f)
        else -> CyberBorder
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = alignment,
    ) {
        Surface(
            color = containerColor,
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (message.isUser) 16.dp else 4.dp,
                bottomEnd = if (message.isUser) 4.dp else 16.dp,
            ),
            border = BorderStroke(1.dp, borderColor),
            modifier = Modifier.widthIn(max = 520.dp),
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (!message.attachmentName.isNullOrBlank()) {
                    Surface(
                        color = CyberDeepBlack.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, NeonBlue.copy(alpha = 0.4f)),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Description,
                                contentDescription = null,
                                tint = NeonBlue,
                                modifier = Modifier.size(14.dp),
                            )
                            Text(
                                text = message.attachmentName,
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonBlue,
                            )
                        }
                    }
                }

                SelectionContainer {
                    Text(
                        text = message.text,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (message.isError) NeonCrimson else CyberTextPrimary,
                    )
                }

                if (!message.isUser && !message.isError) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        if (message.autoSavedResult != null) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.weight(1f),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = "Salvo",
                                    tint = NeonBlue,
                                    modifier = Modifier.size(15.dp),
                                )
                                Text(
                                    text = "Salvo: ${message.autoSavedResult.fileName}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NeonBlue,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        } else {
                            Spacer(modifier = Modifier.weight(1f))
                        }

                        OutlinedButton(
                            onClick = onRequestSave,
                            border = BorderStroke(1.dp, NeonBlue.copy(alpha = 0.7f)),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("save_to_folder_btn_${message.id}"),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Save,
                                contentDescription = "Salvar na Pasta",
                                tint = NeonBlue,
                                modifier = Modifier.size(14.dp),
                            )
                            Spacer(Modifier.width(5.dp))
                            Text(
                                text = "Salvar na Pasta",
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonBlue,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                    }
                }
            }
        }
    }
}
