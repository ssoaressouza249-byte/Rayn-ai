package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.security.IntegrityReport
import com.example.ui.theme.CrimsonSurface
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDeepBlack
import com.example.ui.theme.CyberGraphite
import com.example.ui.theme.CyberGraphiteElevated
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.DeepBlueAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCrimson
import com.example.viewmodel.RaynTab

@Composable
fun RaynTopBar(
    credits: Int,
    maxCredits: Int,
    isProtected: Boolean,
    modifier: Modifier = Modifier,
) {
    val creditColor by animateColorAsState(
        targetValue = if (credits > 0) NeonBlue else NeonCrimson,
        label = "creditColor"
    )
    val creditBg = if (credits > 0) DeepBlueAccent else CrimsonSurface

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = CyberGraphite,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.statusBars)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(ElectricBlue.copy(alpha = 0.25f), NeonCrimson.copy(alpha = 0.2f))
                                )
                            )
                            .border(1.dp, NeonBlue.copy(alpha = 0.6f), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Shield,
                            contentDescription = "Emblema Rayn AI",
                            tint = NeonBlue,
                            modifier = Modifier.size(18.dp),
                        )
                    }
                    Column {
                        Text(
                            text = "Rayn AI",
                            style = MaterialTheme.typography.titleLarge,
                            color = CyberTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = "CYBER NEURAL CORE",
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonBlue.copy(alpha = 0.8f),
                            maxLines = 1,
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Surface(
                        color = creditBg,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, creditColor.copy(alpha = 0.7f)),
                        modifier = Modifier.testTag("top_credits_badge"),
                    ) {
                        Text(
                            text = "$credits/$maxCredits CRÉDITOS",
                            style = MaterialTheme.typography.labelSmall,
                            color = creditColor,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        )
                    }

                    Surface(
                        color = if (isProtected) CrimsonSurface.copy(alpha = 0.65f) else CrimsonSurface,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(
                            1.dp,
                            if (isProtected) NeonCrimson.copy(alpha = 0.7f) else NeonCrimson
                        ),
                        modifier = Modifier.testTag("top_shield_badge"),
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        ) {
                            Icon(
                                imageVector = if (isProtected) Icons.Filled.VerifiedUser else Icons.Filled.GppBad,
                                contentDescription = if (isProtected) "Protegido" else "Violação detectada",
                                tint = if (isProtected) NeonBlue else NeonCrimson,
                                modifier = Modifier.size(13.dp),
                            )
                            Text(
                                text = if (isProtected) "PROTEGIDO" else "ALERTA",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isProtected) NeonCrimson else Color.White,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                CyberBorder,
                                NeonBlue.copy(alpha = 0.7f),
                                NeonCrimson.copy(alpha = 0.7f),
                                CyberBorder,
                            )
                        )
                    )
            )
        }
    }
}

@Composable
fun RaynBottomNavBar(
    currentTab: RaynTab,
    onTabSelected: (RaynTab) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(CyberBorder)
        )
        NavigationBar(
            containerColor = CyberGraphite,
            contentColor = CyberTextPrimary,
            windowInsets = WindowInsets.navigationBars,
        ) {
            RaynTab.entries.forEach { tab ->
                val selected = tab == currentTab
                val (selectedIcon, unselectedIcon) = when (tab) {
                    RaynTab.CHAT -> Icons.Filled.ChatBubble to Icons.Outlined.ChatBubbleOutline
                    RaynTab.SWB -> Icons.Filled.Build to Icons.Outlined.Build
                    RaynTab.SCANNER -> Icons.Filled.Security to Icons.Outlined.Security
                    RaynTab.SETTINGS -> Icons.Filled.Settings to Icons.Outlined.Settings
                }
                NavigationBarItem(
                    selected = selected,
                    onClick = { onTabSelected(tab) },
                    modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}"),
                    icon = {
                        Icon(
                            imageVector = if (selected) selectedIcon else unselectedIcon,
                            contentDescription = tab.label,
                        )
                    },
                    label = {
                        Text(
                            text = tab.label,
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NeonBlue,
                        selectedTextColor = NeonBlue,
                        indicatorColor = DeepBlueAccent,
                        unselectedIconColor = CyberTextMuted,
                        unselectedTextColor = CyberTextMuted,
                    ),
                )
            }
        }
    }
}

@Composable
fun CyberCard(
    modifier: Modifier = Modifier,
    borderColor: Color = CyberBorder,
    containerColor: Color = CyberGraphite,
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = containerColor,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, borderColor),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            content = content,
        )
    }
}

@Composable
fun SecurityLockOverlay(
    report: IntegrityReport,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CyberDeepBlack)
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            color = CrimsonSurface,
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(2.dp, NeonCrimson),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("security_lock_overlay"),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(NeonCrimson.copy(alpha = 0.2f))
                        .border(2.dp, NeonCrimson, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Filled.GppBad,
                        contentDescription = "Alerta Crítico de Segurança",
                        tint = NeonCrimson,
                        modifier = Modifier.size(38.dp),
                    )
                }

                Text(
                    text = "ALERTA DE SEGURANÇA: Modificação não autorizada detectada no Rayn AI.",
                    style = MaterialTheme.typography.titleLarge,
                    color = NeonCrimson,
                    textAlign = TextAlign.Center,
                )

                Text(
                    text = report.failureReason
                        ?: "Assinatura ou identidade do aplicativo violada.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = CyberTextPrimary,
                    textAlign = TextAlign.Center,
                )

                Surface(
                    color = CyberGraphiteElevated,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, NeonCrimson.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text(
                            text = "Pacote atual: ${report.packageName}",
                            style = MaterialTheme.typography.labelMedium,
                            color = CyberTextSecondary,
                        )
                        Text(
                            text = "Nome atual: ${report.appLabel}",
                            style = MaterialTheme.typography.labelMedium,
                            color = CyberTextSecondary,
                        )
                        Text(
                            text = "SHA-256 atual: ${report.currentCertSha256.take(36)}...",
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonCrimson,
                        )
                    }
                }
            }
        }
    }
}
