package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.RaynSettingsState
import com.example.swb.SwbProjectGenerator
import com.example.ui.components.CyberCard
import com.example.ui.theme.CrimsonSurface
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDeepBlack
import com.example.ui.theme.CyberGraphiteElevated
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.DeepBlueAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCrimson
import com.example.viewmodel.RaynUiState

@Composable
fun SwbCreatorScreen(
    uiState: RaynUiState,
    onAppNameChange: (String) -> Unit,
    onPackageNameChange: (String) -> Unit,
    onDescriptionChange: (String) -> Unit,
    onUseAiChange: (Boolean) -> Unit,
    onApplyPreset: (String, String, String) -> Unit,
    onGenerateSwb: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val credits = uiState.settings.swbCredits
    val isLockedByCooldown = credits <= 0

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberDeepBlack)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // Credit Meter & Cooldown Card
        CyberCard(
            borderColor = if (isLockedByCooldown) NeonCrimson else NeonBlue.copy(alpha = 0.6f),
            containerColor = if (isLockedByCooldown) CrimsonSurface else CyberGraphiteElevated,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isLockedByCooldown) "Créditos .SWB Esgotados" else "Energia de Compilação .SWB",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (isLockedByCooldown) NeonCrimson else CyberTextPrimary,
                    )
                    Text(
                        text = if (isLockedByCooldown) {
                            uiState.cooldownFormatted.ifBlank { "Recarregando em 15h..." }
                        } else {
                            "Cada geração consome 1 crédito • Recarga automática em 15h ao zerar"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isLockedByCooldown) NeonCrimson else NeonBlue,
                    )
                }
                Icon(
                    imageVector = if (isLockedByCooldown) Icons.Filled.HourglassTop else Icons.Filled.FolderZip,
                    contentDescription = null,
                    tint = if (isLockedByCooldown) NeonCrimson else NeonBlue,
                    modifier = Modifier.size(28.dp),
                )
            }

            Spacer(Modifier.height(10.dp))

            LinearProgressIndicator(
                progress = { credits.toFloat() / RaynSettingsState.MAX_SWB_CREDITS.toFloat() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp),
                color = if (isLockedByCooldown) NeonCrimson else NeonBlue,
                trackColor = CyberDeepBlack,
            )
        }

        // Quick Presets
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "MODELOS RÁPIDOS SKETCHWARE PRO",
                style = MaterialTheme.typography.labelMedium,
                color = CyberTextSecondary,
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                val presets = listOf(
                    Triple(
                        "MiraVisual",
                        "com.rayn.miravisual",
                        "Utilitário visual inofensivo de mira/crosshair flutuante simples sem alterar arquivos ou memória de jogos."
                    ),
                    Triple(
                        "CalcCyber",
                        "com.rayn.calccyber",
                        "Calculadora escura com tela de resultado, campo numérico e evento onClick com Toast."
                    ),
                    Triple(
                        "NotasPro",
                        "com.rayn.notaspro",
                        "Bloco de notas rápido com campo de entrada, botão salvar e status visual."
                    ),
                )
                presets.forEach { (name, pkg, desc) ->
                    Surface(
                        color = DeepBlueAccent,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.6f)),
                        modifier = Modifier.clickable { onApplyPreset(name, pkg, desc) },
                    ) {
                        Text(
                            text = name,
                            style = MaterialTheme.typography.labelMedium,
                            color = NeonBlue,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        )
                    }
                }
            }
        }

        // Project Form
        CyberCard {
            Text(
                text = "Construtor de Projeto .SWB",
                style = MaterialTheme.typography.titleMedium,
                color = CyberTextPrimary,
            )
            Spacer(Modifier.height(10.dp))

            OutlinedTextField(
                value = uiState.swbAppName,
                onValueChange = onAppNameChange,
                label = { Text("Nome do Aplicativo") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("swb_app_name_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonBlue,
                    unfocusedBorderColor = CyberBorder,
                    focusedTextColor = CyberTextPrimary,
                    unfocusedTextColor = CyberTextPrimary,
                    focusedLabelColor = NeonBlue,
                ),
            )

            Spacer(Modifier.height(10.dp))

            OutlinedTextField(
                value = uiState.swbPackageName,
                onValueChange = onPackageNameChange,
                label = { Text("Package Name (ex: com.rayn.app)") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("swb_package_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonBlue,
                    unfocusedBorderColor = CyberBorder,
                    focusedTextColor = CyberTextPrimary,
                    unfocusedTextColor = CyberTextPrimary,
                    focusedLabelColor = NeonBlue,
                ),
            )

            Spacer(Modifier.height(10.dp))

            OutlinedTextField(
                value = uiState.swbDescription,
                onValueChange = onDescriptionChange,
                label = { Text("Funções, widgets e lógica desejada") },
                placeholder = { Text("Ex: Tela com botão onClick, TextView de status e entrada de texto...") },
                minLines = 3,
                maxLines = 5,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("swb_description_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonBlue,
                    unfocusedBorderColor = CyberBorder,
                    focusedTextColor = CyberTextPrimary,
                    unfocusedTextColor = CyberTextPrimary,
                    focusedLabelColor = NeonBlue,
                ),
            )

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = NeonBlue,
                            modifier = Modifier.size(16.dp),
                        )
                        Text(
                            text = "Gerar layout & blocos com Rayn AI",
                            style = MaterialTheme.typography.titleSmall,
                            color = CyberTextPrimary,
                        )
                    }
                    Text(
                        text = if (uiState.swbUseAi) {
                            "Usa o modelo Gemini ativo para montar views e eventos"
                        } else {
                            "Gera estrutura JSON/XML padrão offline instantaneamente"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextSecondary,
                    )
                }
                Switch(
                    checked = uiState.swbUseAi,
                    onCheckedChange = onUseAiChange,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = CyberDeepBlack,
                        checkedTrackColor = NeonBlue,
                    ),
                    modifier = Modifier.testTag("swb_ai_switch"),
                )
            }

            Spacer(Modifier.height(8.dp))

            Text(
                text = "Destino: ${if (uiState.settings.savedFolderUri.isNotBlank()) uiState.folderDisplayName else "Downloads/RaynAI (MediaStore)"}",
                style = MaterialTheme.typography.labelMedium,
                color = CyberTextMuted,
            )

            if (!uiState.swbError.isNullOrBlank()) {
                Spacer(Modifier.height(10.dp))
                Surface(
                    color = CrimsonSurface,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, NeonCrimson),
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Warning,
                            contentDescription = null,
                            tint = NeonCrimson,
                            modifier = Modifier.size(18.dp),
                        )
                        Text(
                            text = uiState.swbError,
                            style = MaterialTheme.typography.bodySmall,
                            color = NeonCrimson,
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            Button(
                onClick = onGenerateSwb,
                enabled = !isLockedByCooldown && !uiState.isGeneratingSwb,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonBlue,
                    contentColor = CyberDeepBlack,
                    disabledContainerColor = CrimsonSurface,
                    disabledContentColor = NeonCrimson,
                ),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(vertical = 14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("generate_swb_button"),
            ) {
                if (uiState.isGeneratingSwb) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = CyberDeepBlack,
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Empacotando .SWB...", fontWeight = FontWeight.Bold)
                } else if (isLockedByCooldown) {
                    Icon(Icons.Filled.HourglassTop, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = uiState.cooldownFormatted.ifBlank { "Bloqueado (15h)" },
                        fontWeight = FontWeight.Bold,
                    )
                } else {
                    Icon(Icons.Filled.Archive, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Gerar e Salvar .SWB (-1 Crédito)", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Generated Result Card
        val result = uiState.lastSwbResult
        if (result != null) {
            CyberCard(borderColor = CyberGreen.copy(alpha = 0.7f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = CyberGreen,
                    )
                    Column {
                        Text(
                            text = "${result.savedFile.fileName} pronto!",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberGreen,
                        )
                        Text(
                            text = "Salvo em: ${result.savedFile.locationLabel} (${result.savedFile.sizeBytes} bytes)",
                            style = MaterialTheme.typography.labelMedium,
                            color = CyberTextSecondary,
                        )
                    }
                }

                Spacer(Modifier.height(10.dp))

                Text(
                    text = "Entradas ZIP empacotadas: ${result.entries.joinToString(", ")}",
                    style = MaterialTheme.typography.labelMedium,
                    color = NeonBlue,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Lógica: ${result.logicSummary}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberTextSecondary,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "SHA-256: ${result.sha256.take(36)}...",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberTextMuted,
                )

                Spacer(Modifier.height(12.dp))

                Button(
                    onClick = {
                        val intent = SwbProjectGenerator.buildShareWithSketchwareIntent(
                            context = context,
                            fileUri = result.savedFile.uri,
                            fileName = result.savedFile.fileName,
                        )
                        context.startActivity(intent)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricBlue,
                        contentColor = CyberTextPrimary,
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("share_swb_button"),
                ) {
                    Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Compartilhar com Sketchware Pro", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
