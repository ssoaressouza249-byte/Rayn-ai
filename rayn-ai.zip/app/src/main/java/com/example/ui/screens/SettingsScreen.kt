package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.RaynPreferencesRepository
import com.example.ui.RaynMainUiState
import com.example.ui.theme.CrimsonDim
import com.example.ui.theme.CyanDim
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceInput
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MonoBadgeStyle
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCrimson
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SettingsScreen(
    uiState: RaynMainUiState,
    onApiKeyDraftChange: (String) -> Unit,
    onSaveApiKey: () -> Unit,
    onTestConnection: () -> Unit,
    onSafFolderPicked: (android.net.Uri) -> Unit,
    onRecheckIntegrity: () -> Unit
) {
    val openTreeLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) onSafFolderPicked(uri)
    }

    var showApiKey by remember { mutableStateOf(false) }
    val settings = uiState.settingsState
    val prefs = uiState.preferences

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 720.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Column {
                Text(
                    text = stringResource(R.string.settings_title),
                    style = MaterialTheme.typography.headlineSmall,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = stringResource(R.string.settings_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }

            // 1. Gemini API Key & Connection Test
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = CyberSurface,
                border = BorderStroke(1.dp, CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Key, contentDescription = null, tint = NeonBlue, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.settings_gemini_section),
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                    }

                    OutlinedTextField(
                        value = settings.apiKeyDraft,
                        onValueChange = onApiKeyDraftChange,
                        label = { Text(stringResource(R.string.settings_api_key_label)) },
                        placeholder = { Text(stringResource(R.string.settings_api_key_hint), color = TextMuted) },
                        singleLine = true,
                        visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showApiKey = !showApiKey }) {
                                Icon(
                                    imageVector = if (showApiKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    contentDescription = if (showApiKey) "Ocultar chave" else "Mostrar chave",
                                    tint = TextSecondary
                                )
                            }
                        },
                        textStyle = MonoCodeStyle.copy(color = TextPrimary),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CyberSurfaceInput,
                            unfocusedContainerColor = CyberSurfaceInput,
                            focusedBorderColor = NeonBlue,
                            unfocusedBorderColor = CyberBorder,
                            focusedLabelColor = NeonBlue,
                            unfocusedLabelColor = TextSecondary,
                            cursorColor = NeonBlue
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_api_key_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onSaveApiKey,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ElectricBlue,
                                contentColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("settings_save_key_button")
                        ) {
                            Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.settings_save_key))
                        }

                        OutlinedButton(
                            onClick = onTestConnection,
                            enabled = !settings.isTestingConnection,
                            border = BorderStroke(1.dp, NeonBlue),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonBlue),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("settings_test_connection_button")
                        ) {
                            if (settings.isTestingConnection) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = NeonBlue,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(Icons.Filled.NetworkCheck, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.settings_test_connection))
                        }
                    }

                    if (!settings.keySavedBanner.isNullOrBlank()) {
                        StatusBanner(text = settings.keySavedBanner, isSuccess = true)
                    }

                    val testRes = settings.testResult
                    if (testRes != null) {
                        StatusBanner(text = testRes.message, isSuccess = testRes.success)
                    }
                }
            }

            // 2. SAF Default Save Folder
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = CyberSurface,
                border = BorderStroke(1.dp, CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = NeonBlue, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.settings_storage_section),
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                    }

                    Text(
                        text = "Concede acesso persistente via Storage Access Framework para leitura, edição e criação automática de arquivos e subpastas.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = CyberBackground,
                        border = BorderStroke(1.dp, if (prefs.safFolderDisplay != null) NeonBlue.copy(alpha = 0.5f) else CyberBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("PASTA ATUAL", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text(
                                text = prefs.safFolderDisplay ?: stringResource(R.string.settings_no_folder),
                                style = MonoCodeStyle,
                                color = if (prefs.safFolderDisplay != null) NeonBlue else TextMuted
                            )
                        }
                    }

                    Button(
                        onClick = { openTreeLauncher.launch(null) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyanDim,
                            contentColor = NeonBlue
                        ),
                        border = BorderStroke(1.dp, NeonBlue),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("settings_pick_saf_folder_button")
                    ) {
                        Icon(Icons.Filled.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.settings_pick_folder), style = MaterialTheme.typography.labelLarge)
                    }

                    if (!settings.folderSavedBanner.isNullOrBlank()) {
                        StatusBanner(text = settings.folderSavedBanner, isSuccess = true)
                    }
                }
            }

            // 3. Credits Status Summary
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = CyberSurface,
                border = BorderStroke(1.dp, CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = stringResource(R.string.settings_credits_section),
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Saldo atual .SWB", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                        Text(
                            text = "${prefs.swbCredits}/${RaynPreferencesRepository.MAX_SWB_CREDITS} CRÉDITOS",
                            style = MonoBadgeStyle,
                            color = if (prefs.swbCredits > 0) NeonBlue else NeonCrimson
                        )
                    }
                    Text(
                        text = "Ciclo automático de recarga: 15 horas (54.000.000 ms) após zerar os créditos.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            // 4. SecurityIntegrityGuard Live Telemetry
            val report = uiState.integrityReport
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = CyberSurface,
                border = BorderStroke(1.dp, NeonCrimson.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.GppGood, contentDescription = null, tint = NeonCrimson, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.settings_integrity_section),
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                    }

                    if (report != null) {
                        TelemetryEntry("Pacote Verificado", report.detectedPackageName)
                        TelemetryEntry("Nome Oficial", report.detectedAppName)
                        TelemetryEntry(
                            "Certificado APK (SHA-256)",
                            report.currentCertSha256.ifBlank { "Calculando..." }
                        )
                        HorizontalDivider(color = CyberBorder)
                        StatusBanner(
                            text = if (report.isValid) {
                                "Integridade verificada • Proteção anti-crack ativa"
                            } else {
                                report.failureReason ?: "Violação detectada"
                            },
                            isSuccess = report.isValid
                        )
                    }

                    OutlinedButton(
                        onClick = onRecheckIntegrity,
                        border = BorderStroke(1.dp, NeonCrimson.copy(alpha = 0.7f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCrimson),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(stringResource(R.string.action_recheck_integrity))
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusBanner(text: String, isSuccess: Boolean) {
    val accent = if (isSuccess) NeonBlue else NeonCrimson
    val bg = if (isSuccess) CyanDim else CrimsonDim
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = bg,
        border = BorderStroke(1.dp, accent),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isSuccess) Icons.Filled.CheckCircle else Icons.Filled.ErrorOutline,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = text, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
        }
    }
}

@Composable
private fun TelemetryEntry(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Text(text = value, style = MonoCodeStyle, color = NeonBlue)
    }
}
