package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.GeminiModelInfo
import com.example.ui.components.CyberCard
import com.example.ui.theme.CrimsonSurface
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDeepBlack
import com.example.ui.theme.CyberGraphite
import com.example.ui.theme.CyberGraphiteElevated
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberGreenSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCrimson
import com.example.viewmodel.RaynUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    uiState: RaynUiState,
    onApiKeyChange: (String) -> Unit,
    onSaveAndSyncModels: () -> Unit,
    onSelectModel: (GeminiModelInfo) -> Unit,
    onTestConnection: () -> Unit,
    onFolderSelected: (android.net.Uri?) -> Unit,
    onVerifyIntegrity: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        onFolderSelected(uri)
    }

    var showApiKey by remember { mutableStateOf(false) }
    var dropdownExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberDeepBlack)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // 1. Gemini API Key & Dynamic Models
        CyberCard(borderColor = NeonBlue.copy(alpha = 0.5f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.Key,
                    contentDescription = null,
                    tint = NeonBlue,
                    modifier = Modifier.size(20.dp),
                )
                Text(
                    text = "Conexão Dinâmica Gemini (Zero 404)",
                    style = MaterialTheme.typography.titleMedium,
                    color = CyberTextPrimary,
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Ao salvar sua GEMINI_API_KEY, o Rayn AI consulta a rota /v1beta/models da sua conta para listar os modelos realmente ativos.",
                style = MaterialTheme.typography.bodySmall,
                color = CyberTextSecondary,
            )
            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = uiState.apiKeyDraft,
                onValueChange = onApiKeyChange,
                label = { Text("GEMINI_API_KEY") },
                placeholder = { Text("AIzaSy...") },
                singleLine = true,
                visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { showApiKey = !showApiKey }) {
                        Icon(
                            imageVector = if (showApiKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = if (showApiKey) "Ocultar chave" else "Mostrar chave",
                            tint = CyberTextSecondary,
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("api_key_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonBlue,
                    unfocusedBorderColor = CyberBorder,
                    focusedTextColor = CyberTextPrimary,
                    unfocusedTextColor = CyberTextPrimary,
                    focusedLabelColor = NeonBlue,
                ),
            )

            Spacer(Modifier.height(10.dp))

            Button(
                onClick = onSaveAndSyncModels,
                enabled = !uiState.isFetchingModels,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonBlue,
                    contentColor = CyberDeepBlack,
                ),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(vertical = 12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("save_api_key_button"),
            ) {
                if (uiState.isFetchingModels) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = CyberDeepBlack,
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Consultando rota /models...", fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Filled.CloudSync, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Salvar Chave & Listar Modelos Reais", fontWeight = FontWeight.Bold)
                }
            }

            if (!uiState.modelsError.isNullOrBlank()) {
                Spacer(Modifier.height(10.dp))
                Surface(
                    color = CrimsonSurface,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, NeonCrimson),
                ) {
                    Text(
                        text = uiState.modelsError,
                        style = MaterialTheme.typography.bodySmall,
                        color = NeonCrimson,
                        modifier = Modifier.padding(10.dp),
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            // Dynamic Model Dropdown Selector
            val models = uiState.settings.availableModels
            val selectedModelId = uiState.settings.selectedModel

            ExposedDropdownMenuBox(
                expanded = dropdownExpanded,
                onExpandedChange = {
                    if (models.isNotEmpty()) dropdownExpanded = !dropdownExpanded
                },
            ) {
                OutlinedTextField(
                    value = selectedModelId.ifBlank {
                        if (models.isEmpty()) "Salve a chave para carregar modelos" else "Escolha um modelo"
                    },
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Modelo Gemini Ativo (${models.size} disponíveis)") },
                    trailingIcon = {
                        ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        .testTag("model_dropdown"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonBlue,
                        unfocusedBorderColor = CyberBorder,
                        focusedTextColor = CyberTextPrimary,
                        unfocusedTextColor = CyberTextPrimary,
                        focusedLabelColor = NeonBlue,
                    ),
                )

                ExposedDropdownMenu(
                    expanded = dropdownExpanded,
                    onDismissRequest = { dropdownExpanded = false },
                    containerColor = CyberGraphiteElevated,
                ) {
                    models.forEach { model ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(
                                        text = model.id,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (model.id == selectedModelId) NeonBlue else CyberTextPrimary,
                                        fontWeight = FontWeight.Bold,
                                    )
                                    if (model.displayName.isNotBlank() && model.displayName != model.id) {
                                        Text(
                                            text = model.displayName,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = CyberTextSecondary,
                                        )
                                    }
                                }
                            },
                            onClick = {
                                onSelectModel(model)
                                dropdownExpanded = false
                            },
                        )
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            OutlinedButton(
                onClick = onTestConnection,
                enabled = !uiState.isTestingConnection && uiState.settings.selectedModel.isNotBlank(),
                border = BorderStroke(1.dp, ElectricBlue),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(vertical = 12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("test_connection_button"),
            ) {
                if (uiState.isTestingConnection) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = NeonBlue,
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Enviando ping real...", color = NeonBlue)
                } else {
                    Icon(Icons.Filled.Bolt, contentDescription = null, tint = NeonBlue, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Testar Conexão", color = NeonBlue, fontWeight = FontWeight.Bold)
                }
            }

            val ping = uiState.pingResult
            if (ping != null) {
                Spacer(Modifier.height(10.dp))
                Surface(
                    color = if (ping.isOnline) CyberGreenSurface else CrimsonSurface,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, if (ping.isOnline) CyberGreen else NeonCrimson),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("ping_result_badge"),
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Icon(
                            imageVector = if (ping.isOnline) Icons.Filled.CheckCircle else Icons.Filled.Error,
                            contentDescription = null,
                            tint = if (ping.isOnline) CyberGreen else NeonCrimson,
                        )
                        Column {
                            Text(
                                text = if (ping.isOnline) "IA Online • ${ping.latencyMs} ms" else "Falha na Conexão (${ping.latencyMs} ms)",
                                style = MaterialTheme.typography.titleSmall,
                                color = if (ping.isOnline) CyberGreen else NeonCrimson,
                                fontWeight = FontWeight.Bold,
                            )
                            Text(
                                text = ping.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberTextPrimary,
                            )
                        }
                    }
                }
            }
        }

        // 2. Default Save Folder (SAF OpenDocumentTree)
        CyberCard {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.FolderOpen,
                    contentDescription = null,
                    tint = NeonBlue,
                    modifier = Modifier.size(20.dp),
                )
                Text(
                    text = "Pasta Padrão de Salvamento",
                    style = MaterialTheme.typography.titleMedium,
                    color = CyberTextPrimary,
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Usada para salvar automaticamente arquivos do Rayn Chat e pacotes .SWB via DocumentFile com permissão persistente.",
                style = MaterialTheme.typography.bodySmall,
                color = CyberTextSecondary,
            )
            Spacer(Modifier.height(10.dp))

            Surface(
                color = CyberGraphiteElevated,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, CyberBorder),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = uiState.folderDisplayName,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (uiState.settings.savedFolderUri.isNotBlank()) NeonBlue else CyberTextMuted,
                    modifier = Modifier.padding(12.dp),
                )
            }

            Spacer(Modifier.height(10.dp))

            Button(
                onClick = { folderPicker.launch(null) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = ElectricBlue,
                    contentColor = CyberTextPrimary,
                ),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(vertical = 12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("select_folder_button"),
            ) {
                Icon(Icons.Filled.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Selecionar Pasta Padrão", fontWeight = FontWeight.Bold)
            }
        }

        // 3. Anti-Crack SecurityIntegrityGuard Card
        val integrity = uiState.integrityReport
        CyberCard(
            borderColor = if (integrity?.isValid == true) NeonCrimson.copy(alpha = 0.5f) else NeonCrimson
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.Shield,
                    contentDescription = null,
                    tint = NeonCrimson,
                    modifier = Modifier.size(20.dp),
                )
                Text(
                    text = "Proteção Anti-Crack (SecurityIntegrityGuard)",
                    style = MaterialTheme.typography.titleMedium,
                    color = CyberTextPrimary,
                )
            }
            Spacer(Modifier.height(8.dp))
            if (integrity != null) {
                Text(
                    text = "Pacote: ${integrity.packageName}",
                    style = MaterialTheme.typography.labelMedium,
                    color = CyberTextSecondary,
                )
                Text(
                    text = "Nome Oficial: ${integrity.appLabel}",
                    style = MaterialTheme.typography.labelMedium,
                    color = CyberTextSecondary,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "SHA-256 do Certificado APK:",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberTextMuted,
                )
                Text(
                    text = integrity.currentCertSha256,
                    style = MaterialTheme.typography.labelSmall,
                    color = NeonBlue,
                )
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = onVerifyIntegrity,
                border = BorderStroke(1.dp, NeonCrimson),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("verify_integrity_button"),
            ) {
                Text("Verificar Integridade Agora", color = NeonCrimson, fontWeight = FontWeight.Bold)
            }
        }
    }
}
