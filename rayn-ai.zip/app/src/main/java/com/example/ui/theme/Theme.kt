package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val RaynDarkColorScheme = darkColorScheme(
    primary = NeonBlue,
    onPrimary = CyberDeepBlack,
    primaryContainer = DeepBlueAccent,
    onPrimaryContainer = NeonBlue,
    secondary = ElectricBlue,
    onSecondary = CyberTextPrimary,
    secondaryContainer = CyberGraphiteElevated,
    onSecondaryContainer = CyberTextPrimary,
    tertiary = NeonCrimson,
    onTertiary = CyberTextPrimary,
    tertiaryContainer = CrimsonSurface,
    onTertiaryContainer = NeonCrimson,
    background = CyberDeepBlack,
    onBackground = CyberTextPrimary,
    surface = CyberGraphite,
    onSurface = CyberTextPrimary,
    surfaceVariant = CyberGraphiteElevated,
    onSurfaceVariant = CyberTextSecondary,
    outline = CyberBorder,
    outlineVariant = CyberBorderGlow,
    error = NeonCrimson,
    onError = CyberTextPrimary,
    errorContainer = CrimsonSurface,
    onErrorContainer = NeonCrimson,
)

val RaynShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp),
)

@Composable
fun RaynAiTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RaynDarkColorScheme,
        typography = RaynTypography,
        shapes = RaynShapes,
        content = content
    )
}
