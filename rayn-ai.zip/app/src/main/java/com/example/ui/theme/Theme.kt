package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val RaynDarkColorScheme = darkColorScheme(
    primary = NeonBlue,
    onPrimary = CyberBackground,
    primaryContainer = CyanDim,
    onPrimaryContainer = NeonBlue,
    secondary = ElectricBlue,
    onSecondary = TextPrimary,
    secondaryContainer = CyberSurfaceElevated,
    onSecondaryContainer = TextPrimary,
    tertiary = NeonCrimson,
    onTertiary = TextPrimary,
    tertiaryContainer = CrimsonDim,
    onTertiaryContainer = NeonCrimson,
    background = CyberBackground,
    onBackground = TextPrimary,
    surface = CyberSurface,
    onSurface = TextPrimary,
    surfaceVariant = CyberSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = CyberBorder,
    outlineVariant = CyberBorderBright,
    error = NeonCrimson,
    onError = TextPrimary,
    errorContainer = CrimsonDim,
    onErrorContainer = NeonCrimson
)

val RaynShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun RaynAITheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RaynDarkColorScheme,
        typography = Typography,
        shapes = RaynShapes,
        content = content
    )
}
