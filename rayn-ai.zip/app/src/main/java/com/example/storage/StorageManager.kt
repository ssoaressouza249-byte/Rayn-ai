package com.example.storage

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.URLDecoder

data class AttachedFile(
    val uri: Uri,
    val name: String,
    val mimeType: String,
    val sizeBytes: Long,
    val textContent: String,
    val isBinary: Boolean,
)

data class SavedFileResult(
    val uri: Uri,
    val fileName: String,
    val locationLabel: String,
    val sizeBytes: Int,
)

data class ExtractableFilePayload(
    val suggestedFileName: String,
    val content: String,
)

object StorageManager {

    fun getReadableFolderName(context: Context, folderUriString: String): String {
        if (folderUriString.isBlank()) return "Nenhuma pasta selecionada"
        return runCatching {
            val uri = Uri.parse(folderUriString)
            val doc = DocumentFile.fromTreeUri(context, uri)
            val docName = doc?.name
            val decoded = URLDecoder.decode(uri.lastPathSegment ?: uri.toString(), "UTF-8")
            val cleaned = decoded.substringAfterLast(':')
            when {
                cleaned.isNotBlank() -> cleaned
                !docName.isNullOrBlank() -> docName
                else -> "Pasta SAF selecionada"
            }
        }.getOrDefault("Pasta selecionada")
    }

    suspend fun readAttachedFile(context: Context, uri: Uri): Result<AttachedFile> = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            var displayName = "arquivo_anexado"
            var sizeBytes = 0L

            resolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) displayName = cursor.getString(nameIdx) ?: displayName
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) sizeBytes = cursor.getLong(sizeIdx)
                }
            }

            val mimeType = resolver.getType(uri) ?: guessMimeType(displayName)
            val rawBytes = resolver.openInputStream(uri)?.use { input ->
                val maxRead = 256 * 1024
                val buffer = ByteArray(8192)
                val out = ArrayList<Byte>()
                var total = 0
                while (total < maxRead) {
                    val read = input.read(buffer, 0, minOf(buffer.size, maxRead - total))
                    if (read <= 0) break
                    for (i in 0 until read) out.add(buffer[i])
                    total += read
                }
                out.toByteArray()
            } ?: ByteArray(0)

            if (sizeBytes == 0L) sizeBytes = rawBytes.size.toLong()

            val looksBinary = rawBytes.take(1024).count { it == 0.toByte() } > 2 ||
                displayName.endsWith(".apk", ignoreCase = true) ||
                displayName.endsWith(".swb", ignoreCase = true) ||
                displayName.endsWith(".zip", ignoreCase = true)

            val textContent = if (looksBinary) {
                "[Arquivo binário: $displayName • ${rawBytes.size} bytes lidos • MIME: $mimeType]"
            } else {
                rawBytes.toString(Charsets.UTF_8)
            }

            AttachedFile(
                uri = uri,
                name = displayName,
                mimeType = mimeType,
                sizeBytes = sizeBytes,
                textContent = textContent,
                isBinary = looksBinary,
            )
        }
    }

    suspend fun saveTextToFolder(
        context: Context,
        folderUriString: String,
        fileName: String,
        content: String,
    ): Result<SavedFileResult> {
        val sanitizedName = sanitizeFileName(fileName)
        val mime = guessMimeType(sanitizedName)
        return saveBytesToFolderOrDownloads(
            context = context,
            folderUriString = folderUriString,
            fileName = sanitizedName,
            mimeType = mime,
            bytes = content.toByteArray(Charsets.UTF_8),
            allowDownloadsFallback = false,
        )
    }

    suspend fun saveBytesToFolderOrDownloads(
        context: Context,
        folderUriString: String,
        fileName: String,
        mimeType: String,
        bytes: ByteArray,
        allowDownloadsFallback: Boolean = true,
    ): Result<SavedFileResult> = withContext(Dispatchers.IO) {
        runCatching {
            val sanitizedName = sanitizeFileName(fileName)
            if (folderUriString.isNotBlank()) {
                val treeUri = Uri.parse(folderUriString)
                val folderDoc = DocumentFile.fromTreeUri(context, treeUri)
                if (folderDoc != null && folderDoc.exists() && folderDoc.canWrite()) {
                    val existing = folderDoc.findFile(sanitizedName)
                    val targetDoc = existing ?: folderDoc.createFile(mimeType, sanitizedName)
                        ?: error("Não foi possível criar \"$sanitizedName\" na pasta selecionada.")

                    context.contentResolver.openOutputStream(targetDoc.uri, "wt")?.use { out ->
                        out.write(bytes)
                        out.flush()
                    } ?: error("Falha ao abrir fluxo de escrita para \"$sanitizedName\".")

                    return@runCatching SavedFileResult(
                        uri = targetDoc.uri,
                        fileName = sanitizedName,
                        locationLabel = getReadableFolderName(context, folderUriString),
                        sizeBytes = bytes.size,
                    )
                }
            }

            if (!allowDownloadsFallback) {
                error("Selecione primeiro a \"Pasta Padrão de Salvamento\" na aba Ajustes.")
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, sanitizedName)
                    put(MediaStore.Downloads.MIME_TYPE, mimeType)
                    put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/RaynAI")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val itemUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("Não foi possível criar o arquivo em Downloads.")

                resolver.openOutputStream(itemUri)?.use { out ->
                    out.write(bytes)
                    out.flush()
                } ?: error("Falha ao gravar arquivo em Downloads.")

                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)

                SavedFileResult(
                    uri = itemUri,
                    fileName = sanitizedName,
                    locationLabel = "Downloads/RaynAI",
                    sizeBytes = bytes.size,
                )
            } else {
                val outDir = File(
                    context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir,
                    "RaynAI"
                ).apply { mkdirs() }
                val outFile = File(outDir, sanitizedName)
                outFile.writeBytes(bytes)
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    outFile
                )
                SavedFileResult(
                    uri = uri,
                    fileName = sanitizedName,
                    locationLabel = "Downloads/RaynAI",
                    sizeBytes = bytes.size,
                )
            }
        }
    }

    fun shouldAutoSaveFromPrompt(userPrompt: String): Boolean {
        val lower = userPrompt.lowercase()
        val triggers = listOf(
            "salve", "salvar", "salva", "grava", "gravar", "exporta", "exportar",
            "na pasta", "save to", "save file"
        )
        return triggers.any { lower.contains(it) }
    }

    fun extractFilePayload(
        userPrompt: String,
        aiResponse: String,
        attachedFileName: String? = null,
    ): ExtractableFilePayload {
        val markerRegex = Regex(
            """===FILE:([^\r\n=]+)===\s*\r?\n([\s\S]*?)\r?\n===END_FILE===""",
            RegexOption.IGNORE_CASE
        )
        val markerMatch = markerRegex.find(aiResponse)
        if (markerMatch != null) {
            val fileName = sanitizeFileName(markerMatch.groupValues[1].trim())
            val content = markerMatch.groupValues[2]
            return ExtractableFilePayload(fileName, content)
        }

        val codeBlockRegex = Regex("""```([a-zA-Z0-9_+-]*)\s*\r?\n([\s\S]*?)```""")
        val codeMatch = codeBlockRegex.find(aiResponse)
        val lang = codeMatch?.groupValues?.getOrNull(1)?.lowercase().orEmpty()
        val codeContent = codeMatch?.groupValues?.getOrNull(2)?.trimEnd()

        val explicitNameRegex = Regex(
            """([a-zA-Z0-9_\-]+\.(txt|json|xml|kt|java|html|csv|md|py|js|css|yaml|yml|gradle))""",
            RegexOption.IGNORE_CASE
        )
        val promptFileName = explicitNameRegex.find(userPrompt)?.groupValues?.getOrNull(1)
        val responseFileName = explicitNameRegex.find(aiResponse)?.groupValues?.getOrNull(1)

        val inferredExt = when (lang) {
            "json" -> "json"
            "xml" -> "xml"
            "kotlin", "kt" -> "kt"
            "java" -> "java"
            "html" -> "html"
            "csv" -> "csv"
            "python", "py" -> "py"
            "javascript", "js" -> "js"
            "css" -> "css"
            else -> attachedFileName?.substringAfterLast('.', "")?.takeIf { it.isNotBlank() } ?: "txt"
        }

        val finalName = when {
            !promptFileName.isNullOrBlank() -> promptFileName
            !attachedFileName.isNullOrBlank() -> "rayn_${sanitizeFileName(attachedFileName)}"
            !responseFileName.isNullOrBlank() && codeContent != null -> responseFileName
            else -> "rayn_arquivo_${System.currentTimeMillis() % 100000}.$inferredExt"
        }

        return ExtractableFilePayload(
            suggestedFileName = sanitizeFileName(finalName),
            content = codeContent ?: aiResponse,
        )
    }

    fun sanitizeFileName(raw: String): String {
        val cleaned = raw.trim()
            .replace(Regex("""[\\/:*?"<>|]"""), "_")
            .trim('.')
        return cleaned.ifBlank { "rayn_output.txt" }
    }

    fun guessMimeType(fileName: String): String {
        return when (fileName.substringAfterLast('.', "").lowercase()) {
            "json" -> "application/json"
            "xml" -> "application/xml"
            "html", "htm" -> "text/html"
            "csv" -> "text/csv"
            "kt", "java", "txt", "md", "py", "js", "css" -> "text/plain"
            "swb", "zip" -> "application/octet-stream"
            "apk" -> "application/vnd.android.package-archive"
            else -> "application/octet-stream"
        }
    }
}
