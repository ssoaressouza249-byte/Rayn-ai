package com.example.storage

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class AttachedFileData(
    val uriString: String,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val textContent: String,
    val isBinaryOrTruncated: Boolean
)

data class SafSaveResult(
    val success: Boolean,
    val displayPath: String,
    val fileName: String,
    val shareUri: Uri? = null,
    val errorMessage: String? = null
)

class SafStorageManager(private val context: Context) {

    fun persistTreePermission(treeUri: Uri): String {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        runCatching {
            context.contentResolver.takePersistableUriPermission(treeUri, flags)
        }
        return extractReadableFolderName(treeUri)
    }

    fun extractReadableFolderName(treeUri: Uri): String {
        val docFile = DocumentFile.fromTreeUri(context, treeUri)
        val rawPath = treeUri.lastPathSegment ?: docFile?.name ?: "Pasta SAF"
        val cleaned = rawPath
            .substringAfter("primary:", rawPath)
            .substringAfter(":", rawPath)
            .trim('/')
        return cleaned.ifBlank { docFile?.name ?: "Pasta SAF" }
    }

    fun hasValidTreePermission(treeUriString: String?): Boolean {
        if (treeUriString.isNullOrBlank()) return false
        val uri = runCatching { Uri.parse(treeUriString) }.getOrNull() ?: return false
        val doc = DocumentFile.fromTreeUri(context, uri)
        return doc != null && doc.exists() && doc.canWrite()
    }

    suspend fun readAttachedDocument(uri: Uri): Result<AttachedFileData> = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            var name = "arquivo_anexo"
            var size = 0L

            resolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) name = cursor.getString(nameIdx) ?: name
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) size = cursor.getLong(sizeIdx)
                }
            }

            val mimeType = resolver.getType(uri) ?: "application/octet-stream"
            val rawBytes = resolver.openInputStream(uri)?.use { input ->
                val maxRead = 512 * 1024 // 512 KB cap for prompt reading
                val buffer = ByteArray(maxRead + 1)
                var total = 0
                while (total < buffer.size) {
                    val read = input.read(buffer, total, buffer.size - total)
                    if (read <= 0) break
                    total += read
                }
                buffer.copyOf(total)
            } ?: ByteArray(0)

            val truncated = rawBytes.size > 512 * 1024
            val effectiveBytes = if (truncated) rawBytes.copyOf(512 * 1024) else rawBytes
            if (size == 0L) size = rawBytes.size.toLong()

            val looksBinary = effectiveBytes.take(512).count { b ->
                val v = b.toInt() and 0xFF
                v == 0 || (v < 0x09) || (v in 0x0E..0x1F)
            } > 12

            val text = if (looksBinary) {
                "[Arquivo binário detectado: $name • ${effectiveBytes.size} bytes]"
            } else {
                String(effectiveBytes, Charsets.UTF_8)
            }

            AttachedFileData(
                uriString = uri.toString(),
                fileName = name,
                mimeType = mimeType,
                sizeBytes = size,
                textContent = text,
                isBinaryOrTruncated = looksBinary || truncated
            )
        }
    }

    suspend fun saveTextToSafFolder(
        treeUriString: String,
        folderDisplayName: String,
        fileName: String,
        content: String,
        subfolder: String? = null
    ): SafSaveResult = withContext(Dispatchers.IO) {
        saveBytesToSafFolder(
            treeUriString = treeUriString,
            folderDisplayName = folderDisplayName,
            fileName = fileName,
            bytes = content.toByteArray(Charsets.UTF_8),
            subfolder = subfolder
        )
    }

    suspend fun saveBytesToSafFolder(
        treeUriString: String,
        folderDisplayName: String,
        fileName: String,
        bytes: ByteArray,
        subfolder: String? = null
    ): SafSaveResult = withContext(Dispatchers.IO) {
        try {
            val treeUri = Uri.parse(treeUriString)
            var currentDir = DocumentFile.fromTreeUri(context, treeUri)
                ?: return@withContext SafSaveResult(
                    success = false,
                    displayPath = folderDisplayName,
                    fileName = fileName,
                    errorMessage = "Acesso à pasta SAF inválido. Selecione a pasta novamente em Ajustes."
                )

            val cleanSubfolder = subfolder
                ?.replace("\\", "/")
                ?.split("/")
                ?.map { it.trim() }
                ?.filter { it.isNotBlank() && it != "." && it != ".." }
                .orEmpty()

            val displayPathBuilder = StringBuilder(folderDisplayName.ifBlank { "Pasta SAF" })
            for (part in cleanSubfolder) {
                val existingDir = currentDir.findFile(part)?.takeIf { it.isDirectory }
                val nextDir = existingDir ?: currentDir.createDirectory(part)
                    ?: return@withContext SafSaveResult(
                        success = false,
                        displayPath = displayPathBuilder.toString(),
                        fileName = fileName,
                        errorMessage = "Não foi possível criar a subpasta '$part'."
                    )
                currentDir = nextDir
                displayPathBuilder.append("/").append(part)
            }

            val safeFileName = sanitizeFileName(fileName)
            val existingFile = currentDir.findFile(safeFileName)
            if (existingFile != null && existingFile.isFile) {
                existingFile.delete()
            }

            // Use application/octet-stream when extension is present so Android SAF does not append .txt
            val mime = if (safeFileName.contains(".")) "application/octet-stream" else "text/plain"
            val targetFile = currentDir.createFile(mime, safeFileName)
                ?: return@withContext SafSaveResult(
                    success = false,
                    displayPath = displayPathBuilder.toString(),
                    fileName = safeFileName,
                    errorMessage = "Falha ao criar '$safeFileName' na pasta selecionada."
                )

            context.contentResolver.openOutputStream(targetFile.uri, "wt")?.use { out ->
                out.write(bytes)
                out.flush()
            } ?: return@withContext SafSaveResult(
                success = false,
                displayPath = displayPathBuilder.toString(),
                fileName = safeFileName,
                errorMessage = "Não foi possível abrir fluxo de escrita para '$safeFileName'."
            )

            val shareUri = writeExportCopyForShare(safeFileName, bytes) ?: targetFile.uri
            SafSaveResult(
                success = true,
                displayPath = displayPathBuilder.toString(),
                fileName = safeFileName,
                shareUri = shareUri
            )
        } catch (e: Exception) {
            SafSaveResult(
                success = false,
                displayPath = folderDisplayName,
                fileName = fileName,
                errorMessage = e.localizedMessage ?: "Erro desconhecido ao salvar via SAF."
            )
        }
    }

    suspend fun saveSwbArchive(
        treeUriString: String?,
        folderDisplayName: String?,
        fileName: String,
        bytes: ByteArray
    ): SafSaveResult = withContext(Dispatchers.IO) {
        val safeName = if (fileName.endsWith(".swb", ignoreCase = true)) {
            sanitizeFileName(fileName)
        } else {
            "${sanitizeFileName(fileName)}.swb"
        }

        if (!treeUriString.isNullOrBlank() && hasValidTreePermission(treeUriString)) {
            return@withContext saveBytesToSafFolder(
                treeUriString = treeUriString,
                folderDisplayName = folderDisplayName ?: "Pasta SAF",
                fileName = safeName,
                bytes = bytes
            )
        }

        // Fallback to public Downloads via MediaStore.Downloads (API 29+) or app external Downloads
        return@withContext try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                    put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("MediaStore Downloads indisponível.")
                resolver.openOutputStream(uri)?.use { out ->
                    out.write(bytes)
                    out.flush()
                }
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, values, null, null)

                val shareUri = writeExportCopyForShare(safeName, bytes) ?: uri
                SafSaveResult(
                    success = true,
                    displayPath = "Downloads",
                    fileName = safeName,
                    shareUri = shareUri
                )
            } else {
                val downloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                    ?: File(context.filesDir, "swb_exports").apply { mkdirs() }
                val outFile = File(downloadsDir, safeName)
                outFile.writeBytes(bytes)
                val shareUri = writeExportCopyForShare(safeName, bytes)
                    ?: FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", outFile)
                SafSaveResult(
                    success = true,
                    displayPath = "Downloads",
                    fileName = safeName,
                    shareUri = shareUri
                )
            }
        } catch (e: Exception) {
            val shareUri = writeExportCopyForShare(safeName, bytes)
            SafSaveResult(
                success = shareUri != null,
                displayPath = "Exports",
                fileName = safeName,
                shareUri = shareUri,
                errorMessage = if (shareUri == null) e.localizedMessage else null
            )
        }
    }

    private fun writeExportCopyForShare(fileName: String, bytes: ByteArray): Uri? {
        return runCatching {
            val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val exportFile = File(exportDir, sanitizeFileName(fileName))
            exportFile.writeBytes(bytes)
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                exportFile
            )
        }.getOrNull()
    }

    private fun sanitizeFileName(raw: String): String {
        val trimmed = raw.trim().ifBlank { "rayn_output.txt" }
        return trimmed.replace(Regex("[\\\\/:*?\"<>|]"), "_")
    }
}
