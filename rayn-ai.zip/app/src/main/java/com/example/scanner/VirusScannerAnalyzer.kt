package com.example.scanner

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import com.example.security.SecurityIntegrityGuard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.util.zip.ZipInputStream

enum class RiskLevel(val label: String) {
    SAFE("Seguro"),
    CAUTION("Atenção"),
    HIGH_RISK("Alto Risco"),
}

data class PermissionFinding(
    val permission: String,
    val severity: RiskLevel,
    val reason: String,
)

data class ScanReport(
    val fileName: String,
    val fileSizeBytes: Long,
    val detectedFormat: String,
    val sha256: String,
    val md5: String,
    val isApk: Boolean,
    val packageName: String? = null,
    val versionName: String? = null,
    val versionCode: Long? = null,
    val signatureVerified: Boolean = false,
    val signatureSha256: String? = null,
    val signatureSubject: String? = null,
    val totalPermissions: Int = 0,
    val dangerousFindings: List<PermissionFinding> = emptyList(),
    val heuristicAlerts: List<String> = emptyList(),
    val riskLevel: RiskLevel,
    val summary: String,
)

object VirusScannerAnalyzer {

    private val highRiskPermissions = mapOf(
        "android.permission.READ_SMS" to "Leitura de mensagens SMS (risco de interceptação de OTP/2FA).",
        "android.permission.RECEIVE_SMS" to "Captura em tempo real de SMS recebidos.",
        "android.permission.SEND_SMS" to "Envio silencioso de SMS (risco de fraude/tarifação).",
        "android.permission.BIND_ACCESSIBILITY_SERVICE" to "Controle total de acessibilidade da tela e cliques automatizados.",
        "android.permission.REQUEST_INSTALL_PACKAGES" to "Capacidade de instalar APKs externos (dropper).",
        "android.permission.MANAGE_EXTERNAL_STORAGE" to "Acesso irrestrito a todos os arquivos do dispositivo.",
    )

    private val cautionPermissions = mapOf(
        "android.permission.SYSTEM_ALERT_WINDOW" to "Sobreposição de janelas sobre outros aplicativos.",
        "android.permission.READ_CALL_LOG" to "Acesso ao histórico de chamadas.",
        "android.permission.READ_CONTACTS" to "Leitura da agenda de contatos.",
        "android.permission.RECORD_AUDIO" to "Gravação de áudio pelo microfone.",
        "android.permission.CAMERA" to "Acesso à câmera.",
        "android.permission.ACCESS_FINE_LOCATION" to "Localização GPS precisa.",
    )

    suspend fun analyzeFile(context: Context, uri: Uri): Result<ScanReport> = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            var fileName = "arquivo_selecionado"
            var fileSize = 0L

            resolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) fileName = cursor.getString(nameIdx) ?: fileName
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) fileSize = cursor.getLong(sizeIdx)
                }
            }

            val tempFile = File(context.cacheDir, "scan_${System.currentTimeMillis()}_${fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")}")
            try {
                resolver.openInputStream(uri)?.use { input ->
                    tempFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                } ?: error("Não foi possível ler o arquivo selecionado.")

                if (fileSize == 0L) fileSize = tempFile.length()

                val sha256 = hashFile(tempFile, "SHA-256")
                val md5 = hashFile(tempFile, "MD5")
                val header = readMagicHeader(tempFile)
                val detectedFormat = detectMagicFormat(header, fileName)
                val isZip = header.size >= 4 &&
                    header[0] == 0x50.toByte() && header[1] == 0x4B.toByte() &&
                    header[2] == 0x03.toByte() && header[3] == 0x04.toByte()

                val isApk = fileName.endsWith(".apk", ignoreCase = true) ||
                    (isZip && zipContainsEntry(tempFile, "AndroidManifest.xml"))

                if (isApk) {
                    inspectApk(context, tempFile, fileName, fileSize, detectedFormat, sha256, md5)
                } else {
                    inspectGenericFile(tempFile, fileName, fileSize, detectedFormat, header, sha256, md5)
                }
            } finally {
                tempFile.delete()
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun inspectApk(
        context: Context,
        apkFile: File,
        fileName: String,
        fileSize: Long,
        detectedFormat: String,
        sha256: String,
        md5: String,
    ): ScanReport {
        val pm = context.packageManager
        val flags = PackageManager.GET_PERMISSIONS or
            PackageManager.GET_SERVICES or
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                PackageManager.GET_SIGNING_CERTIFICATES
            } else {
                PackageManager.GET_SIGNATURES
            }

        val pkgInfo: PackageInfo? = pm.getPackageArchiveInfo(apkFile.absolutePath, flags)
        pkgInfo?.applicationInfo?.apply {
            sourceDir = apkFile.absolutePath
            publicSourceDir = apkFile.absolutePath
        }

        val packageName = pkgInfo?.packageName ?: "Desconhecido (Manifest não legível)"
        val versionName = pkgInfo?.versionName ?: "N/D"
        val versionCode = if (pkgInfo != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) pkgInfo.longVersionCode
            else pkgInfo.versionCode.toLong()
        } else null

        var sigSha256: String? = null
        var sigSubject: String? = null

        val pmCertBytes: ByteArray? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val signingInfo = pkgInfo?.signingInfo
            val signers = signingInfo?.let {
                if (it.hasMultipleSigners()) it.apkContentsSigners else it.signingCertificateHistory
            }
            signers?.firstOrNull()?.toByteArray()
        } else {
            pkgInfo?.signatures?.firstOrNull()?.toByteArray()
        }

        if (pmCertBytes != null) {
            sigSha256 = SecurityIntegrityGuard.sha256Hex(pmCertBytes)
            sigSubject = parseX509Subject(pmCertBytes)
        } else {
            val zipCert = extractCertFromApkZip(apkFile)
            if (zipCert != null) {
                sigSha256 = zipCert.first
                sigSubject = zipCert.second
            }
        }

        val requestedPermissions = pkgInfo?.requestedPermissions?.toList().orEmpty()
        val findings = mutableListOf<PermissionFinding>()

        requestedPermissions.forEach { perm ->
            highRiskPermissions[perm]?.let { reason ->
                findings.add(PermissionFinding(perm, RiskLevel.HIGH_RISK, reason))
            }
            cautionPermissions[perm]?.let { reason ->
                findings.add(PermissionFinding(perm, RiskLevel.CAUTION, reason))
            }
        }

        val hasAccessibilityService = pkgInfo?.services?.any {
            it.permission == "android.permission.BIND_ACCESSIBILITY_SERVICE"
        } == true
        if (hasAccessibilityService && findings.none { it.permission.contains("BIND_ACCESSIBILITY_SERVICE") }) {
            findings.add(
                PermissionFinding(
                    "android.permission.BIND_ACCESSIBILITY_SERVICE",
                    RiskLevel.HIGH_RISK,
                    "Serviço de acessibilidade declarado no AndroidManifest."
                )
            )
        }

        val heuristicAlerts = mutableListOf<String>()
        if (sigSha256 == null) {
            heuristicAlerts.add("APK sem certificado de assinatura válido ou assinatura v1/v2 ausente.")
        }
        val zipInsights = inspectApkZipEntries(apkFile)
        heuristicAlerts.addAll(zipInsights)

        val highCount = findings.count { it.severity == RiskLevel.HIGH_RISK }
        val cautionCount = findings.count { it.severity == RiskLevel.CAUTION }

        val riskLevel = when {
            highCount > 0 || sigSha256 == null -> RiskLevel.HIGH_RISK
            cautionCount >= 2 || heuristicAlerts.isNotEmpty() -> RiskLevel.CAUTION
            cautionCount == 1 -> RiskLevel.CAUTION
            else -> RiskLevel.SAFE
        }

        val summary = when (riskLevel) {
            RiskLevel.SAFE -> "APK assinado com certificado íntegro e sem permissões críticas de alto risco."
            RiskLevel.CAUTION -> "APK válido, porém solicita permissões sensíveis ou possui alertas que exigem atenção."
            RiskLevel.HIGH_RISK -> "Alto risco detectado: permissões críticas (${highCount}) ou assinatura ausente/inválida."
        }

        return ScanReport(
            fileName = fileName,
            fileSizeBytes = fileSize,
            detectedFormat = detectedFormat,
            sha256 = sha256,
            md5 = md5,
            isApk = true,
            packageName = packageName,
            versionName = versionName,
            versionCode = versionCode,
            signatureVerified = sigSha256 != null,
            signatureSha256 = sigSha256,
            signatureSubject = sigSubject,
            totalPermissions = requestedPermissions.size,
            dangerousFindings = findings.sortedByDescending { it.severity == RiskLevel.HIGH_RISK },
            heuristicAlerts = heuristicAlerts,
            riskLevel = riskLevel,
            summary = summary,
        )
    }

    private fun inspectGenericFile(
        file: File,
        fileName: String,
        fileSize: Long,
        detectedFormat: String,
        header: ByteArray,
        sha256: String,
        md5: String,
    ): ScanReport {
        val alerts = mutableListOf<String>()
        val ext = fileName.substringAfterLast('.', "").lowercase()

        val isElf = header.size >= 4 && header[0] == 0x7F.toByte() && header[1] == 0x45.toByte() &&
            header[2] == 0x4C.toByte() && header[3] == 0x46.toByte()
        val isDex = header.size >= 3 && header[0] == 0x64.toByte() && header[1] == 0x65.toByte() &&
            header[2] == 0x78.toByte()
        val isMz = header.size >= 2 && header[0] == 0x4D.toByte() && header[1] == 0x5A.toByte()

        if ((isElf || isDex || isMz) && ext in setOf("txt", "json", "xml", "jpg", "png", "pdf", "csv")) {
            alerts.add("Discrepância crítica: arquivo disfarçado como .$ext possui cabeçalho binário executável ($detectedFormat).")
        }
        if (isDex) {
            alerts.add("Arquivo Dalvik Executable (.dex) bruto — potencial carregamento dinâmico de código.")
        }
        if (isElf && ext != "so") {
            alerts.add("Binário nativo ELF detectado fora de biblioteca .so padrão.")
        }

        if (fileSize <= 512 * 1024 && !isElf && !isDex && !isMz) {
            val text = runCatching { file.readText(Charsets.UTF_8) }.getOrDefault("")
            val suspiciousPatterns = listOf(
                "DexClassLoader" to "Carregamento dinâmico de DEX em tempo de execução.",
                "Runtime.getRuntime().exec" to "Execução direta de comandos shell.",
                "su -c" to "Tentativa de escalação de privilégio root (su).",
                "/Android/data" to "Referência a manipulação direta de Android/data.",
                "/Android/obb" to "Referência a manipulação direta de arquivos OBB.",
            )
            suspiciousPatterns.forEach { (pattern, msg) ->
                if (text.contains(pattern, ignoreCase = false)) {
                    alerts.add("$msg (padrão: \"$pattern\")")
                }
            }
        }

        val riskLevel = when {
            alerts.any { it.contains("Discrepância") || it.contains("root") || it.contains("DEX") } -> RiskLevel.HIGH_RISK
            alerts.isNotEmpty() -> RiskLevel.CAUTION
            else -> RiskLevel.SAFE
        }

        val summary = when (riskLevel) {
            RiskLevel.SAFE -> "Assinatura de bytes consistente ($detectedFormat) e nenhum indicador malicioso encontrado."
            RiskLevel.CAUTION -> "Arquivo analisado com alertas heurísticos leves; revise antes de executar."
            RiskLevel.HIGH_RISK -> "Assinatura suspeita ou padrão de risco elevado detectado no arquivo."
        }

        return ScanReport(
            fileName = fileName,
            fileSizeBytes = fileSize,
            detectedFormat = detectedFormat,
            sha256 = sha256,
            md5 = md5,
            isApk = false,
            signatureVerified = alerts.none { it.contains("Discrepância") },
            heuristicAlerts = alerts,
            riskLevel = riskLevel,
            summary = summary,
        )
    }

    private fun hashFile(file: File, algorithm: String): String {
        val digest = MessageDigest.getInstance(algorithm)
        FileInputStream(file).use { fis ->
            val buf = ByteArray(8192)
            while (true) {
                val read = fis.read(buf)
                if (read <= 0) break
                digest.update(buf, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun readMagicHeader(file: File): ByteArray {
        return FileInputStream(file).use { fis ->
            val buf = ByteArray(16)
            val read = fis.read(buf)
            if (read <= 0) ByteArray(0) else buf.copyOf(read)
        }
    }

    private fun detectMagicFormat(header: ByteArray, fileName: String): String {
        return when {
            header.size >= 4 && header[0] == 0x50.toByte() && header[1] == 0x4B.toByte() ->
                if (fileName.endsWith(".apk", true)) "APK / ZIP (PK\\x03\\x04)"
                else if (fileName.endsWith(".swb", true)) "Sketchware Backup .SWB (ZIP)"
                else "Arquivo Compactado ZIP (PK)"
            header.size >= 4 && header[0] == 0x7F.toByte() && header[1] == 0x45.toByte() &&
                header[2] == 0x4C.toByte() && header[3] == 0x46.toByte() -> "Binário Nativo ELF (.so)"
            header.size >= 3 && header[0] == 0x64.toByte() && header[1] == 0x65.toByte() &&
                header[2] == 0x78.toByte() -> "Dalvik Executable (.dex)"
            header.size >= 4 && header[0] == 0x25.toByte() && header[1] == 0x50.toByte() &&
                header[2] == 0x44.toByte() && header[3] == 0x46.toByte() -> "Documento PDF"
            else -> "Texto / Dados (${fileName.substringAfterLast('.', "bin").uppercase()})"
        }
    }

    private fun zipContainsEntry(file: File, entryName: String): Boolean {
        return runCatching {
            ZipInputStream(FileInputStream(file)).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (entry.name == entryName) return true
                    entry = zis.nextEntry
                }
                false
            }
        }.getOrDefault(false)
    }

    private fun inspectApkZipEntries(apkFile: File): List<String> {
        val alerts = mutableListOf<String>()
        runCatching {
            var dexInAssets = false
            var nativeLibCount = 0
            ZipInputStream(FileInputStream(apkFile)).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val name = entry.name
                    if (name.startsWith("assets/") && name.endsWith(".dex", ignoreCase = true)) {
                        dexInAssets = true
                    }
                    if (name.startsWith("lib/") && name.endsWith(".so", ignoreCase = true)) {
                        nativeLibCount++
                    }
                    entry = zis.nextEntry
                }
            }
            if (dexInAssets) {
                alerts.add("Arquivo .dex oculto dentro de assets/ (técnica comum de carregamento dinâmico).")
            }
            if (nativeLibCount > 12) {
                alerts.add("Grande quantidade de bibliotecas nativas .so empacotadas ($nativeLibCount).")
            }
        }
        return alerts
    }

    private fun parseX509Subject(certBytes: ByteArray): String? {
        return runCatching {
            val cf = CertificateFactory.getInstance("X.509")
            val cert = cf.generateCertificate(certBytes.inputStream()) as? X509Certificate
            cert?.subjectX500Principal?.name
        }.getOrNull()
    }

    private fun extractCertFromApkZip(apkFile: File): Pair<String, String?>? {
        return runCatching {
            ZipInputStream(FileInputStream(apkFile)).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val upper = entry.name.uppercase()
                    if (upper.startsWith("META-INF/") &&
                        (upper.endsWith(".RSA") || upper.endsWith(".DSA") || upper.endsWith(".EC"))
                    ) {
                        val bytes = zis.readBytes()
                        val cf = CertificateFactory.getInstance("X.509")
                        val certs = cf.generateCertificates(bytes.inputStream())
                        val first = certs.firstOrNull() as? X509Certificate
                        if (first != null) {
                            return SecurityIntegrityGuard.sha256Hex(first.encoded) to first.subjectX500Principal?.name
                        }
                    }
                    entry = zis.nextEntry
                }
                null
            }
        }.getOrNull()
    }
}
