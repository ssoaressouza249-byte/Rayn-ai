package com.example.scanner

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipFile

enum class ScanRiskLevel {
    SAFE,
    WARNING,
    HIGH_RISK
}

data class ScannedPermission(
    val fullName: String,
    val shortName: String,
    val isCritical: Boolean,
    val isElevated: Boolean,
    val description: String
)

data class ApkMetadata(
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val minSdk: Int?,
    val targetSdk: Int?,
    val dexCount: Int,
    val nativeLibCount: Int,
    val embeddedArchiveCount: Int,
    val signerSha256: String?,
    val permissions: List<ScannedPermission>
)

data class FileScanReport(
    val fileName: String,
    val sizeBytes: Long,
    val magicType: String,
    val magicHeaderHex: String,
    val sha256: String,
    val riskLevel: ScanRiskLevel,
    val riskSummary: String,
    val findings: List<String>,
    val apkMetadata: ApkMetadata? = null
)

class ApkStaticScanner(private val context: Context) {

    companion object {
        val CRITICAL_PERMISSIONS = mapOf(
            "android.permission.READ_SMS" to "Leitura direta de mensagens SMS e códigos 2FA",
            "android.permission.RECEIVE_SMS" to "Interceptação de SMS recebidos em segundo plano",
            "android.permission.BIND_ACCESSIBILITY_SERVICE" to "Controle de acessibilidade (leitura de tela / automação)",
            "android.permission.SYSTEM_ALERT_WINDOW" to "Sobreposição de janelas sobre outros aplicativos",
            "android.permission.REQUEST_INSTALL_PACKAGES" to "Instalação silenciosa ou externa de outros APKs",
            "android.permission.READ_CONTACTS" to "Extração da agenda completa de contatos"
        )

        val ELEVATED_PERMISSIONS = mapOf(
            "android.permission.READ_CALL_LOG" to "Acesso ao histórico de chamadas",
            "android.permission.RECORD_AUDIO" to "Gravação de áudio pelo microfone",
            "android.permission.CAMERA" to "Captura de câmera",
            "android.permission.ACCESS_FINE_LOCATION" to "Rastreamento de localização GPS precisa",
            "android.permission.WRITE_SETTINGS" to "Alteração de configurações do sistema",
            "android.permission.QUERY_ALL_PACKAGES" to "Inventário de todos os apps instalados"
        )

        fun detectMagicType(header: ByteArray, fileName: String): Pair<String, Boolean> {
            if (header.isEmpty()) return "Arquivo vazio" to false
            val hex = header.take(8).joinToString(" ") { "%02X".format(it) }
            val ext = fileName.substringAfterLast('.', "").lowercase()

            return when {
                header.size >= 4 && header[0] == 0x50.toByte() && header[1] == 0x4B.toByte() &&
                    header[2] == 0x03.toByte() && header[3] == 0x04.toByte() -> {
                    if (ext == "apk") "APK / ZIP Android Package (PK)" to false
                    else if (ext == "swb") "Sketchware Pro Backup ZIP (PK)" to false
                    else "Arquivo Compactado ZIP / JAR (PK)" to false
                }
                header.size >= 4 && header[0] == 0x64.toByte() && header[1] == 0x65.toByte() &&
                    header[2] == 0x78.toByte() && header[3] == 0x0A.toByte() -> {
                    "Dalvik Executable (DEX)" to (ext != "dex")
                }
                header.size >= 4 && header[0] == 0x7F.toByte() && header[1] == 0x45.toByte() &&
                    header[2] == 0x4C.toByte() && header[3] == 0x46.toByte() -> {
                    "Binário Nativo Linux/Android (ELF)" to (ext != "so")
                }
                header.size >= 2 && header[0] == 0x4D.toByte() && header[1] == 0x5A.toByte() -> {
                    "Executável Windows PE/MZ" to true
                }
                header.size >= 4 && header[0] == 0x25.toByte() && header[1] == 0x50.toByte() &&
                    header[2] == 0x44.toByte() && header[3] == 0x46.toByte() -> {
                    "Documento PDF (%PDF)" to false
                }
                header.size >= 4 && header[0] == 0x89.toByte() && header[1] == 0x50.toByte() &&
                    header[2] == 0x4E.toByte() && header[3] == 0x47.toByte() -> {
                    "Imagem PNG" to false
                }
                header.size >= 3 && header[0] == 0xFF.toByte() && header[1] == 0xD8.toByte() &&
                    header[2] == 0xFF.toByte() -> {
                    "Imagem JPEG" to false
                }
                else -> {
                    val sampleText = String(header.take(128).toByteArray(), Charsets.UTF_8).trimStart()
                    val printable = header.take(128).all { b ->
                        val v = b.toInt() and 0xFF
                        v == 0x09 || v == 0x0A || v == 0x0D || v in 0x20..0x7E || v >= 0x80
                    }
                    when {
                        sampleText.startsWith("{") || sampleText.startsWith("[") -> "Dados Estruturados JSON" to false
                        sampleText.startsWith("<") -> "Documento XML / HTML" to false
                        printable -> "Texto / Script UTF-8 ($hex)" to false
                        else -> "Binário Genérico ($hex)" to false
                    }
                }
            }
        }
    }

    suspend fun scanUri(uri: Uri): Result<FileScanReport> = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            var fileName = "arquivo_desconhecido"
            var reportedSize = 0L

            resolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) fileName = cursor.getString(nameIdx) ?: fileName
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) reportedSize = cursor.getLong(sizeIdx)
                }
            }

            val tempFile = File(context.cacheDir, "scan_${System.currentTimeMillis()}.tmp")
            try {
                val digest = MessageDigest.getInstance("SHA-256")
                val headerBytes = ByteArray(16)
                var headerRead = 0
                var actualSize = 0L

                resolver.openInputStream(uri)?.use { input ->
                    tempFile.outputStream().use { out ->
                        val buffer = ByteArray(8192)
                        while (true) {
                            val read = input.read(buffer)
                            if (read <= 0) break
                            if (headerRead < headerBytes.size) {
                                val toCopy = minOf(read, headerBytes.size - headerRead)
                                System.arraycopy(buffer, 0, headerBytes, headerRead, toCopy)
                                headerRead += toCopy
                            }
                            digest.update(buffer, 0, read)
                            out.write(buffer, 0, read)
                            actualSize += read
                        }
                    }
                } ?: throw IllegalStateException("Não foi possível abrir o arquivo selecionado.")

                val effectiveHeader = headerBytes.copyOf(headerRead)
                val headerHex = effectiveHeader.take(8).joinToString(" ") { "%02X".format(it) }
                val sha256 = digest.digest().joinToString("") { "%02x".format(it) }
                val (magicType, suspiciousSpoof) = detectMagicType(effectiveHeader, fileName)
                val finalSize = if (actualSize > 0) actualSize else reportedSize

                val isZip = effectiveHeader.size >= 4 &&
                    effectiveHeader[0] == 0x50.toByte() && effectiveHeader[1] == 0x4B.toByte() &&
                    effectiveHeader[2] == 0x03.toByte() && effectiveHeader[3] == 0x04.toByte()

                val hasManifestInside = if (isZip) {
                    runCatching {
                        ZipFile(tempFile).use { zip -> zip.getEntry("AndroidManifest.xml") != null }
                    }.getOrDefault(false)
                } else {
                    false
                }

                val isApk = fileName.endsWith(".apk", ignoreCase = true) || hasManifestInside
                val findings = mutableListOf<String>()
                var apkMeta: ApkMetadata? = null

                if (suspiciousSpoof) {
                    findings.add("Incompatibilidade suspeita entre extensão '$fileName' e assinatura binária ($magicType).")
                }

                if (isApk) {
                    if (!isZip) {
                        findings.add("Arquivo possui extensão .apk mas não contém cabeçalho ZIP válido (PK).")
                    } else {
                        apkMeta = inspectApkArchive(tempFile)
                    }
                }

                val riskLevel: ScanRiskLevel
                val riskSummary: String

                if (apkMeta != null) {
                    val criticalCount = apkMeta.permissions.count { it.isCritical }
                    val elevatedCount = apkMeta.permissions.count { it.isElevated }
                    val hasAccessibility = apkMeta.permissions.any {
                        it.fullName == "android.permission.BIND_ACCESSIBILITY_SERVICE"
                    }
                    val hasSms = apkMeta.permissions.any {
                        it.fullName == "android.permission.READ_SMS" || it.fullName == "android.permission.RECEIVE_SMS"
                    }
                    val hasInstallOrOverlay = apkMeta.permissions.any {
                        it.fullName == "android.permission.REQUEST_INSTALL_PACKAGES" ||
                            it.fullName == "android.permission.SYSTEM_ALERT_WINDOW"
                    }

                    if (criticalCount > 0) {
                        findings.add("$criticalCount permissão(ões) crítica(s) detectada(s) no AndroidManifest.")
                    }
                    if (elevatedCount > 0) {
                        findings.add("$elevatedCount permissão(ões) sensível(is) secundária(s) declarada(s).")
                    }
                    if (apkMeta.embeddedArchiveCount > 0) {
                        findings.add("${apkMeta.embeddedArchiveCount} arquivo(s) .apk/.jar/.dex secundário(s) embutido(s) no pacote.")
                    }

                    when {
                        suspiciousSpoof ||
                            criticalCount >= 3 ||
                            (hasAccessibility && (hasSms || hasInstallOrOverlay)) ||
                            (hasSms && hasInstallOrOverlay) -> {
                            riskLevel = ScanRiskLevel.HIGH_RISK
                            riskSummary = "Alto Risco: combinação crítica de permissões invasivas ou carga oculta."
                        }
                        criticalCount in 1..2 || elevatedCount >= 3 || apkMeta.embeddedArchiveCount > 0 -> {
                            riskLevel = ScanRiskLevel.WARNING
                            riskSummary = "Atenção: APK solicita permissões sensíveis que exigem verificação de origem."
                        }
                        else -> {
                            riskLevel = ScanRiskLevel.SAFE
                            riskSummary = "Seguro: nenhuma permissão crítica ou anomalia estática grave detectada."
                            if (findings.isEmpty()) {
                                findings.add("Estrutura APK íntegra e sem permissões críticas na matriz de risco.")
                            }
                        }
                    }
                } else {
                    when {
                        suspiciousSpoof -> {
                            riskLevel = ScanRiskLevel.HIGH_RISK
                            riskSummary = "Alto Risco: assinatura binária disfarçada detectada."
                        }
                        magicType.contains("Executável") || magicType.contains("ELF") || magicType.contains("DEX") -> {
                            riskLevel = ScanRiskLevel.WARNING
                            riskSummary = "Atenção: binário executável detectado ($magicType). Execute apenas se confiar na fonte."
                            findings.add("Arquivo executável fora de contêiner APK padrão.")
                        }
                        else -> {
                            riskLevel = ScanRiskLevel.SAFE
                            riskSummary = "Seguro: assinatura mágica consistente com o tipo declarado."
                            findings.add("Sem assinaturas executáveis ocultas ou inconsistência de cabeçalho.")
                        }
                    }
                }

                FileScanReport(
                    fileName = fileName,
                    sizeBytes = finalSize,
                    magicType = if (isApk && isZip) "APK Android Package (ZIP/PK)" else magicType,
                    magicHeaderHex = headerHex.ifBlank { "N/A" },
                    sha256 = sha256,
                    riskLevel = riskLevel,
                    riskSummary = riskSummary,
                    findings = findings,
                    apkMetadata = apkMeta
                )
            } finally {
                tempFile.delete()
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun inspectApkArchive(apkFile: File): ApkMetadata? {
        val pm = context.packageManager
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            PackageManager.GET_PERMISSIONS or PackageManager.GET_SIGNING_CERTIFICATES
        } else {
            PackageManager.GET_PERMISSIONS or PackageManager.GET_SIGNATURES
        }

        val info: PackageInfo = pm.getPackageArchiveInfo(apkFile.absolutePath, flags) ?: return null

        val requested = info.requestedPermissions?.toList().orEmpty()
        val scannedPerms = requested.map { perm ->
            val shortName = perm.substringAfterLast('.')
            val criticalDesc = CRITICAL_PERMISSIONS[perm]
            val elevatedDesc = ELEVATED_PERMISSIONS[perm]
            ScannedPermission(
                fullName = perm,
                shortName = shortName,
                isCritical = criticalDesc != null,
                isElevated = elevatedDesc != null,
                description = criticalDesc ?: elevatedDesc ?: "Permissão padrão do sistema Android"
            )
        }.sortedWith(
            compareByDescending<ScannedPermission> { it.isCritical }
                .thenByDescending { it.isElevated }
                .thenBy { it.shortName }
        )

        var dexCount = 0
        var nativeLibCount = 0
        var embeddedCount = 0
        runCatching {
            ZipFile(apkFile).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val entryName = entries.nextElement().name.lowercase()
                    when {
                        entryName.endsWith(".dex") -> {
                            dexCount++
                            if (!entryName.startsWith("classes")) embeddedCount++
                        }
                        entryName.endsWith(".so") -> nativeLibCount++
                        entryName.endsWith(".apk") || entryName.endsWith(".jar") -> embeddedCount++
                    }
                }
            }
        }

        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.longVersionCode
        } else {
            info.versionCode.toLong()
        }

        val signerHash = runCatching {
            val sigBytes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                info.signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray()
            } else {
                info.signatures?.firstOrNull()?.toByteArray()
            }
            sigBytes?.let { bytes ->
                MessageDigest.getInstance("SHA-256").digest(bytes).joinToString(":") { "%02X".format(it) }
            }
        }.getOrNull()

        return ApkMetadata(
            packageName = info.packageName ?: "desconhecido",
            versionName = info.versionName ?: "N/D",
            versionCode = versionCode,
            minSdk = info.applicationInfo?.minSdkVersion,
            targetSdk = info.applicationInfo?.targetSdkVersion,
            dexCount = dexCount,
            nativeLibCount = nativeLibCount,
            embeddedArchiveCount = embeddedCount,
            signerSha256 = signerHash,
            permissions = scannedPerms
        )
    }
}
