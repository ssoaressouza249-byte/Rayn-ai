package com.example

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.RaynTab
import com.example.ui.RaynViewModel
import com.example.ui.components.RaynBottomBar
import com.example.ui.components.RaynTopBar
import com.example.ui.components.SecurityLockScreen
import com.example.ui.screens.RaynChatScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SwbBuilderScreen
import com.example.ui.screens.VirusScannerScreen
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.RaynAITheme

class MainActivity : ComponentActivity() {

    private val viewModel: RaynViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )

        setContent {
            RaynAITheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                val integrityReport = uiState.integrityReport

                when {
                    uiState.isCheckingIntegrity && integrityReport == null -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(CyberBackground),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = NeonBlue)
                        }
                    }

                    integrityReport != null && !integrityReport.isValid -> {
                        SecurityLockScreen(
                            report = integrityReport,
                            onRecheck = { viewModel.recheckIntegrity() }
                        )
                    }

                    else -> {
                        BackHandler(enabled = uiState.currentTab != RaynTab.CHAT) {
                            viewModel.selectTab(RaynTab.CHAT)
                        }

                        Scaffold(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(CyberBackground),
                            containerColor = CyberBackground,
                            contentWindowInsets = WindowInsets(0, 0, 0, 0),
                            topBar = {
                                RaynTopBar(
                                    credits = uiState.preferences.swbCredits,
                                    onProtectedBadgeClick = { viewModel.selectTab(RaynTab.SETTINGS) },
                                    onCreditsBadgeClick = { viewModel.selectTab(RaynTab.SWB) }
                                )
                            },
                            bottomBar = {
                                RaynBottomBar(
                                    currentTab = uiState.currentTab,
                                    onSelectTab = { viewModel.selectTab(it) }
                                )
                            }
                        ) { innerPadding ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding)
                                    .imePadding()
                            ) {
                                Crossfade(
                                    targetState = uiState.currentTab,
                                    label = "raynTabTransition"
                                ) { tab ->
                                    when (tab) {
                                        RaynTab.CHAT -> RaynChatScreen(
                                            uiState = uiState,
                                            onInputChanged = viewModel::updateChatInput,
                                            onAttachDocument = viewModel::attachDocument,
                                            onClearAttachment = viewModel::clearAttachment,
                                            onSend = viewModel::sendChatMessage,
                                            onSaveMessageToFolder = viewModel::saveMessageToSafFolder,
                                            onClearChat = viewModel::clearChatHistory,
                                            onNavigateToSettings = { viewModel.selectTab(RaynTab.SETTINGS) }
                                        )

                                        RaynTab.SWB -> SwbBuilderScreen(
                                            uiState = uiState,
                                            onAppNameChange = viewModel::updateSwbAppName,
                                            onPackageNameChange = viewModel::updateSwbPackageName,
                                            onDescriptionChange = viewModel::updateSwbDescription,
                                            onGenerateClick = viewModel::generateSwbProject,
                                            onSaveToSafClick = viewModel::reSaveLastSwbToSaf
                                        )

                                        RaynTab.SCANNER -> VirusScannerScreen(
                                            uiState = uiState,
                                            onFileSelected = viewModel::scanSelectedFile
                                        )

                                        RaynTab.SETTINGS -> SettingsScreen(
                                            uiState = uiState,
                                            onApiKeyDraftChange = viewModel::updateApiKeyDraft,
                                            onSaveApiKey = viewModel::saveGeminiApiKey,
                                            onTestConnection = viewModel::testGeminiConnection,
                                            onSafFolderPicked = viewModel::onSafFolderPicked,
                                            onRecheckIntegrity = viewModel::recheckIntegrity
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
