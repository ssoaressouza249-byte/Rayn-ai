package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.RaynSettingsState
import com.example.ui.components.RaynBottomNavBar
import com.example.ui.components.RaynTopBar
import com.example.ui.components.SecurityLockOverlay
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.ScannerScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SwbCreatorScreen
import com.example.ui.theme.CrimsonSurface
import com.example.ui.theme.CyberDeepBlack
import com.example.ui.theme.DeepBlueAccent
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCrimson
import com.example.ui.theme.RaynAiTheme
import com.example.viewmodel.RaynTab
import com.example.viewmodel.RaynViewModel
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    private val viewModel: RaynViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(CyberDeepBlack.toArgb()),
            navigationBarStyle = SystemBarStyle.dark(CyberDeepBlack.toArgb()),
        )
        setContent {
            RaynAiTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                val integrity = uiState.integrityReport

                if (uiState.currentTab != RaynTab.CHAT && integrity?.isValid != false) {
                    BackHandler {
                        viewModel.selectTab(RaynTab.CHAT)
                    }
                }

                LaunchedEffect(uiState.saveBanner) {
                    if (uiState.saveBanner != null) {
                        delay(4200L)
                        viewModel.dismissBanner()
                    }
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        containerColor = CyberDeepBlack,
                        topBar = {
                            RaynTopBar(
                                credits = uiState.settings.swbCredits,
                                maxCredits = RaynSettingsState.MAX_SWB_CREDITS,
                                isProtected = integrity?.isValid ?: true,
                            )
                        },
                        bottomBar = {
                            RaynBottomNavBar(
                                currentTab = uiState.currentTab,
                                onTabSelected = viewModel::selectTab,
                            )
                        },
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when (uiState.currentTab) {
                                RaynTab.CHAT -> ChatScreen(
                                    uiState = uiState,
                                    onInputChange = viewModel::updateChatInput,
                                    onAttachDocument = viewModel::attachDocument,
                                    onClearAttachment = viewModel::clearAttachment,
                                    onSendMessage = viewModel::sendChatMessage,
                                    onSaveMessageToFolder = viewModel::saveMessageToFolder,
                                    onGoToSettings = { viewModel.selectTab(RaynTab.SETTINGS) },
                                )

                                RaynTab.SWB -> SwbCreatorScreen(
                                    uiState = uiState,
                                    onAppNameChange = viewModel::updateSwbAppName,
                                    onPackageNameChange = viewModel::updateSwbPackageName,
                                    onDescriptionChange = viewModel::updateSwbDescription,
                                    onUseAiChange = viewModel::updateSwbUseAi,
                                    onApplyPreset = viewModel::applySwbPreset,
                                    onGenerateSwb = viewModel::generateSwbProject,
                                )

                                RaynTab.SCANNER -> ScannerScreen(
                                    uiState = uiState,
                                    onScanFile = viewModel::scanFile,
                                )

                                RaynTab.SETTINGS -> SettingsScreen(
                                    uiState = uiState,
                                    onApiKeyChange = viewModel::updateApiKeyDraft,
                                    onSaveAndSyncModels = viewModel::saveApiKeyAndSyncModels,
                                    onSelectModel = viewModel::selectModel,
                                    onTestConnection = viewModel::testConnection,
                                    onFolderSelected = viewModel::onFolderSelected,
                                    onVerifyIntegrity = viewModel::runIntegrityCheck,
                                )
                            }

                            AnimatedVisibility(
                                visible = uiState.saveBanner != null,
                                enter = fadeIn(),
                                exit = fadeOut(),
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                            ) {
                                val banner = uiState.saveBanner
                                if (banner != null) {
                                    val accent = if (banner.isError) NeonCrimson else NeonBlue
                                    val bg = if (banner.isError) CrimsonSurface else DeepBlueAccent
                                    Surface(
                                        color = bg,
                                        shape = RoundedCornerShape(12.dp),
                                        border = BorderStroke(1.dp, accent),
                                        shadowElevation = 6.dp,
                                        modifier = Modifier.fillMaxWidth(),
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 12.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        ) {
                                            Icon(
                                                imageVector = if (banner.isError) Icons.Filled.Error else Icons.Filled.CheckCircle,
                                                contentDescription = null,
                                                tint = accent,
                                            )
                                            Text(
                                                text = banner.message,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = accent,
                                                modifier = Modifier.weight(1f),
                                            )
                                            IconButton(
                                                onClick = viewModel::dismissBanner,
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.Close,
                                                    contentDescription = "Fechar aviso",
                                                    tint = accent,
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (integrity != null && !integrity.isValid) {
                        SecurityLockOverlay(report = integrity)
                    }
                }
            }
        }
    }
}
