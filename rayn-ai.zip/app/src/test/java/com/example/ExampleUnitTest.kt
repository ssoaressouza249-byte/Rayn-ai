package com.example

import com.example.scanner.ApkStaticScanner
import com.example.ui.RaynChatParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `chat parser extracts structured file, subfolder, and auto-save intent`() {
        val aiText = """
            Arquivo atualizado conforme solicitado:
            <<<RAYN_FILE_START>>>
            FILENAME: config.json
            SUBFOLDER: meus/configs
            AUTO_SAVE: true
            <<<CONTENT>>>
            {"enabled": true}
            <<<RAYN_FILE_END>>>
        """.trimIndent()

        val parsed = RaynChatParser.parseReply(
            rawReply = aiText,
            userPrompt = "Edite e salve como config.json na subpasta meus/configs",
            attachedFileName = null
        )

        assertEquals("config.json", parsed.fileName)
        assertEquals("meus/configs", parsed.subfolder)
        assertTrue(parsed.shouldAutoSave)
        assertEquals("{\"enabled\": true}", parsed.savableContent)
    }

    @Test
    fun `magic bytes detector flags disguised Windows PE executable`() {
        val mzBytes = byteArrayOf(0x4D, 0x5A, 0x90.toByte(), 0x00)
        val (type, spoofed) = ApkStaticScanner.detectMagicType(mzBytes, "nota.txt")
        assertTrue(type.contains("PE/MZ"))
        assertTrue(spoofed)

        val zipBytes = byteArrayOf(0x50, 0x4B, 0x03, 0x04)
        val (apkType, apkSpoofed) = ApkStaticScanner.detectMagicType(zipBytes, "app.apk")
        assertTrue(apkType.contains("APK"))
        assertFalse(apkSpoofed)
    }
}
