package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.network.PolicyGuard
import com.example.storage.StorageManager
import com.example.swb.SwbProjectGenerator
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.zip.ZipInputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class ExampleRobolectricTest {

    @Test
    fun `verify Rayn AI identity and package name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Rayn AI", context.getString(R.string.app_name))
        assertEquals("com.raynai.assistant.pro", context.packageName)
    }

    @Test
    fun `policy guard blocks cheats and nsfw while allowing crosshair utility and sketchware`() {
        assertNotNull(PolicyGuard.checkPromptViolation("Criar um aimbot e injetar .so em Android/data"))
        assertNotNull(PolicyGuard.checkPromptViolation("Conteudo NSFW pornografia"))
        assertNull(PolicyGuard.checkPromptViolation("Criar mira crosshair flutuante visual simples sem tocar em jogos"))
        assertNull(PolicyGuard.checkPromptViolation("Montar blocos onCreate e onClick no Sketchware Pro"))
    }

    @Test
    fun `extractFilePayload detects explicit file markers`() {
        val response = """
            Aqui está o JSON:
            ===FILE:config.json===
            {"app": "Rayn AI", "active": true}
            ===END_FILE===
        """.trimIndent()
        val payload = StorageManager.extractFilePayload("salve config.json na pasta", response)
        assertEquals("config.json", payload.suggestedFileName)
        assertTrue(payload.content.contains("Rayn AI"))
    }

    @Test
    fun `swb generator creates valid zip with all six sketchware entries`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val spec = SwbProjectGenerator.buildDefaultSpec("MiraVisual", "mira flutuante simples")
        val result = SwbProjectGenerator.generateAndSaveSwb(
            context = context,
            folderUriString = "",
            appName = "MiraVisual",
            packageName = "com.rayn.miravisual",
            spec = spec,
        ).getOrThrow()

        val expectedEntries = setOf(
            "project",
            "data/file",
            "data/view",
            "data/logic",
            "data/library",
            "data/resource",
        )
        assertEquals(expectedEntries, result.entries.toSet())

        val actualEntries = mutableSetOf<String>()
        context.contentResolver.openInputStream(result.savedFile.uri)?.use { stream ->
            ZipInputStream(stream).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    actualEntries.add(entry.name)
                    entry = zis.nextEntry
                }
            }
        }
        assertEquals(expectedEntries, actualEntries)
    }
}
