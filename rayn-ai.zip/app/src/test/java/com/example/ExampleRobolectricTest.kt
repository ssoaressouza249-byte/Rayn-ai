package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.RaynPreferencesRepository
import com.example.security.SecurityIntegrityGuard
import com.example.swb.SwbPackageBuilder
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name and package match Rayn AI specification`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Rayn AI", appName)
        assertEquals("com.raynai.assistant.pro", context.packageName)
    }

    @Test
    fun `credits deplete from 15 to 0 and auto restore after 15 hours`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        var fakeNow = 1_000_000_000L
        val repo = RaynPreferencesRepository(context) { fakeNow }

        repeat(15) {
            assertTrue(repo.consumeSwbCredit())
        }
        assertFalse(repo.consumeSwbCredit())

        val depleted = repo.getSnapshot()
        assertEquals(0, depleted.swbCredits)
        assertEquals(fakeNow, depleted.cooldownStartTimestamp)

        // Advance 14h 59m 59s -> still locked
        fakeNow += RaynPreferencesRepository.COOLDOWN_DURATION_MS - 1000L
        assertFalse(repo.refreshCreditsIfCooldownExpired())
        assertEquals(0, repo.getSnapshot().swbCredits)

        // Advance 1 more second -> exact 15 hours -> restored to 15
        fakeNow += 1000L
        assertTrue(repo.refreshCreditsIfCooldownExpired())
        assertEquals(15, repo.getSnapshot().swbCredits)
        assertEquals(0L, repo.getSnapshot().cooldownStartTimestamp)
    }

    @Test
    fun `security integrity guard blocks tampered package name, app name, or certificate hash`() {
        val valid = SecurityIntegrityGuard.evaluateIntegrity(
            detectedPackageName = "com.raynai.assistant.pro",
            stringResourceAppName = "Rayn AI",
            manifestLabelAppName = "Rayn AI",
            currentCertSha256 = "AA:BB:CC",
            expectedCertSha256 = "AA:BB:CC"
        )
        assertTrue(valid.isValid)

        val renamedApp = SecurityIntegrityGuard.evaluateIntegrity(
            detectedPackageName = "com.raynai.assistant.pro",
            stringResourceAppName = "Fake AI",
            manifestLabelAppName = "Fake AI",
            currentCertSha256 = "AA:BB:CC",
            expectedCertSha256 = "AA:BB:CC"
        )
        assertFalse(renamedApp.isValid)

        val tamperedCert = SecurityIntegrityGuard.evaluateIntegrity(
            detectedPackageName = "com.raynai.assistant.pro",
            stringResourceAppName = "Rayn AI",
            manifestLabelAppName = "Rayn AI",
            currentCertSha256 = "11:22:33",
            expectedCertSha256 = "AA:BB:CC"
        )
        assertFalse(tamperedCert.isValid)
    }

    @Test
    fun `swb builder packages all required Sketchware Pro zip entries`() {
        val builder = SwbPackageBuilder()
        val rawJson = """
            {
              "rejected": false,
              "project": {"my_app_name": "TesteApp", "my_sc_pkg_name": "com.teste.app"},
              "file": {"activities": [{"fileName": "main", "type": 1}]},
              "view": {"mainXml": "<LinearLayout/>"},
              "logic": {"events": []},
              "library": {"useAppCompat": true},
              "resource": {"stringsXml": "<resources/>"}
            }
        """.trimIndent()

        val artifact = builder.buildFromAiJson(rawJson, "TesteApp", "com.teste.app")
        assertEquals("TesteApp.swb", artifact.fileName)

        val zipEntries = mutableSetOf<String>()
        ZipInputStream(ByteArrayInputStream(artifact.archiveBytes)).use { zis ->
            while (true) {
                val entry = zis.nextEntry ?: break
                zipEntries.add(entry.name)
            }
        }
        assertTrue(zipEntries.containsAll(
            listOf("project", "data/file", "data/view", "data/logic", "data/library", "data/resource")
        ))
    }
}
